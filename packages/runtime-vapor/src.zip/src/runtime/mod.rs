mod bridge;
mod core;
mod dom_adapter;
mod globals;
mod instance;
mod js_adapter;
mod js_shims;
mod props;
mod real_dom;
mod render;
mod render_lifecycle;
mod render_patch;
mod types;

pub use bridge::{WasmRue, createRue};
pub use core::Rue;
pub use dom_adapter::DomAdapter;
pub use globals::{VNODE_REGISTRY, push_pending_hook, take_pending_hooks};
pub use globals::{is_runtime_crashed, last_hook_error, mark_crashed_from_hook};
pub use instance::*;
pub use js_adapter::JsDomAdapter;
pub use js_shims::{
    create_element_js, emitted_js, fragment_const_js, h_js, mount_js, render_between_js, render_js,
    unmount_js, use_plugin_js, vapor_js,
};
pub use props::*;
#[allow(unused_imports)]
pub use render::*;
pub use types::*;
