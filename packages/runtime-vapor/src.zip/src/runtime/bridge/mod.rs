//! WASM 侧桥接模块（中文注释增强）
//!
//! - 暴露 WasmRue 供 JS 调用（创建、渲染、挂载、卸载等）
//! - 管理 VNode 注册表与异步渲染队列（render/renderBetween）
//! - 通过 Promise.then 驱动批处理刷新，避免重入
//! - 提供 DOM 适配器的设置与读取，以及生命周期 hooks 注册
use crate::reactive::effect::EffectHandle;
use crate::runtime::core::Rue;
use crate::runtime::dom_adapter::DomAdapter;
use crate::runtime::globals::{VNODE_REGISTRY, push_pending_hook, take_pending_hooks};
use crate::runtime::js_adapter::JsDomAdapter;
use crate::runtime::types::{Child, ComponentProps, VNode, VNodeType};
use js_sys::{Array, Function, Object, Promise, Reflect};
use std::cell::RefCell;
use wasm_bindgen::JsCast;
use wasm_bindgen::JsValue;
use wasm_bindgen::closure::Closure;
use wasm_bindgen::prelude::*;

#[cfg(feature = "dev")]
use crate::log::{log, want_log, warning};

mod create_element;
mod create_rue;
mod emitted;
mod get_current_container;
mod get_dom_adapter;
mod get_dom_adapter_mut;
mod h;
mod mount;
mod on_before_create;
mod on_before_mount;
mod on_before_unmount;
mod on_before_update;
mod on_created;
mod on_error;
mod on_mounted;
mod on_unmounted;
mod on_updated;
mod render;
mod render_between;
mod set_dom_adapter;
mod unmount;
mod use_plugin;
mod vapor;

pub use create_rue::createRue;

#[wasm_bindgen]
pub struct WasmRue {
    inner: RefCell<Rue<JsDomAdapter>>,
    // 最近一次渲染/挂载的容器引用（JS 值克隆）：
    // - 供 getCurrentContainer() 之类的 API 使用
    // - 也便于在某些错误/兜底路径下找到“当前容器上下文”
    last_container: RefCell<Option<JsValue>>,
    pending_between: RefCell<Vec<(VNode<JsDomAdapter>, JsValue, JsValue, JsValue)>>,
    pending_render: RefCell<Vec<(VNode<JsDomAdapter>, JsValue)>>,
    // root 级别的 effect 句柄（由 mount 创建）：
    // - mount(app, container) 会用 create_effect 包裹 app 执行，从而实现依赖变化自动重渲染
    // - 需要在 unmount 或再次 mount 时释放，避免多个 root effect 并存导致重复渲染/内存泄漏
    root_effect: RefCell<Option<EffectHandle>>,
}

pub(super) fn is_fragment_like(el: &JsValue) -> bool {
    let nt = Reflect::get(el, &JsValue::from_str("nodeType"))
        .unwrap_or(JsValue::UNDEFINED)
        .as_f64()
        .unwrap_or(0.0);
    if nt == 11.0 {
        let host = Reflect::get(el, &JsValue::from_str("host")).unwrap_or(JsValue::UNDEFINED);
        if host.is_undefined() || host.is_null() {
            return true;
        }
    }
    let tag = Reflect::get(el, &JsValue::from_str("tag"))
        .unwrap_or(JsValue::UNDEFINED)
        .as_string()
        .unwrap_or_default();
    tag == "fragment"
}

pub(super) fn collect_fragment_nodes(el: &JsValue) -> Option<Array> {
    if !is_fragment_like(el) {
        return None;
    }
    let child_nodes =
        Reflect::get(el, &JsValue::from_str("childNodes")).unwrap_or(JsValue::UNDEFINED);
    if !child_nodes.is_undefined() && !child_nodes.is_null() {
        return Some(Array::from(&child_nodes));
    }
    let children = Reflect::get(el, &JsValue::from_str("children")).unwrap_or(JsValue::UNDEFINED);
    if !children.is_undefined() && !children.is_null() {
        return Some(Array::from(&children));
    }
    Some(Array::new())
}

impl WasmRue {
    /// 处理挂起的渲染队列：render 优先，其次 renderBetween
    ///
    /// 若借用失败（重入），将任务放回队列并终止本次处理
    fn process_queues(&self) {
        loop {
            let r = { self.pending_render.borrow_mut().pop() };
            if let Some((vnode_r, cont_r)) = r {
                match self.inner.try_borrow_mut() {
                    Ok(mut inner_r) => {
                        let mut cr = cont_r.clone();
                        inner_r.render(vnode_r, (&mut cr).into());
                    }
                    Err(_) => {
                        self.pending_render.borrow_mut().push((vnode_r, cont_r));
                        break;
                    }
                }
                continue;
            }
            let b = { self.pending_between.borrow_mut().pop() };
            if let Some((vnode_b, p_b, s_b, e_b)) = b {
                match self.inner.try_borrow_mut() {
                    Ok(mut inner_b) => {
                        let mut pb = p_b.clone();
                        inner_b.render_between(vnode_b, (&mut pb).into(), s_b.into(), e_b.into());
                    }
                    Err(_) => {
                        self.pending_between.borrow_mut().push((vnode_b, p_b, s_b, e_b));
                        break;
                    }
                }
                continue;
            }
            break;
        }
    }

    /// 是否存在挂起任务（render 或 renderBetween）
    fn has_pending(&self) -> bool {
        !self.pending_render.borrow().is_empty() || !self.pending_between.borrow().is_empty()
    }

    /// 创建一个闭包用于驱动队列处理；在任务未清空时递归调度
    fn make_process_closure(this_ptr: *const WasmRue) -> Closure<dyn FnMut(JsValue)> {
        Closure::wrap(Box::new(move |_v: JsValue| {
            let this = unsafe { &*this_ptr };
            this.process_queues();
            if this.has_pending() {
                let cb2 = WasmRue::make_process_closure(this_ptr);
                let _ = Promise::resolve(&JsValue::UNDEFINED).then(&cb2);
                cb2.forget();
            }
        }) as Box<dyn FnMut(JsValue)>)
    }

    /// 安排一次异步刷新：Promise.then 调用处理闭包
    pub(super) fn schedule_flush(&self) {
        let this_ptr = self as *const WasmRue;
        let cb = WasmRue::make_process_closure(this_ptr);
        let _ = Promise::resolve(&JsValue::UNDEFINED).then(&cb);
        cb.forget();
    }

    fn dispose_root_effect(&self) {
        // 释放 mount 创建的 root effect（如果存在）。
        //
        // 设计上，一个 WasmRue 实例同一时刻只应该有一个“root effect”：
        // - 负责把 app(props) 的结果渲染到指定容器
        // - 依赖追踪会让它在响应式数据变化时自动重新运行
        //
        // 若不释放：
        // - 重复 mount 会叠加多个 effect，造成重复 render / DOM 重复插入
        // - 同时也会导致 JS Function / Closure 等资源无法回收
        let maybe = { self.root_effect.borrow_mut().take() };
        if let Some(eh) = maybe {
            eh.dispose_js();
        }
    }

    /// 从注册表按 id 取出 VNode（并置空其槽位）
    pub(super) fn take_vnode_from_registry(idv: &JsValue) -> Option<VNode<JsDomAdapter>> {
        if let Some(idf) = idv.as_f64() {
            let idx = idf as usize;
            VNODE_REGISTRY.with(|reg| {
                let mut r = reg.borrow_mut();
                if idx < r.len() { r[idx].take() } else { None }
            })
        } else {
            None
        }
    }
}
