use super::WasmRue;
use js_sys::{Array, Function, Object, Reflect};
use wasm_bindgen::JsCast;
use wasm_bindgen::JsValue;
use wasm_bindgen::closure::Closure;
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
impl WasmRue {
    /// 记录最近容器（克隆一份 JsValue）
    fn set_last_container_clone(&self, cont: &JsValue) {
        let mut lc = self.last_container.borrow_mut();
        *lc = Some(cont.clone());
    }

    /// 挂载前刷新延迟队列：设置当前容器并执行 deferred_queue
    fn pre_flush_deferred(&self, cont: &JsValue) {
        // deferred_queue 的来源：
        // - 运行时某些路径会把“需要在真实挂载前执行的任务”延迟入队（例如插件、hook 包装等）
        // - mount 的语义是“把应用挂到指定容器”，因此在第一次 render 前需要先把这些任务跑完
        //
        // 注意：这里用 std::mem::take 把队列直接搬走，避免在执行过程中 re-entrant 再次借用 inner。
        let pre_queue = {
            let mut inner = self.inner.borrow_mut();
            inner.current_container = Some(cont.clone().into());
            std::mem::take(&mut inner.deferred_queue)
        };
        #[cfg(feature = "dev")]
        {
            if crate::log::want_log("debug", "runtime:mount pre_flush") {
                crate::log::log(
                    "debug",
                    &format!("runtime:mount pre_flush deferred_queue_len={}", pre_queue.len()),
                );
            }
        }
        for mut f in pre_queue.into_iter() {
            f();
        }
    }

    fn normalize_app_return(&self, v: JsValue) -> JsValue {
        // mount(app) 的 app 返回值在生态里并不总是“VNode id / VNode registry 对象”：
        // - 一部分使用方式会直接返回真实 DOM Node（例如 setup 返回 element / fragment）
        // - render_wasm 已经支持 { vaporElement } 这种“把真实 DOM 当作 Vapor VNode” 的输入形式
        //
        // 因此这里做一个“轻量归一化”：
        // - 若返回值看起来像 DOM Node（存在 nodeType 数字属性）
        // - 则包装成 { vaporElement: node } 交给 render_wasm，复用其解析逻辑
        if v.is_object() {
            let obj = Object::from(v.clone());
            let node_type =
                Reflect::get(&obj, &JsValue::from_str("nodeType")).unwrap_or(JsValue::UNDEFINED);
            if node_type.as_f64().is_some() {
                let out = Object::new();
                let _ = Reflect::set(&out, &JsValue::from_str("vaporElement"), &v);
                return out.into();
            }
        }
        v
    }

    /// 若 app 为函数：调用并将返回值交由 render 处理
    fn try_call_app_and_render(&self, app: &JsValue, cont: &JsValue) -> bool {
        // 这里传给 app 的 props 目前是空对象：
        // - 通常会传入 props + children
        // - Rust/wasm 这层目前主要是兼容 “app(props) -> vnode-like” 的签名
        //
        // 关键点：app 函数内部通常会“读取响应式数据”（signal/ref/computed 等）。
        // 在 mount_wasm 中我们会把 try_call_app_and_render 包进 create_effect 里，
        // 因此这些读取会被依赖追踪，从而实现 root 级别的自动重渲染。
        let props = Object::new();
        if let Some(func) = app.dyn_ref::<Function>() {
            if let Ok(v) = func.call1(&JsValue::UNDEFINED, &props.into()) {
                #[cfg(feature = "dev")]
                {
                    if crate::log::want_log("debug", "runtime:mount app return") {
                        let is_num = v.as_f64().is_some();
                        let is_str = v.as_string().is_some();
                        let is_obj = v.is_object();
                        crate::log::log(
                            "debug",
                            &format!(
                                "runtime:mount app return type num={} str={} obj={}",
                                is_num, is_str, is_obj
                            ),
                        );
                    }
                }
                let vv = self.normalize_app_return(v);
                // 将 app 的返回值交给 render_wasm：
                // - vv 可以是 registry id / dev object / { vaporElement } 等
                // - render_wasm 会解析成 VNode 并入队，随后通过 Promise.then 异步 flush
                self.render_wasm(vv, cont.clone());
                return true;
            }
        }
        false
    }

    /// 渲染一个空 Fragment 到容器，用于无 app 场景
    fn render_empty_fragment_to(&self, cont: &JsValue) {
        let vnode_id = self.create_element_wasm(
            JsValue::from_str("fragment"),
            JsValue::UNDEFINED,
            Array::new().into(),
        );
        let mut vnode_id_unwrapped = vnode_id.clone();
        if vnode_id_unwrapped.is_object() {
            let obj_id = Object::from(vnode_id_unwrapped.clone());
            vnode_id_unwrapped = Reflect::get(&obj_id, &JsValue::from_str("__rue_vnode_id"))
                .unwrap_or(JsValue::UNDEFINED);
        }
        if let Some(vnode) = super::WasmRue::take_vnode_from_registry(&vnode_id_unwrapped) {
            self.pending_render.borrow_mut().push((vnode, cont.clone()));
            self.schedule_flush();
        }
    }

    #[wasm_bindgen(js_name = "mount")]
    /// 挂载入口：预刷新延迟任务 → 调用 app → 回退到空片段
    pub fn mount_wasm(&self, app: JsValue, container: JsValue) {
        #[cfg(feature = "dev")]
        {
            if crate::log::want_log("debug", "runtime:mount") {
                let has_app = app.is_function();
                let has_cont = !container.is_undefined() && !container.is_null();
                crate::log::log(
                    "debug",
                    &format!("runtime:mount has_app_fn={} has_container={}", has_app, has_cont),
                );
            }
        }
        let cont: JsValue = container;
        // mount 可能被重复调用（例如热更新、路由切换、用户手动重新挂载）：
        // - 为避免一个 WasmRue 实例存在多个 root effect 同时运行导致重复 render
        // - 这里先释放上一次 mount 创建的 root effect（如果存在）
        self.dispose_root_effect();
        self.set_last_container_clone(&cont);
        self.pre_flush_deferred(&cont);
        if app.is_function() {
            // 核心：用 create_effect 把 “执行 app 并 render” 包起来：
            // - app 内部读取的响应式数据会被依赖追踪
            // - 当依赖变化时，effect 重新运行，从而触发重新 render
            //
            // 为什么这里用裸指针 *const WasmRue：
            // - Closure 需要 'static 生命周期
            // - self 不能直接 move 进 Closure（借用/生命周期不满足）
            // - WasmRue 在 JS 侧持有期间其地址稳定；这里用指针在回调里取回引用
            //
            // 注意：如果未来引入“销毁 WasmRue 实例”的 API，需要确保先 dispose_root_effect，
            // 否则这里的回调可能在实例析构后被触发。
            let this_ptr = self as *const WasmRue;
            let app_for_cb = app.clone();
            let cont_for_cb = cont.clone();
            let cb = Closure::wrap(Box::new(move || {
                let this = unsafe { &*this_ptr };
                // effect 每次运行都尝试：
                // 1) 调用 app(props)
                // 2) 将返回值 render 到容器
                // 若 app 调用失败或不是函数返回，则回退到空片段保证容器可用
                if !this.try_call_app_and_render(&app_for_cb, &cont_for_cb) {
                    this.render_empty_fragment_to(&cont_for_cb);
                }
            }) as Box<dyn FnMut()>);
            // create_effect 的入参是 JS Function，这里把 Rust Closure 转成 Function。
            let cb_fn: Function = cb.as_ref().clone().unchecked_into();
            // 创建 root effect：其句柄会存入 WasmRue，用于 unmount/再次 mount 时释放。
            let eh = crate::reactive::effect::create_effect(cb_fn, None);
            *self.root_effect.borrow_mut() = Some(eh);
            // 重要：Closure::wrap 创建的闭包如果在 Rust 侧被 drop，会导致 JS 侧回调失效。
            // root effect 生命周期由运行时管理，因此这里 forget 让其交由 wasm_bindgen 的“泄漏式”策略存活。
            cb.forget();
        } else {
            // app 不是函数：保持语义一致，仍然渲染一个空 Fragment 占位到容器。
            self.render_empty_fragment_to(&cont);
        }
    }
}
