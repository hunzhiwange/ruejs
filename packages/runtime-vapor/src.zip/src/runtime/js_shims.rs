//! JS 侧导出符号的占位实现（仅用于类型与链接）
//!
//! 这些函数在实际运行时会被 bridge 模块中的 WasmRue 实现替代，
//! 这里提供空实现以满足 wasm-bindgen 绑定和编译期需求。
use wasm_bindgen::JsValue;
use wasm_bindgen::prelude::*;

#[wasm_bindgen(js_name = "createElement")]
/// JS createElement 的占位实现：运行时会被真正实现替换
pub fn create_element_js(_type_tag: JsValue, _props: JsValue, _children: JsValue) -> JsValue {
    JsValue::UNDEFINED
}

#[wasm_bindgen(js_name = "render")]
/// JS render 的占位实现
pub fn render_js(_vnode: JsValue, _container: JsValue) {}

#[wasm_bindgen(js_name = "renderBetween")]
/// JS renderBetween 的占位实现
pub fn render_between_js(_vnode: JsValue, _parent: JsValue, _start: JsValue, _end: JsValue) {}

#[wasm_bindgen(js_name = "mount")]
/// JS mount 的占位实现
pub fn mount_js(_app: JsValue, _container: JsValue) {}

#[wasm_bindgen(js_name = "unmount")]
/// JS unmount 的占位实现
pub fn unmount_js(_container: JsValue) {}

#[wasm_bindgen(js_name = "use")]
/// JS use 插件的占位实现
pub fn use_plugin_js(_plugin: JsValue, _options: JsValue) {}

#[wasm_bindgen(js_name = "emitted")]
/// JS emitted 的占位实现：返回 UNDEFINED
pub fn emitted_js(_props: JsValue) -> JsValue {
    JsValue::UNDEFINED
}

#[wasm_bindgen(js_name = "vapor")]
/// JS vapor 的占位实现：返回 UNDEFINED
pub fn vapor_js(_setup: JsValue) -> JsValue {
    JsValue::UNDEFINED
}

#[wasm_bindgen(js_name = "h")]
/// JS h 的占位实现：返回 UNDEFINED
pub fn h_js(_type_tag: JsValue, _props: JsValue, _children: JsValue) -> JsValue {
    JsValue::UNDEFINED
}

#[wasm_bindgen(js_name = "Fragment")]
/// JS Fragment 常量：返回内部定义的分隔符字符串
pub fn fragment_const_js() -> String {
    super::types::FRAGMENT.to_string()
}
