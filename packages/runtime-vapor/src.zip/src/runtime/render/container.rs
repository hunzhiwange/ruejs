use super::super::Rue;
use super::super::types::VNode;
#[cfg(feature = "dev")]
use crate::log::{log, want_log};
use crate::reactive::core::batch_scope;
use crate::runtime::dom_adapter::DomAdapter;
use wasm_bindgen::JsValue;
use wasm_bindgen::throw_str;

// 容器渲染入口（render）：
// - 维护 container_map，将容器与其当前 vnode 绑定，支持后续增量更新
// - 首次挂载：清空容器 innerHTML 并插入真实 DOM（片段需插入子节点）
// - 后续更新：命中 container_map 时走 patch 以复用 DOM，触发生命周期钩子
// - 崩溃防护：检测运行时异常并抛出最后的钩子错误/运行时错误

impl<A: DomAdapter> Rue<A>
where
    A::Element: Clone,
{
    /// 将 vnode 渲染到指定容器；支持首次挂载与后续增量更新
    ///
    /// 参数：
    /// - vnode：待渲染的虚拟节点
    /// - container：目标容器元素
    /// 行为：
    /// - 崩溃防护与钩子调用
    /// - 命中 container_map 走 patch；未命中则首次挂载并记录映射
    pub fn render(&mut self, mut vnode: VNode<A>, container: &mut A::Element)
    where
        <A as DomAdapter>::Element: From<JsValue> + Into<JsValue>,
    {
        #[cfg(feature = "dev")]
        {
            // 进入渲染日志（开发模式）
            if want_log("debug", "runtime:render enter") {
                log("debug", "runtime:render enter");
            }
        }
        // 运行时崩溃防护：优先抛出最后的钩子错误，其次运行时错误
        if self.crashed || crate::runtime::is_runtime_crashed() {
            if let Some(e) = crate::runtime::last_hook_error() {
                wasm_bindgen::throw_val(e);
            } else if let Some(e) = self.last_error.clone() {
                wasm_bindgen::throw_val(e);
            } else {
                throw_str("Rue runtime crashed");
            }
        }

        if self.get_dom_adapter().is_none() || self.get_dom_adapter_mut().is_none() {
            throw_str("Rue runtime: no DOM adapter for render");
        }

        batch_scope(|| {
            self.current_container = Some(container.clone());
            self.compact_container_map();
            if !self.deferred_queue.is_empty() {
                let mut queue = Vec::new();
                queue.append(&mut self.deferred_queue);
                for mut f in queue.into_iter() {
                    f();
                }
            }
            self.call_hooks("before_mount");
            if let Some(idx) = self.find_container_index(container) {
                #[cfg(feature = "dev")]
                {
                    if want_log("debug", "runtime:render container_map hit") {
                        log("debug", &format!("runtime:render container_map hit idx={}", idx));
                    }
                }
                let taken = {
                    let entry = self.container_map.get_mut(idx).unwrap();
                    entry.1.take()
                };
                if let Some(mut old_vnode) = taken {
                    let mut parent = container.clone();
                    self.call_hooks("before_update");
                    #[cfg(feature = "dev")]
                    {
                        if want_log("debug", "runtime:render patch") {
                            log("debug", "runtime:render patch");
                        }
                    }
                    self.patch(&mut old_vnode, &mut vnode, &mut parent);
                    self.call_hooks("updated");
                } else {
                    #[cfg(feature = "dev")]
                    {
                        if want_log("debug", "runtime:render initial append") {
                            log("debug", "runtime:render initial append");
                        }
                    }
                    if let Some(el) = self.create_real_dom(&mut vnode) {
                        if let Some(adapter) = self.get_dom_adapter() {
                            if adapter.is_fragment(&el) {
                                if let Some(adapter2) = self.get_dom_adapter_mut() {
                                    adapter2.set_inner_html(container, "");
                                }
                                self.insert_fragment_children(container, &el, &None);
                            } else {
                                if let Some(adapter2) = self.get_dom_adapter_mut() {
                                    adapter2.append_child(container, &el);
                                } else {
                                    throw_str("Rue runtime: no DOM adapter for initial append");
                                }
                            }
                        } else {
                            throw_str("Rue runtime: no DOM adapter for initial append");
                        }
                    }
                }
                {
                    let entry = self.container_map.get_mut(idx).unwrap();
                    entry.1 = Some(vnode);
                }
            } else {
                #[cfg(feature = "dev")]
                {
                    if want_log("debug", "runtime:render first mount") {
                        log("debug", "runtime:render first mount");
                    }
                }
                if let Some(el) = self.create_real_dom(&mut vnode) {
                    if let Some(adapter) = self.get_dom_adapter() {
                        if adapter.is_fragment(&el) {
                            if let Some(adapter2) = self.get_dom_adapter_mut() {
                                adapter2.set_inner_html(container, "");
                            }
                            self.insert_fragment_children(container, &el, &None);
                        } else {
                            if let Some(adapter2) = self.get_dom_adapter_mut() {
                                adapter2.set_inner_html(container, "");
                                adapter2.append_child(container, &el);
                            } else {
                                throw_str("Rue runtime: no DOM adapter for first mount");
                            }
                        }
                    } else {
                        throw_str("Rue runtime: no DOM adapter for first mount");
                    }
                }
                self.container_map.push((container.clone(), Some(vnode)));
            }
            self.call_hooks("mounted");
        });
        #[cfg(feature = "dev")]
        {
            if want_log("debug", "runtime:render exit") {
                log("debug", "runtime:render exit");
            }
        }
    }
}
