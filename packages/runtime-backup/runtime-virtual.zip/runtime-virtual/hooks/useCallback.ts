import { useMemo } from './useMemo'

export function useCallback<T extends (...args: any[]) => any>(fn: T, deps: any[]): T {
  return useMemo(() => fn, deps)
}
