import rue, { onError } from '../rue'

export function useError(opts?: { overlay?: boolean; console?: boolean }) {
  const installConsole = () => {
    onError((error: any) => {
      try {
        const stack = (error && (error as any).stack) || ''
        ;(console as any).error?.(
          '%cRue Error - The Wasm Framework For Vapor Native DOM%c\n' + stack,
          'background:linear-gradient(to right, oklch(0.541 0.281 293.009) 0%, oklch(0.667 0.295 322.15) 50%, oklch(0.656 0.241 354.308) 100%);color:#fff;padding:5px 8px;font-size:15px;border-radius:5px;font-weight:900;letter-spacing:.02em;margin-bottom:0.5em',
          'color:red;padding:3px 5px',
        )
      } catch {}
    })
  }

  const installOverlay = () => {
    onError((error: any) => {
      const message = (error && (error as any).message) || String(error)
      const id = 'rue-error-overlay'
      let root = document.getElementById(id)
      if (!root) {
        root = document.createElement('div')
        root.id = id
        document.body.appendChild(root)
      }
      root.innerHTML = `
        <div id="rue-error-backdrop" class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div id="rue-error-dialog" class="w-full max-w-md rounded-md overflow-hidden bg-gray-900 text-gray-100">
            <div id="rue-error-header" class="flex items-center justify-between px-3 py-2 border-b border-gray-700 text-white" style="background:linear-gradient(to right, oklch(0.541 0.281 293.009) 0%, oklch(0.667 0.295 322.15) 50%, oklch(0.656 0.241 354.308) 100%)">
              <span class="text-sm font-bold">Rue Error</span>
              <button id="rue-error-close" aria-label="close" class="text-xs font-medium cursor-pointer hover:opacity-80">close</button>
            </div>
            <div class="p-4 text-sm leading-relaxed">
              ${message}
            </div>
          </div>
        </div>
      `
      const close = root.querySelector('#rue-error-close') as HTMLButtonElement | null
      if (close)
        close.onclick = e => {
          e.preventDefault()
          if (root) root.remove()
        }
    })
  }

  const emit = (error: any, instance?: any) => {
    ;(rue as any).handleError(error, instance ?? null)
  }

  if (opts?.console) installConsole()
  if (opts?.overlay) installOverlay()

  return { on: onError, emit, installConsole, installOverlay }
}
