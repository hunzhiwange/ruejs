import { withHookSlot } from '@rue/runtime-vapor'

export function useRef<T = any>(initial?: T): { current: T | undefined } {
  const factory = () => ({ current: initial }) as { current: T | undefined }
  return withHookSlot(factory) as { current: T | undefined }
}
