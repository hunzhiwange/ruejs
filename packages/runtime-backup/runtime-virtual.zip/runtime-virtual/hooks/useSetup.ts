import { useMemo } from './useMemo'

export function useSetup<T>(factory: () => T): T {
  return useMemo(factory, [])
}
