import { withHookSlot } from '@rue/runtime-vapor'
import { toValue } from '../reactivity'
export function useMemo<T>(factory: () => T, deps: any[]): T {
  const slot = withHookSlot(() => ({ value: undefined as T, deps: undefined as any })) as {
    value: T
    deps: any
  }

  const nd = Array.isArray(deps) ? deps.map(d => toValue(d)) : deps
  const changed =
    !slot.deps ||
    !Array.isArray(nd) ||
    slot.deps.length !== nd.length ||
    nd.some((d: any, idx: number) => !Object.is(d, slot.deps[idx]))
  if (changed) {
    slot.value = factory()
    slot.deps = Array.isArray(nd) ? nd.slice() : nd
  }
  return slot.value as T
}
