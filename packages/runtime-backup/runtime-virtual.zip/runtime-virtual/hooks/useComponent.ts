import rue, { FC, h } from '../rue'
import { signal } from '../reactivity'

const asyncComponentCache = new WeakMap<Function, any>()

export function useComponent<P = {}>(
  loader: () => Promise<{ default: FC<P> } | FC<P>>,
  opts?: { loading?: FC<any>; error?: FC<{ error: any }> },
): FC<P> {
  let started = false

  return (props: any) => {
    const appRue = rue as any
    let slot = asyncComponentCache.get(loader as any)
    if (!slot) {
      const component = signal<FC<P> | null>(null, {}, true)
      const err = signal<any>(null, {}, true)
      const start = () => {
        try {
          loader()
            .then((m: any) => {
              component.set(m && (m as any).default ? ((m as any).default as FC<P>) : (m as FC<P>))
            })
            .catch((e: any) => {
              err.set(e)
              appRue.handleError(e, null)
            })
        } catch (e: any) {
          err.set(e)
          appRue.handleError(e, null)
        }
      }

      const Loading: FC<any> =
        opts?.loading ??
        (() =>
          h(
            'div',
            { className: 'inline-flex items-center gap-2 text-sm text-gray-500' },
            h('span', {
              className:
                'inline-block h-4 w-4 rounded-full border-2 border-gray-300 border-t-transparent animate-spin',
            }),
            h('span', null, 'Loading...'),
          ))

      const ErrorComp: FC<any> =
        opts?.error ??
        ((p: any) => {
          const err = p && p.error
          const msg = err && err.message ? err.message : typeof err === 'string' ? err : 'Error'
          return h(
            'div',
            {
              className:
                'flex items-start gap-2 rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700',
            },
            h(
              'span',
              {
                className:
                  'inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-red-600 text-white text-xs',
              },
              '!',
            ),
            h('div', null, h('div', { className: 'font-medium' }, msg)),
          )
        })
      slot = { component, err, start, Loading, ErrorComp }
      asyncComponentCache.set(loader as any, slot)
    }

    const { component, err, start, Loading, ErrorComp } = slot as any

    if (!started) {
      started = true
      start()
    }

    if (err.get()) return h(ErrorComp, { error: err.get() })

    if (!component.get()) return h(Loading, {})

    try {
      return h(component.get() as FC<P>, props)
    } catch (e) {
      ;(slot as any).err.value = e
      ;(rue as any).handleError(e, (rue as any).currentInstance)
      return h(ErrorComp, { error: (slot as any).err.value })
    }
  }
}
