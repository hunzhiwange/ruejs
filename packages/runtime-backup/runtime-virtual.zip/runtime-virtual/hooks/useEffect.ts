import rue, { onMounted, onUpdated, onBeforeUnmount } from '../rue'
import { withHookSlot } from '@rue/runtime-vapor'
import { toValue } from '../reactivity'

export function useEffect(effect: () => void | (() => void), deps?: any[]): void {
  throw new Error('useEffect is not supported now')
  const slot = withHookSlot(() => ({
    deps: undefined as any,
    nextDeps: undefined as any,
    cleanup: undefined as (() => void) | undefined,
    run: null as (() => void) | null,
    initialized: false,
    eff: effect,
    stop: undefined as any,
    sources: undefined as any,
    help: undefined as any,
  })) as any

  const run = () => {
    const nd = slot.nextDeps
    const changed =
      !slot.initialized ||
      !nd ||
      !slot.deps ||
      nd.length !== slot.deps.length ||
      nd.some((d: any, idx: number) => !Object.is(d, slot.deps[idx]))
    if (changed) {
      if (slot.cleanup) {
        try {
          slot.cleanup()
        } catch (e) {
          ;(rue as any).handleError(e, (rue as any).currentInstance)
        }
      }
      const ret = slot.eff()
      slot.cleanup = typeof ret === 'function' ? (ret as () => void) : undefined
      slot.deps = nd ? nd.slice() : slot.deps
      slot.initialized = true
    }
  }
  slot.run = run

  onMounted(run)
  onUpdated(run)
  onBeforeUnmount(() => {
    try {
      if (slot.stop) slot.stop()
    } catch (e) {
      ;(rue as any).handleError(e, (rue as any).currentInstance)
    }
    if (slot.cleanup) {
      try {
        slot.cleanup()
      } catch (e) {
        ;(rue as any).handleError(e, (rue as any).currentInstance)
      }
    }
    slot.cleanup = undefined
    slot.stop = undefined
  })

  slot.eff = effect
  slot.nextDeps = Array.isArray(deps) ? deps.map(d => toValue(d)) : deps
}
