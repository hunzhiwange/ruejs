import rue, { FC, ComponentInstance, VNode, Rue } from '../rue'

export function useApp(
  AppOrOptions:
    | ComponentInstance
    | {
        setup?: () => any
        render?: (ctx: any) => VNode
      },
  runtime?: Rue,
) {
  let containerRef: HTMLElement | null = null
  //const appRue = (runtime as any) || (rue as any)
  const appRue = rue as any
  const App: ComponentInstance =
    typeof AppOrOptions === 'function'
      ? (AppOrOptions as ComponentInstance)
      : (() => {
          const opts = (AppOrOptions || {}) as { setup?: () => any; render?: (ctx: any) => VNode }
          const Wrapper: FC = () => {
            const ctx = typeof opts.setup === 'function' ? opts.setup() : {}
            return typeof opts.render === 'function'
              ? opts.render(ctx)
              : appRue.createElement('div', null, '')
          }
          return Wrapper
        })()

  const normalizeContainer = (container: string | HTMLElement): HTMLElement | null => {
    if (typeof container === 'string') {
      const el = document.querySelector(container)
      return (el as HTMLElement) || null
    }
    return container as HTMLElement
  }
  return {
    use(plugin: any, ...options: any[]) {
      appRue.use(plugin, ...options)
      return this
    },
    mount(container: string | HTMLElement) {
      const el = normalizeContainer(container)
      if (!el) return
      if ((el as any).nodeType === 1) {
        ;(el as Element).textContent = ''
      }
      appRue.mount(App, el)
      if (el instanceof Element) {
        el.setAttribute('data-rue-app', '')
      }
      containerRef = el
    },
    unmount() {
      if (containerRef) {
        appRue.unmount(containerRef)
        containerRef = null
      }
    },
  }
}
