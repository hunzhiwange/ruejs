import swc from '@swc/core'
const { parseSync, printSync } = swc

function exprToCode(node, _source) {
  try {
    const wrapper = parseSync('0;', {
      syntax: 'typescript',
      tsx: true,
      target: 'es2020',
    })
    wrapper.body[0].expression = node
    const out = printSync(wrapper, { minify: false }).code.trim()
    return out.replace(/;$/, '')
  } catch {
    return ''
  }
}

// ID 生成器
let __elId = 0,
  __spanId = 0,
  __listId = 0,
  __mapId = 0
let __usesRender = false
const nextEl = () => `_el${++__elId}`
const nextSpan = () => `_span${++__spanId}`
const nextList = () => `_list${++__listId}`
const nextMap = () => `_map${++__mapId}`

// 表达式解包
const unwrapExpr = e => {
  let x = e
  while (x && typeof x === 'object') {
    if (x.type === 'ParenthesizedExpression') {
      x = x.expression
      continue
    }
    if (
      x.type === 'TsAsExpression' ||
      x.type === 'TSAsExpression' ||
      x.type === 'TsTypeAssertion' ||
      x.type === 'TSTypeAssertion'
    ) {
      x = x.expression
      continue
    }
    break
  }
  return x
}

// 顶层工具 - isJSX（函数）
const isJSX = n => {
  const x = unwrapExpr(n)
  return !!x && (x.type === 'JSXElement' || x.type === 'JSXFragment')
}
function hasDeepJSX(node) {
  const visit = n => {
    if (!n || typeof n !== 'object') return false
    if (n.type === 'JSXElement' || n.type === 'JSXFragment') return true
    for (const k of Object.keys(n)) {
      const v = n[k]
      if (Array.isArray(v)) {
        for (const x of v) {
          if (visit(x)) return true
        }
      } else if (visit(v)) return true
    }
    return false
  }
  return visit(node)
}
function getFirstJSX(node) {
  const visit = n => {
    if (!n || typeof n !== 'object') return null
    if (n.type === 'JSXElement' || n.type === 'JSXFragment') return n
    for (const k of Object.keys(n)) {
      const v = n[k]
      if (Array.isArray(v)) {
        for (const x of v) {
          const r = visit(x)
          if (r) return r
        }
      } else {
        const r = visit(v)
        if (r) return r
      }
    }
    return null
  }
  return visit(node)
}

// 增强的 map 检测
const isMapCall = e => {
  const x = unwrapExpr(e)
  if (!x || x.type !== 'CallExpression') return false

  let callee = x.callee
  if (callee?.type === 'OptionalChainingExpression') callee = callee.base
  if (!callee || callee.type !== 'MemberExpression') return false

  const prop = callee.property
  const propName = prop && prop.type === 'Identifier' ? prop.value : prop?.value
  return propName === 'map'
}

// 特殊检测：props.children
const isPropsChildren = e => {
  const x = unwrapExpr(e)
  return (
    !!x &&
    x.type === 'MemberExpression' &&
    x.object &&
    x.object.type === 'Identifier' &&
    x.object.value === 'props' &&
    (x.property && x.property.type === 'Identifier' ? x.property.value : x.property?.value) ===
      'children'
  )
}

// 通用检测：props.<slot>
const isPropsMember = e => {
  const x = unwrapExpr(e)
  return (
    !!x &&
    x.type === 'MemberExpression' &&
    x.object &&
    x.object.type === 'Identifier' &&
    x.object.value === 'props' &&
    !!x.property
  )
}

// Map 调用解析器
function parseMapCall(expr, _source) {
  const x = unwrapExpr(expr)
  if (!x || x.type !== 'CallExpression') return null

  const callee = x.callee
  if (!callee || callee.type !== 'MemberExpression') return null

  const arrayExpr = callee.object
  const mapFn = x.arguments[0]

  if (!arrayExpr || !mapFn) return null

  const mapFnExpr = unwrapExpr(mapFn.expression || mapFn)
  if (
    !mapFnExpr ||
    !(mapFnExpr.type === 'ArrowFunctionExpression' || mapFnExpr.type === 'FunctionExpression')
  ) {
    return null
  }

  // 提取参数
  const params = mapFnExpr.params || []
  const primaryParam = params[0]?.type === 'Identifier' ? params[0].value : 'item'
  const secondaryParam = params[1]?.type === 'Identifier' ? params[1].value : 'index'
  let destructureParamCode = null
  if (params[0] && params[0].type === 'ObjectPattern') {
    try {
      const mod = parseSync('const __tmp = __src;', {
        syntax: 'typescript',
        tsx: true,
        target: 'es2020',
      })
      const decl = mod.body[0]
      decl.declarations[0].id = params[0]
      decl.declarations[0].init = { type: 'Identifier', value: primaryParam }
      const printed = printSync(mod, { minify: false }).code.trim()
      destructureParamCode = printed
    } catch {}
  }

  // 提取函数体
  let body = mapFnExpr.body
  while (body && body.type === 'ParenthesizedExpression') body = body.expression

  // 处理块语句中的 return
  if (body && body.type === 'BlockStatement') {
    const retStmt = body.body.find(s => s.type === 'ReturnStatement')
    body = retStmt ? retStmt.argument : body
  }

  const arrayCode = exprToCode(arrayExpr, _source) || '[]'

  return {
    arrayExpr,
    arrayCode: arrayCode.trim() || '[]',
    mapFn: mapFnExpr,
    body,
    primaryParam,
    secondaryParam,
    destructureParamCode,
    originalExpr: expr,
  }
}

// 核心：构建嵌套 DOM 结构
function buildNested(jsxEl, parentVar, source) {
  const isFragment = jsxEl.type === 'JSXFragment' || jsxEl.opening?.name?.value === 'Fragment'

  if (isFragment) {
    return buildFragment(jsxEl, parentVar, source)
  }

  return buildElement(jsxEl, parentVar, source)
}

function buildFragment(jsxEl, parentVar, source) {
  const creation = []
  const updates = []

  for (const child of jsxEl.children || []) {
    processChildNode(child, parentVar, creation, updates, source, jsxEl.children, null)
  }

  return { creation, updates, elName: parentVar }
}

function buildElement(jsxEl, parentVar, source) {
  const nameNode = jsxEl.opening?.name
  const nameVal = nameNode && nameNode.value
  if (nameNode && typeof nameVal === 'string' && /^[A-Z]/.test(nameVal) && nameVal !== 'Fragment') {
    return buildComponentElement(jsxEl, parentVar, source)
  }
  const tag = jsxEl.opening.name.value
  const elName = nextEl()
  const creation = [
    `const ${elName} = _$createElement(${JSON.stringify(tag)});`,
    `_$appendChild(${parentVar}, ${elName});`,
  ]
  const updates = []
  processAttributes(jsxEl, elName, creation, updates, source)
  for (const child of jsxEl.children || []) {
    processChildNode(child, elName, creation, updates, source, jsxEl.children, tag)
  }
  return { creation, updates, elName }
}

function buildComponentElement(jsxEl, parentVar, source) {
  const start = nextList()
  const end = nextList()
  const creation = [
    `const ${start} = _$createComment('rue:component:start');`,
    `const ${end} = _$createComment('rue:component:end');`,
    `_$appendChild(${parentVar}, ${start});`,
    `_$appendChild(${parentVar}, ${end});`,
    `_$vaporWatchRun(() => { renderBetween(${exprToCode(jsxEl, source)}, ${parentVar}, ${start}, ${end}); });`,
  ]
  const updates = []
  __usesRender = true
  return { creation, updates, elName: parentVar }
}

function processAttributes(jsxEl, elName, creation, updates, source) {
  for (const attr of jsxEl.opening?.attributes || []) {
    if (attr.type !== 'JSXAttribute') continue

    const name = attr.name.value
    const isEvent = /^on[A-Z]/.test(name)

    if (isEvent) {
      processEventAttribute(attr, elName, creation, source)
      continue
    }

    processRegularAttribute(attr, elName, creation, updates, source)
  }
}

function processEventAttribute(attr, elName, creation, source) {
  const name = attr.name.value
  const val = attr.value
  const ev = name.slice(2).toLowerCase()
  const code = val?.type === 'JSXExpressionContainer' ? exprToCode(val.expression, source) : ''
  const handler = code && code.trim() ? code : '() => {}'

  creation.push(`${elName}.addEventListener(${JSON.stringify(ev)}, (${handler}));`)
}

function processRegularAttribute(attr, elName, creation, updates, source) {
  const name = attr.name.value
  const val = attr.value

  if (val?.type === 'StringLiteral') {
    if (name === 'className') {
      creation.push(`${elName}.className = ${JSON.stringify(val.value)};`)
    } else if (name === 'disabled') {
      // 任何字符串字面量（包括空串）都按 presence 处理为 true
      creation.push(`${elName}.disabled = true;`)
    } else if (name === 'ref') {
    } else {
      creation.push(
        `${elName}.setAttribute(${JSON.stringify(name)}, ${JSON.stringify(val.value)});`,
      )
    }
  } else if (val?.type === 'JSXExpressionContainer') {
    const code0 = exprToCode(val.expression, source)
    const code =
      code0 && code0.trim() ? code0 : name === 'checked' ? 'false' : name === 'value' ? '""' : '""'

    if (name === 'className') {
      creation.push(`_$vaporWatchRun(() => { ${elName}.className = String(${code}); });`)
    } else if (name === 'value') {
      creation.push(`_$vaporWatchRun(() => { ${elName}.value = ${code}; });`)
    } else if (name === 'checked') {
      creation.push(`_$vaporWatchRun(() => { ${elName}.checked = !!(${code}); });`)
    } else if (name === 'disabled') {
      creation.push(`_$vaporWatchRun(() => { ${elName}.disabled = !!(${code}); });`)
    } else if (name === 'style') {
      creation.push(
        `_$vaporWatchRun(() => { const ${elName}_style = (${code}); _$setStyle(${elName}, ${elName}_style); });`,
      )
    } else if (name === 'ref') {
      creation.push(`let ${elName}_prev_ref;`)
      creation.push(
        `const ${elName}_ref_stop = watchEffect(() => { const __r = (${code}); const __p = ${elName}_prev_ref; if (__p && __p !== __r) { if (typeof __p === 'function') { try { __p(null); } catch {} } else if (__p && typeof __p === 'object' && 'current' in __p) { __p.current = undefined; } } if (typeof __r === 'function') { try { __r(${elName}); } catch {} } else if (__r && typeof __r === 'object' && 'current' in __r) { __r.current = ${elName}; } ${elName}_prev_ref = __r; });`,
      )
      creation.push(
        `onBeforeUnmount(() => { const __p = ${elName}_prev_ref; if (__p) { if (typeof __p === 'function') { try { __p(null); } catch {} } else if (__p && typeof __p === 'object' && 'current' in __p) { __p.current = undefined; } } ${elName}_ref_stop(); });`,
      )
    } else {
      creation.push(
        `_$vaporWatchRun(() => { ${elName}.setAttribute(${JSON.stringify(name)}, String(${code})); });`,
      )
    }
  } else {
    // 无值布尔属性，如 <button disabled>
    if (name === 'disabled') {
      creation.push(`${elName}.disabled = true;`)
    } else if (name === 'checked') {
      creation.push(`${elName}.checked = true;`)
    }
  }
}

function processChildNode(child, parentVar, creation, updates, source, allChildren, parentTag) {
  // 特殊处理：style 标签内的文本不得做空白压缩
  if (child.type === 'JSXText' && parentTag === 'style') {
    const raw = child.value || ''
    creation.push(`_$appendChild(${parentVar}, _$createTextNode(${JSON.stringify(raw)}));`)
    return
  }

  if (child.type === 'JSXText') {
    const raw = child.value || ''
    const idx = allChildren ? allChildren.indexOf(child) : -1
    const prev = idx > 0 ? allChildren[idx - 1] : null
    const next = idx >= 0 && idx < allChildren.length - 1 ? allChildren[idx + 1] : null
    const isMeaningfulNode = n => !!n && (n.type !== 'JSXText' ? true : /[^\s]/.test(n.value || ''))
    const keepLeading = isMeaningfulNode(prev)
    const keepTrailing = isMeaningfulNode(next)
    const hasNewline = /[\r\n]/.test(raw)
    let normalized = raw.replace(/[ \t]+/g, ' ')
    if (hasNewline) {
      normalized = normalized.replace(/\s*[\r\n]+\s*/g, '')
    }
    const hasNonWhitespace = /[^\s]/.test(normalized)
    if (!hasNonWhitespace) {
      if (!hasNewline && keepLeading && keepTrailing) {
        creation.push(`_$appendChild(${parentVar}, _$createTextNode(" "));`)
      }
      return
    }
    if (normalized.startsWith(' ') && !keepLeading) normalized = normalized.slice(1)
    if (normalized.endsWith(' ') && !keepTrailing) normalized = normalized.slice(0, -1)
    if (normalized) {
      creation.push(`_$appendChild(${parentVar}, _$createTextNode(${JSON.stringify(normalized)}));`)
    }
    return
  } else if (child.type === 'JSXExpressionContainer') {
    processExpressionContainer(child, parentVar, creation, updates, source, allChildren, parentTag)
  } else if (child.type === 'JSXElement') {
    const nested = buildNested(child, parentVar, source)
    creation.push(...nested.creation)
    updates.push(...nested.updates)
  }
  // 新增：直接子节点为 Fragment 时也进行构建
  else if (child.type === 'JSXFragment') {
    const nested = buildNested(child, parentVar, source)
    creation.push(...nested.creation)
    updates.push(...nested.updates)
  }
}

function processExpressionContainer(
  child,
  parentVar,
  creation,
  updates,
  source,
  allChildren,
  parentTag,
) {
  const expr0 = child.expression
  const expr = unwrapExpr(expr0)

  if (!expr) return

  // 特殊处理：style 标签中的表达式，生成纯文本节点，而不是 <span>
  if (parentTag === 'style' && !isJSX(expr) && !isMapCall(expr)) {
    const spanName = nextSpan()
    creation.push(`const ${spanName} = _$createTextNode("");`)
    creation.push(`_$appendChild(${parentVar}, ${spanName});`)
    if (isStaticEmptyLike(expr)) {
      creation.push(`${spanName}.textContent = '';`)
    } else if (isStaticTextLiteral(expr)) {
      const lit = getStaticTextLiteral(expr)
      creation.push(`${spanName}.textContent = ${lit};`)
    } else {
      const code0 = exprToCode(expr, source)
      const code = code0 && code0.trim() ? code0 : '""'
      creation.push(
        `_$vaporWatchRun(() => { const __val = (${code}); _$settextContent(${spanName}, __val); });`,
      )
    }
    return
  }

  // 如果父节点是 <text>，优先把表达式直接写入父节点文本，避免嵌套 <text>
  if (parentTag === 'text' && !isJSX(expr) && !isMapCall(expr)) {
    if (isStaticEmptyLike(expr)) {
      creation.push(`${parentVar}.textContent = '';`)
    } else if (isStaticTextLiteral(expr)) {
      const lit = getStaticTextLiteral(expr)
      creation.push(`${parentVar}.textContent = ${lit};`)
    } else {
      const code0 = exprToCode(expr, source)
      const code = code0 && code0.trim() ? code0 : '""'
      creation.push(
        `_$vaporWatchRun(() => { const __val = (${code}); _$settextContent(${parentVar}, __val); });`,
      )
    }
    return
  }

  // 检测不同类型的表达式（增加兜底：深层 JSX）
  if (isJSX(expr)) {
    processDirectJSX(expr, parentVar, creation, updates, source)
  } else if (isPropsChildren(expr)) {
    processPropsChildren(parentVar, creation, updates, source)
  } else if (isPropsMember(expr)) {
    const code0 = exprToCode(expr, source)
    const code = code0 && code0.trim() ? code0 : 'null'
    processPropsSlot(code, parentVar, creation, updates, source)
  } else if (
    expr.type === 'ConditionalExpression' &&
    (hasJSXInConditional(expr) || hasDeepJSXInConditional(expr))
  ) {
    processConditionalJSX(expr, parentVar, creation, updates, source)
  } else if (isMapCall(expr)) {
    processMapExpression(expr, parentVar, creation, updates, source, allChildren)
  } else if (hasDeepJSX(expr)) {
    const first = getFirstJSX(expr)
    if (first) {
      processDirectJSX(first, parentVar, creation, updates, source)
    } else {
      processGenericExpression(expr, parentVar, creation, updates, source)
    }
  } else {
    processGenericExpression(expr, parentVar, creation, updates, source)
  }
}

// 条件表达式中是否包含 JSX（函数）
function hasJSXInConditional(expr) {
  const cons = unwrapExpr(expr.consequent)
  const alt = unwrapExpr(expr.alternate)
  return (cons && isJSX(cons)) || (alt && isJSX(alt))
}

// 兜底：条件表达式分支“深层包含 JSX”（包括 Parenthesized 包裹）
function hasDeepJSXInConditional(expr) {
  const cons = unwrapExpr(expr.consequent)
  const alt = unwrapExpr(expr.alternate)
  return (cons && hasDeepJSX(cons)) || (alt && hasDeepJSX(alt))
}

function processDirectJSX(jsxNode, parentVar, creation, updates, source) {
  const nested = buildNested(jsxNode, parentVar, source)
  creation.push(...nested.creation)
  updates.push(...nested.updates)
}

// 特殊处理：在 Vapor 组件中渲染 props.children
function processPropsChildren(parentVar, creation, _updates, _source) {
  const start = nextList()
  const end = nextList()
  creation.push(`const ${start} = _$createComment('rue:children:start');`)
  creation.push(`const ${end} = _$createComment('rue:children:end');`)
  creation.push(`_$appendChild(${parentVar}, ${start});`)
  creation.push(`_$appendChild(${parentVar}, ${end});`)
  creation.push(
    `_$vaporWatchRun(() => { renderBetween(h('fragment', null, ...(props.children || [])), ${parentVar}, ${start}, ${end}); });`,
  )
  __usesRender = true
}

// 通用处理：在 Vapor 组件中渲染任意 props.<slot>
function processPropsSlot(exprCode, parentVar, creation, _updates, _source) {
  const start = nextList()
  const end = nextList()
  creation.push(`const ${start} = _$createComment('rue:slot:start');`)
  creation.push(`const ${end} = _$createComment('rue:slot:end');`)
  creation.push(`_$appendChild(${parentVar}, ${start});`)
  creation.push(`_$appendChild(${parentVar}, ${end});`)
  creation.push(
    `_$vaporWatchRun(() => { const __slot = (${exprCode}); const __vnode = Array.isArray(__slot) ? h('fragment', null, ...__slot) : (typeof __slot === 'object' && __slot ? __slot : h('fragment', null, String(__slot ?? ''))); renderBetween(__vnode, ${parentVar}, ${start}, ${end}); });`,
  )
  __usesRender = true
}

// 条件 JSX 处理（函数）
function processConditionalJSX(expr, parentVar, creation, updates, source) {
  const start = nextList()
  const end = nextList()
  creation.push(`const ${start} = _$createComment('rue:cond:start');`)
  creation.push(`const ${end} = _$createComment('rue:cond:end');`)
  creation.push(`_$appendChild(${parentVar}, ${start});`)
  creation.push(`_$appendChild(${parentVar}, ${end});`)
  const testCode = exprToCode(expr.test, source) || 'false'
  const consCode0 = exprToCode(unwrapExpr(expr.consequent), source)
  const consCode = consCode0 && consCode0.trim() ? consCode0 : '""'
  const altCode0 = exprToCode(unwrapExpr(expr.alternate), source)
  const altCode = altCode0 && altCode0.trim() ? altCode0 : '""'
  creation.push(
    `_$vaporWatchRun(() => { if (${testCode}) { const __v = (${consCode}); const __n = (typeof __v === 'object' && __v) ? __v : h('fragment', null, String(__v ?? '')); renderBetween(__n, ${parentVar}, ${start}, ${end}); } else { const __v2 = (${altCode}); const __n2 = (typeof __v2 === 'object' && __v2) ? __v2 : h('fragment', null, String(__v2 ?? '')); renderBetween(__n2, ${parentVar}, ${start}, ${end}); } });`,
  )
  __usesRender = true
}

// 核心：处理 map 表达式
function processMapExpression(expr, parentVar, creation, updates, source, _allChildren) {
  const mapInfo = parseMapCall(expr, source)
  if (!mapInfo) {
    processGenericExpression(expr, parentVar, creation, updates, source)
    return
  }
  const start = nextList()
  const end = nextList()
  creation.push(`const ${start} = _$createComment('rue:list:start');`)
  creation.push(`const ${end} = _$createComment('rue:list:end');`)
  creation.push(`_$appendChild(${parentVar}, ${start});`)
  creation.push(`_$appendChild(${parentVar}, ${end});`)
  if (mapInfo.body && hasDeepJSX(mapInfo.body)) {
    createAdvancedMapProcessing(mapInfo, parentVar, start, end, creation, updates, source)
  } else {
    createSimpleMapProcessing(mapInfo, parentVar, start, end, creation, updates, source)
  }
}

// 高级 map 处理（函数）
function createAdvancedMapProcessing(mapInfo, parentVar, start, end, creation, updates, source) {
  const mapId = nextMap()
  creation.push(`let ${mapId}_elements = new Map();`)
  const block = []
  block.push(`const ${mapId}_current = ${mapInfo.arrayCode} || [];`)
  block.push(`const ${mapId}_newElements = new Map();`)
  block.push(`const ${mapId}_fragment = _$createDocumentFragment();`)
  block.push(
    `for (let ${mapInfo.secondaryParam} = 0; ${mapInfo.secondaryParam} < ${mapId}_current.length; ${mapInfo.secondaryParam}++) {`,
  )
  block.push(`  const ${mapInfo.primaryParam} = ${mapId}_current[${mapInfo.secondaryParam}];`)
  if (mapInfo.destructureParamCode) {
    block.push(`  ${mapInfo.destructureParamCode}`)
  }
  block.push(
    `  const ${mapInfo.primaryParam}_key = ${mapInfo.primaryParam}?.id ?? ${mapInfo.secondaryParam};`,
  )
  block.push(
    `  let ${mapInfo.primaryParam}_el = ${mapId}_elements.get(${mapInfo.primaryParam}_key);`,
  )
  block.push(`  if (!${mapInfo.primaryParam}_el) {`)
  block.push(
    `    ${mapInfo.primaryParam}_el = ((${parentVar}) instanceof SVGElement) ? _$createElement('g') : _$createElement('span');`,
  )
  block.push(
    `    ${mapInfo.primaryParam}_el.setAttribute('data-key', ${mapInfo.primaryParam}_key);`,
  )
  const jsxNode = getFirstJSX(mapInfo.body)
  if (!jsxNode) {
    const bodyCode0 = exprToCode(mapInfo.body, source)
    const bodyCode = bodyCode0 && bodyCode0.trim() ? bodyCode0 : '""'
    block.push(`    _$settextContent(${mapInfo.primaryParam}_el, String(${bodyCode}));`)
  } else {
    const nested = buildNested(jsxNode, `${mapInfo.primaryParam}_el`, source)
    block.push(...nested.creation.map(line => `    ${line}`))
  }
  block.push(`  }`)
  block.push(`  _$appendChild(${mapId}_fragment, ${mapInfo.primaryParam}_el);`)
  block.push(`  ${mapId}_newElements.set(${mapInfo.primaryParam}_key, ${mapInfo.primaryParam}_el);`)
  block.push(`}`)
  block.push(
    `${mapId}_elements.forEach((el, key) => { if (!${mapId}_newElements.has(key)) { el.remove(); } });`,
  )
  block.push(`${parentVar}.insertBefore(${mapId}_fragment, ${end});`)
  block.push(`${mapId}_elements = ${mapId}_newElements;`)
  creation.push(`_$vaporWatchRun(() => { ${block.join(' ')} });`)
}

function createSimpleMapProcessing(mapInfo, parentVar, start, end, creation, updates, source) {
  const mapId = nextMap()
  creation.push(`let ${mapId}_elements = new Map();`)
  const code0 = exprToCode(mapInfo.body || mapInfo.originalExpr, source)
  const code = code0 && code0.trim() ? code0 : '""'
  const block = []
  block.push(`const ${mapId}_current = ${mapInfo.arrayCode} || [];`)
  block.push(`const ${mapId}_newElements = new Map();`)
  block.push(`const ${mapId}_fragment = _$createDocumentFragment();`)
  block.push(
    `for (let ${mapInfo.secondaryParam} = 0; ${mapInfo.secondaryParam} < ${mapId}_current.length; ${mapInfo.secondaryParam}++) {`,
  )
  block.push(`  const ${mapInfo.primaryParam} = ${mapId}_current[${mapInfo.secondaryParam}];`)
  if (mapInfo.destructureParamCode) {
    block.push(`  ${mapInfo.destructureParamCode}`)
  }
  block.push(
    `  const ${mapInfo.primaryParam}_key = ${mapInfo.primaryParam}?.id ?? ${mapInfo.secondaryParam};`,
  )
  block.push(
    `  let ${mapInfo.primaryParam}_el = ${mapId}_elements.get(${mapInfo.primaryParam}_key);`,
  )
  block.push(`  if (!${mapInfo.primaryParam}_el) {`)
  block.push(
    `    ${mapInfo.primaryParam}_el = ((${parentVar}) instanceof SVGElement) ? _$createElement('text') : _$createElement('span');`,
  )
  block.push(
    `    ${mapInfo.primaryParam}_el.setAttribute('data-key', ${mapInfo.primaryParam}_key);`,
  )
  block.push(`  }`)
  block.push(`  { const __v = (${code}); _$settextContent(${mapInfo.primaryParam}_el, __v); }`)
  block.push(`  _$appendChild(${mapId}_fragment, ${mapInfo.primaryParam}_el);`)
  block.push(`  ${mapId}_newElements.set(${mapInfo.primaryParam}_key, ${mapInfo.primaryParam}_el);`)
  block.push(`}`)
  block.push(
    `${mapId}_elements.forEach((el, key) => { if (!${mapId}_newElements.has(key)) { el.remove(); } });`,
  )
  block.push(`${parentVar}.insertBefore(${mapId}_fragment, ${end});`)
  block.push(`${mapId}_elements = ${mapId}_newElements;`)
  creation.push(`_$vaporWatchRun(() => { ${block.join(' ')} });`)
}

function processGenericExpression(expr, parentVar, creation, updates, source) {
  const spanName = nextSpan()
  creation.push(
    `const ${spanName} = ((${parentVar}) instanceof SVGElement) ? _$createElement('text') : _$createElement('span');`,
  )
  creation.push(`_$appendChild(${parentVar}, ${spanName});`)

  // 静态字面量直接在创建阶段赋值；动态表达式放到更新并加空值/布尔值保护
  if (isStaticEmptyLike(expr)) {
    creation.push(`${spanName}.textContent = '';`)
  } else if (isStaticTextLiteral(expr)) {
    const lit = getStaticTextLiteral(expr)
    creation.push(`${spanName}.textContent = ${lit};`)
  } else {
    const code0 = exprToCode(expr, source)
    const code = code0 && code0.trim() ? code0 : '""'
    creation.push(
      `_$vaporWatchRun(() => { const __val = (${code}); _$settextContent(${spanName}, __val); });`,
    )
  }
}

// 构建完整的 Vapor Block
function buildVaporBlockCode(jsxRoot, source) {
  const isFragment = jsxRoot.type === 'JSXFragment' || jsxRoot.opening?.name?.value === 'Fragment'
  const isComponentRoot =
    jsxRoot.type === 'JSXElement' &&
    (() => {
      const nameNode = jsxRoot.opening?.name
      const nameVal = nameNode && nameNode.value
      return typeof nameVal === 'string' && /^[A-Z]/.test(nameVal) && nameVal !== 'Fragment'
    })()
  const rootName = '_root'

  const creation = []
  const updates = []

  if (isFragment) {
    creation.push(`const ${rootName} = _$createDocumentFragment();`)
    for (const child of jsxRoot.children || []) {
      processChildNode(child, rootName, creation, updates, source, jsxRoot.children, null)
    }
  } else if (isComponentRoot) {
    const start = nextList()
    const end = nextList()
    creation.push(`const ${rootName} = _$createDocumentFragment();`)
    creation.push(`const ${start} = _$createComment('rue:component:start');`)
    creation.push(`const ${end} = _$createComment('rue:component:end');`)
    creation.push(`_$appendChild(${rootName}, ${start});`)
    creation.push(`_$appendChild(${rootName}, ${end});`)
    creation.push(
      `_$vaporWatchRun(() => { renderBetween(${exprToCode(jsxRoot, source)}, ${rootName}, ${start}, ${end}); });`,
    )
    __usesRender = true
  } else {
    creation.push(
      `const ${rootName} = _$createElement(${JSON.stringify(jsxRoot.opening.name.value)});`,
    )
    processAttributes(jsxRoot, rootName, creation, updates, source)
    for (const child of jsxRoot.children || []) {
      processChildNode(
        child,
        rootName,
        creation,
        updates,
        source,
        jsxRoot.children,
        jsxRoot.opening.name.value,
      )
    }
  }

  const lines = [...creation, `return { el: ${rootName} };`]

  return `{\n${lines.join('\n')}\n}`
}

// AST 转换器
function transformAst(program, source) {
  const unwrap = expr => {
    let e = expr
    while (e && typeof e === 'object') {
      if (e.type === 'ParenthesizedExpression') {
        e = e.expression
        continue
      }
      if (
        e.type === 'TsAsExpression' ||
        e.type === 'TSAsExpression' ||
        e.type === 'TsTypeAssertion' ||
        e.type === 'TSTypeAssertion'
      ) {
        e = e.expression
        continue
      }
      break
    }
    return e
  }

  const isJSX = expr => {
    const e = unwrap(expr)
    return !!e && (e.type === 'JSXElement' || e.type === 'JSXFragment')
  }

  const getJSX = expr => unwrap(expr)

  const visit = node => {
    if (!node || typeof node !== 'object') return node

    // 转换 JSX 元素
    if (node.type === 'JSXElement' || node.type === 'JSXFragment') {
      const blockCode = buildVaporBlockCode(node, source)
      const mod = parseSync(`vapor(() => ${blockCode})`, {
        syntax: 'typescript',
        tsx: true,
        target: 'es2020',
      })
      return mod.body[0].expression
    }

    // 转换箭头函数返回 JSX
    if (node.type === 'ArrowFunctionExpression' && node.body && isJSX(node.body)) {
      const blockCode = buildVaporBlockCode(getJSX(node.body), source)
      const mod = parseSync(`vapor(() => ${blockCode})`, {
        syntax: 'typescript',
        tsx: true,
        target: 'es2020',
      })
      const callExpr = mod.body[0].expression
      return { ...node, body: callExpr }
    }

    // 转换 return 语句中的 JSX
    if (node.type === 'ReturnStatement' && node.argument && isJSX(node.argument)) {
      const blockCode = buildVaporBlockCode(getJSX(node.argument), source)
      const mod = parseSync(`vapor(() => ${blockCode})`, {
        syntax: 'typescript',
        tsx: true,
        target: 'es2020',
      })
      const callExpr = mod.body[0].expression
      return { ...node, argument: callExpr }
    }

    // 递归遍历
    for (const k of Object.keys(node)) {
      const v = node[k]
      if (Array.isArray(v)) node[k] = v.map(visit)
      else node[k] = visit(v)
    }
    return node
  }

  return visit(program)
}

// 确保导入必要的运行时函数
function ensureRueImports(program) {
  const body = program.body || []
  const need = new Set([
    'vapor',
    'watchEffect',
    'onBeforeUnmount',
    'h',
    '_$createElement',
    '_$createComment',
    '_$createTextNode',
    '_$setStyle',
    '_$settextContent',
    '_$createDocumentFragment',
    '_$appendChild',
    '_$vaporWatchRun',
  ])
  if (__usesRender) need.add('renderBetween')

  for (const stmt of body) {
    if (
      stmt.type === 'ImportDeclaration' &&
      typeof stmt.source?.value === 'string' &&
      stmt.source.value.includes('rue')
    ) {
      const specifiers = stmt.specifiers || []
      const existingValueNames = specifiers
        .filter(s => s.type === 'ImportSpecifier' && !s.isTypeOnly)
        .map(s => (s.imported?.value ? s.imported.value : s.local?.value))
        .filter(Boolean)
      const existingTypeNames = specifiers
        .filter(s => s.type === 'ImportSpecifier' && s.isTypeOnly)
        .map(s => (s.imported?.value ? s.imported.value : s.local?.value))
        .filter(Boolean)

      const missing = Array.from(need).filter(n => !existingValueNames.includes(n))
      if (missing.length === 0) break

      const valueNames = Array.from(new Set([...existingValueNames, ...missing]))
      const typeNames = Array.from(new Set(existingTypeNames))
      const mergedParts = [...typeNames.map(n => `type ${n}`), ...valueNames]
      const importCode = `import { ${mergedParts.join(', ')} } from '${stmt.source.value}';`
      const mod = parseSync(importCode, {
        syntax: 'typescript',
        tsx: true,
        target: 'es2020',
      })
      stmt.specifiers = mod.body[0].specifiers
      break
    }
  }
  return program
}

// 主转换函数
export function transformSource(code) {
  __elId = 0
  __spanId = 0
  __listId = 0
  __mapId = 0
  __usesRender = false

  const ast = parseSync(code, {
    syntax: 'typescript',
    tsx: true,
    comments: true,
    target: 'es2020',
  })

  let nextAst = transformAst(ast, code)
  // 移除基于 AST 的导入处理（ensureRueImports）
  nextAst = ensureRueImports(nextAst)
  const { code: out } = printSync(nextAst, { minify: false })

  return '/* RUE_VAPOR_TRANSFORMED */\n' + out
}

export default transformSource

// 顶层辅助函数（基于 unwrapExpr）
const isStaticEmptyLike = expr => {
  const e = unwrapExpr(expr)
  if (!e || typeof e !== 'object') return false
  if (e.type === 'NullLiteral') return true
  if (e.type === 'BooleanLiteral') return true
  if (e.type === 'Identifier' && e.value === 'undefined') return true
  if (e.type === 'UnaryExpression' && e.operator === 'void') return true // void 0
  return false
}

const isStaticTextLiteral = expr => {
  const e = unwrapExpr(expr)
  if (!e || typeof e !== 'object') return false
  if (e.type === 'StringLiteral') return true
  if (e.type === 'NumericLiteral') return true
  return false
}

const getStaticTextLiteral = expr => {
  const e = unwrapExpr(expr)
  // 返回适合放进模板字符串中的字面量串（已正确转义）
  if (!e || typeof e !== 'object') return null
  if (e.type === 'StringLiteral') return JSON.stringify(e.value)
  if (e.type === 'NumericLiteral') return JSON.stringify(String(e.value))
  if (isStaticEmptyLike(e)) return JSON.stringify('')
  return null
}