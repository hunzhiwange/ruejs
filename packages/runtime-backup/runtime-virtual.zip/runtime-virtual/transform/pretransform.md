import swc from '@swc/core'
const { parseSync, printSync } = swc

const isJSXElement = n => n && typeof n === 'object' && n.type === 'JSXElement'
const isJSXFragment = n => n && typeof n === 'object' && n.type === 'JSXFragment'

const getAttrName = name => {
  if (!name) return ''
  if (name.type === 'Identifier') return name.value
  if (name.type === 'JSXIdentifier') return name.value
  if (name.type === 'JSXNamespacedName') return `${name.namespace.value}:${name.name.value}`
  return name.value || ''
}

const getAttrValueExpr = node => {
  if (!node) return null
  if (node.type === 'StringLiteral') return node
  if (node.type === 'JSXExpressionContainer') return node.expression
  return null
}

const removeAttrsByNames = (opening, names) => {
  opening.attributes = (opening.attributes || []).filter(a => {
    if (a.type !== 'JSXAttribute') return true
    const n = getAttrName(a.name)
    return !names.includes(n)
  })
}

const pushAttr = (opening, name, valueExpr) => {
  opening.attributes = opening.attributes || []
  opening.attributes.push({
    type: 'JSXAttribute',
    name: { type: 'JSXIdentifier', value: name },
    value: valueExpr ? { type: 'JSXExpressionContainer', expression: valueExpr } : undefined,
  })
}

const makeObjectExpr = obj => ({ type: 'ObjectExpression', properties: obj })
const makeProp = (key, value) => ({
  type: 'KeyValueProperty',
  key: { type: 'Identifier', value: key },
  value,
})

const makeConditional = (test, consExpr, altExpr) => ({
  type: 'ConditionalExpression',
  test,
  consequent: consExpr,
  alternate: altExpr,
})

const wrapInJSXExpr = expr => ({ type: 'JSXExpressionContainer', expression: expr })

const cloneNode = node => JSON.parse(JSON.stringify(node))

const rewriteVHtml = el => {
  const opening = el.opening
  const attrs = opening.attributes || []
  const a = attrs.find(
    x => x.type === 'JSXAttribute' && ['vHtml', 'v-html'].includes(getAttrName(x.name)),
  )
  if (!a) return false
  const expr = getAttrValueExpr(a.value)
  if (!expr) return false
  const inner = exprToCode(expr)
  const parsedAttrAst = parseSync(
    `const __v = <div dangerouslySetInnerHTML={{ __html: ${inner} }} />;`,
    { syntax: 'typescript', tsx: true, target: 'es2020' },
  )
  const newAttr = parsedAttrAst.body[0].declarations[0].init.opening.attributes[0]
  a.name = newAttr.name
  a.value = newAttr.value
  el.children = []
  return true
}

const rewriteVShow = el => {
  const opening = el.opening
  const attrs = opening.attributes || []
  const a = attrs.find(
    x => x.type === 'JSXAttribute' && ['vShow', 'v-show'].includes(getAttrName(x.name)),
  )
  if (!a) return false
  const cond = getAttrValueExpr(a.value)
  if (!cond) return false
  const condCode = exprToCode(cond)
  const existingStyle = attrs.find(
    x => x.type === 'JSXAttribute' && getAttrName(x.name) === 'style',
  )
  let newAttr
  if (existingStyle) {
    const styleVal = existingStyle.value
    // Build a unified style expression that respects original style (string or object)
    let styleExprCode
    if (styleVal && styleVal.type === 'StringLiteral') {
      const sCode = exprToCode(styleVal)
      styleExprCode = `((${condCode}) ? (${sCode}) : ((${sCode}) + '; display: none'))`
    } else if (styleVal && styleVal.type === 'JSXExpressionContainer') {
      const sExpr = styleVal.expression
      const sCode = exprToCode(sExpr)
      styleExprCode = `((typeof (${sCode}) === 'string') ? ((${condCode}) ? (${sCode}) : ((${sCode}) + '; display: none')) : ({ ...(${sCode}), display: ((${condCode})) ? '' : 'none' }))`
    } else {
      // Unknown style, treat as empty string
      styleExprCode = `((${condCode}) ? '' : 'display: none')`
    }
    const parsedAttrAst = parseSync(`const __v = <div style={${styleExprCode}} />;`, {
      syntax: 'typescript',
      tsx: true,
      target: 'es2020',
    })
    newAttr = parsedAttrAst.body[0].declarations[0].init.opening.attributes[0]
    // Remove original style to avoid duplicate keys
    opening.attributes = (opening.attributes || []).filter(x => x !== existingStyle)
  } else {
    const parsedAttrAst = parseSync(
      `const __v = <div style={{ display: (${condCode}) ? "" : "none" }} />;`,
      { syntax: 'typescript', tsx: true, target: 'es2020' },
    )
    newAttr = parsedAttrAst.body[0].declarations[0].init.opening.attributes[0]
  }
  a.name = newAttr.name
  a.value = newAttr.value
  return true
}

const rewriteVModel = el => {
  const opening = el.opening
  const tagName = getAttrName(opening.name)
  const attrs = opening.attributes || []
  const a = attrs.find(
    x => x.type === 'JSXAttribute' && ['vModel', 'v-model'].includes(getAttrName(x.name)),
  )
  if (!a) return false
  const modelExpr = getAttrValueExpr(a.value)
  if (!modelExpr) return false
  removeAttrsByNames(opening, ['vModel', 'v-model'])
  const isInput = typeof tagName === 'string' && tagName.toLowerCase() === 'input'
  const isTextarea = typeof tagName === 'string' && tagName.toLowerCase() === 'textarea'
  const isSelect = typeof tagName === 'string' && tagName.toLowerCase() === 'select'
  const typeAttr = attrs.find(x => x.type === 'JSXAttribute' && getAttrName(x.name) === 'type')
  const typeValue =
    typeAttr && typeAttr.value && typeAttr.value.type === 'StringLiteral'
      ? typeAttr.value.value
      : null
  if (isInput && (typeValue === 'checkbox' || typeValue === 'radio')) {
    pushAttr(opening, 'checked', {
      type: 'MemberExpression',
      object: modelExpr,
      property: { type: 'Identifier', value: 'value' },
    })
    pushAttr(opening, 'onChange', {
      type: 'ArrowFunctionExpression',
      params: [{ type: 'Identifier', value: 'e' }],
      body: {
        type: 'AssignmentExpression',
        operator: '=',
        left: {
          type: 'MemberExpression',
          object: modelExpr,
          property: { type: 'Identifier', value: 'value' },
        },
        right: {
          type: 'MemberExpression',
          object: {
            type: 'MemberExpression',
            object: { type: 'Identifier', value: 'e' },
            property: { type: 'Identifier', value: 'target' },
          },
          property: { type: 'Identifier', value: 'checked' },
        },
      },
    })
    return true
  }
  if (isInput || isTextarea || isSelect) {
    pushAttr(opening, 'value', {
      type: 'MemberExpression',
      object: modelExpr,
      property: { type: 'Identifier', value: 'value' },
    })
    const eventName = isSelect ? 'onChange' : 'onInput'
    pushAttr(opening, eventName, {
      type: 'ArrowFunctionExpression',
      params: [{ type: 'Identifier', value: 'e' }],
      body: {
        type: 'AssignmentExpression',
        operator: '=',
        left: {
          type: 'MemberExpression',
          object: modelExpr,
          property: { type: 'Identifier', value: 'value' },
        },
        right: {
          type: 'MemberExpression',
          object: {
            type: 'MemberExpression',
            object: { type: 'Identifier', value: 'e' },
            property: { type: 'Identifier', value: 'target' },
          },
          property: { type: 'Identifier', value: 'value' },
        },
      },
    })
    return true
  }
  return false
}

const stripDirectiveAttrs = el => {
  const opening = el.opening
  removeAttrsByNames(opening, ['vIf', 'v-if', 'vElseIf', 'v-else-if', 'vElse', 'v-else'])
}

const buildConditionalJSX = chain => {
  const parts = []
  for (let i = 0; i < chain.length; i++) {
    const item = chain[i]
    stripDirectiveAttrs(item.el)
    const testCode = item.test ? exprToCode(item.test) : 'true'
    const jsxCode = exprToCode(item.el)
    parts.push({ testCode, jsxCode })
  }
  const buildCode = idx => {
    const p = parts[idx]
    if (idx === parts.length - 1) return `((${p.testCode}) ? (${p.jsxCode}) : (null))`
    return `((${p.testCode}) ? (${p.jsxCode}) : ${buildCode(idx + 1)})`
  }
  const code = buildCode(0)
  const ast = parseSync(`const __v = ${code};`, {
    syntax: 'typescript',
    tsx: true,
    target: 'es2020',
  })
  const expr = ast.body[0].declarations[0].init
  return { type: 'JSXExpressionContainer', expression: expr }
}

const collectDirectiveChain = (siblings, startIdx) => {
  const chain = []
  for (let i = startIdx; i < siblings.length; i++) {
    const n = siblings[i]
    if (!isJSXElement(n)) break
    const attrs = n.opening.attributes || []
    const hasIf = attrs.find(
      a => a.type === 'JSXAttribute' && ['vIf', 'v-if'].includes(getAttrName(a.name)),
    )
    const hasElseIf = attrs.find(
      a => a.type === 'JSXAttribute' && ['vElseIf', 'v-else-if'].includes(getAttrName(a.name)),
    )
    const hasElse = attrs.find(
      a => a.type === 'JSXAttribute' && ['vElse', 'v-else'].includes(getAttrName(a.name)),
    )
    if (i === startIdx && !hasIf) break
    if (hasIf) {
      const testExpr = getAttrValueExpr(hasIf.value)
      let parsedFalse = null
      if (!testExpr) {
        const tAst = parseSync('const __t = false;', {
          syntax: 'typescript',
          tsx: true,
          target: 'es2020',
        })
        parsedFalse = tAst.body[0].declarations[0].init
      }
      chain.push({ el: n, test: testExpr || parsedFalse })
      continue
    }
    if (hasElseIf) {
      const testExpr = getAttrValueExpr(hasElseIf.value)
      let parsedFalse = null
      if (!testExpr) {
        const tAst = parseSync('const __t = false;', {
          syntax: 'typescript',
          tsx: true,
          target: 'es2020',
        })
        parsedFalse = tAst.body[0].declarations[0].init
      }
      chain.push({ el: n, test: testExpr || parsedFalse })
      continue
    }
    if (hasElse) {
      chain.push({ el: n, test: null })
      continue
    }
    break
  }
  return chain
}

const rewriteIfChainsInChildren = children => {
  const out = []
  for (let i = 0; i < children.length; i++) {
    const n = children[i]
    if (isJSXElement(n)) {
      const attrs = n.opening.attributes || []
      const hasIf = attrs.find(
        a => a.type === 'JSXAttribute' && ['vIf', 'v-if'].includes(getAttrName(a.name)),
      )
      if (hasIf) {
        const chain = collectDirectiveChain(children, i)
        const replaced = buildConditionalJSX(chain)
        out.push(replaced)
        i += chain.length - 1
        continue
      }
    }
    out.push(n)
  }
  return out
}

const memoizeLiteralsInProps = el => {
  return false
}

const ensureUseMemoImport = program => {
  let hasImport = false
  for (const stmt of program.body) {
    if (
      stmt.type === 'ImportDeclaration' &&
      stmt.source &&
      (stmt.source.value === 'rue-js' || stmt.source.value === '@rue')
    ) {
      const spec = stmt.specifiers || []
      const found = spec.find(
        s =>
          s.type === 'ImportSpecifier' &&
          s.imported &&
          ((s.imported.type === 'Identifier' && s.imported.value === 'useMemo') ||
            s.imported.value === 'useMemo'),
      )
      if (found) {
        hasImport = true
        break
      }
      // append useMemo
      spec.push({
        type: 'ImportSpecifier',
        local: { type: 'Identifier', value: 'useMemo' },
        imported: { type: 'Identifier', value: 'useMemo' },
      })
      stmt.specifiers = spec
      hasImport = true
      break
    }
  }
  if (!hasImport) {
    program.body.unshift({
      type: 'ImportDeclaration',
      source: { type: 'StringLiteral', value: 'rue-js' },
      specifiers: [
        {
          type: 'ImportSpecifier',
          local: { type: 'Identifier', value: 'useMemo' },
          imported: { type: 'Identifier', value: 'useMemo' },
        },
      ],
    })
  }
}

const traverseJSX = node => {
  if (!node || typeof node !== 'object') return { changed: false, needMemoImport: false }
  let changed = false
  let needMemoImport = false
  const visit = n => {
    if (!n || typeof n !== 'object') return
    if (isJSXElement(n)) {
      if (rewriteVHtml(n)) changed = true
      if (rewriteVShow(n)) changed = true
      if (rewriteVModel(n)) changed = true
      const memoNeeded = memoizeLiteralsInProps(n)
      if (memoNeeded) {
        changed = true
        needMemoImport = true
      }
      if (Array.isArray(n.children) && n.children.length) {
        const replaced = rewriteIfChainsInChildren(n.children)
        if (replaced !== n.children) {
          n.children = replaced
          changed = true
        }
        n.children.forEach(c => visit(c))
      }
    } else if (isJSXFragment(n)) {
      if (Array.isArray(n.children) && n.children.length) {
        n.children.forEach(c => visit(c))
      }
    } else {
      for (const k of Object.keys(n)) {
        const v = n[k]
        if (Array.isArray(v)) v.forEach(visit)
        else visit(v)
      }
    }
  }
  visit(node)
  return { changed, needMemoImport }
}

export function pretransformSource(code) {
  const ast = parseSync(code, { syntax: 'typescript', tsx: true, target: 'es2020', comments: true })
  const repls = []
  const collectChains = children => {
    for (let i = 0; i < children.length; i++) {
      const n = children[i]
      if (isJSXElement(n)) {
        const attrs = n.opening.attributes || []
        const hasIf = attrs.find(
          a => a.type === 'JSXAttribute' && ['vIf', 'v-if'].includes(getAttrName(a.name)),
        )
        if (hasIf) {
          const chain = collectDirectiveChain(children, i)
          const start = children[i].span.start
          const end = children[i + chain.length - 1].span.end
          const parts = []
          for (let j = 0; j < chain.length; j++) {
            const item = chain[j]
            stripDirectiveAttrs(item.el)
            const testCode = item.test ? exprToCode(item.test) : 'true'
            const jsxCode = exprToCode(item.el)
            parts.push({ testCode, jsxCode })
          }
          const buildCode = idx => {
            const p = parts[idx]
            if (idx === parts.length - 1) return `((${p.testCode}) ? (${p.jsxCode}) : (null))`
            return `((${p.testCode}) ? (${p.jsxCode}) : ${buildCode(idx + 1)})`
          }
          const codeExpr = `{${buildCode(0)}}`
          repls.push({ start, end, code: codeExpr })
          i += chain.length - 1
          continue
        }
      }
      if (isJSXElement(n) || isJSXFragment(n)) {
        const kids = n.children || []
        if (kids.length) collectChains(kids)
      }
    }
  }
  collectChains(ast.body?.[0]?.expression?.arguments?.[0]?.children || [])
  if (repls.length > 0) {
    let out = ''
    let cursor = 0
    const sorted = repls.sort((a, b) => a.start - b.start)
    for (const r of sorted) {
      out += code.slice(cursor, r.start)
      out += r.code
      cursor = r.end
    }
    out += code.slice(cursor)
    return out
  }
  const { changed, needMemoImport } = traverseJSX(ast)
  if (!changed) return null
  let out = printSync(ast, { minify: false }).code
  if (needMemoImport) {
    const has = /import\s*\{[^}]*useMemo[^}]*\}\s*from\s*['"](@rue|rue-js)['"]/m.test(code)
    if (!has) out = `import { useMemo } from 'rue-js';\n` + out
  }
  return out
}

export default pretransformSource

function exprToCode(node) {
  try {
    const wrapper = parseSync('const __x = 0;', {
      syntax: 'typescript',
      tsx: true,
      target: 'es2020',
    })
    // replace initializer with given node
    wrapper.body[0].declarations[0].init = node
    const out = printSync(wrapper, { minify: false }).code.trim()
    return out.replace(/^const __x =\s*/, '').replace(/;$/, '')
  } catch {
    return ''
  }
}