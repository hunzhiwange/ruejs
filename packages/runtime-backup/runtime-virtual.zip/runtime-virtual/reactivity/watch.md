import { cleanup, effect } from './core'

export interface Signal<T = any> {
  value: T
}
export interface WatchOptions {
  immediate?: boolean
  deep?: boolean
}
export interface WatchStopHandle {
  (): void
}

export function watch<T>(
  source: (() => T) | Signal<T>,
  callback: (newValue: T, oldValue: T) => void,
  options: WatchOptions = {},
): WatchStopHandle {
  const get: () => T =
    typeof source === 'function' ? (source as () => T) : () => (source as Signal<T>).value

  let oldValue: T
  let firstRun = true

  const runner = effect(() => {
    const newValue = get()
    if (firstRun) {
      oldValue = newValue as T
      firstRun = false
      if (options.immediate) callback(newValue, newValue)
    } else {
      if (options.deep || newValue !== oldValue) {
        callback(newValue, oldValue)
        oldValue = newValue
      }
    }
  })

  return () => {
    ;(runner as any).active = false
    cleanup(runner)
  }
}

export function watchEffect(
  fn: () => void,
  options: { scheduler?: () => void } = {},
): WatchStopHandle {
  const runner = effect(fn, { lazy: false, scheduler: options.scheduler })
  return () => {
    ;(runner as any).active = false
    cleanup(runner)
  }
}