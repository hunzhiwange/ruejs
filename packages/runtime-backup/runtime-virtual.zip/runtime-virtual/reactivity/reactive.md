import { getCurrentInstance } from './context'
import { ITERATE_KEY, type ReactiveTarget, track, trigger } from './core'

export const IS_REACTIVE = Symbol('rue-reactive')
export const IS_REF = Symbol('rue-ref')
export const IS_COMPUTED = Symbol('rue-computed')

const reactiveCache = new WeakMap<object, any>()
const readonlyReactiveCache = new WeakMap<object, any>()

function createProxyHandlers(isReadonly: boolean, shallow: boolean) {
  return {
    get(t: ReactiveTarget, key: string | symbol, receiver: any) {
      const res = Reflect.get(t, key, receiver)
      track(t, key)
      if (!shallow && Array.isArray(t)) {
        if (key === Symbol.iterator) track(t, ITERATE_KEY)
        else if (key === 'length') track(t, ITERATE_KEY)
        else if (
          key === 'map' ||
          key === 'forEach' ||
          key === 'filter' ||
          key === 'reduce' ||
          key === 'some' ||
          key === 'every' ||
          key === 'find' ||
          key === 'findIndex' ||
          key === 'entries' ||
          key === 'keys' ||
          key === 'values'
        ) {
          track(t, ITERATE_KEY)
        }
      }
      if (!shallow && res && typeof res === 'object' && !isReadonly) {
        const nestedCache = readonlyReactiveCache
        const normalCache = reactiveCache
        const nestedExisting =
          (normalCache.get(res as any) as any) ?? (nestedCache.get(res as any) as any)
        if (nestedExisting) return nestedExisting
        return createReactive(res as any, false)
      }
      return res
    },
    set(t: ReactiveTarget, key: string | symbol, value: any, receiver: any) {
      const oldValue = (t as any)[key]
      const r = Reflect.set(t, key, value, receiver)
      if (!Object.is(oldValue, value)) {
        trigger(t, key)
        if (Array.isArray(t) && (key === 'length' || typeof key === 'string')) {
          trigger(t, ITERATE_KEY)
        }
      }
      return r
    },
  }
}

// Deep reactive proxy
export function createReactive<T extends object>(target: T, isReadonly: boolean): T {
  const cache = isReadonly ? readonlyReactiveCache : reactiveCache
  const existing = cache.get(target as any)
  if (existing) return existing
  const proxy = new Proxy(target as any, createProxyHandlers(isReadonly, false)) as T

  ;(proxy as any)[IS_REACTIVE] = true
  cache.set(target as any, proxy)
  return proxy
}

// Shallow reactive proxy
export function createShallowReactive<T extends object>(target: T): T {
  return new Proxy(target as any, createProxyHandlers(false, true)) as T
}

// Public APIs with hook-slot persistence inside components
export function reactive<T extends object>(target: T): T {
  const inst = getCurrentInstance() as any
  if (inst) {
    const hooks = inst.__hooks || (inst.__hooks = { states: [], index: 0 })
    const forced = (hooks as any).__forcedIndex
    const i = typeof forced === 'number' ? forced : hooks.index++
    if (typeof forced === 'number') (hooks as any).__forcedIndex = undefined
    if (hooks.states[i] === undefined) {
      hooks.states[i] = createReactive(target, false)
    }
    return hooks.states[i] as T
  }
  return createReactive(target, false)
}

export function ref<T = any>(value: T): { value: T } {
  const inst = getCurrentInstance() as any
  if (inst) {
    const hooks = inst.__hooks || (inst.__hooks = { states: [], index: 0 })
    const forced = (hooks as any).__forcedIndex
    const i = typeof forced === 'number' ? forced : hooks.index++
    if (typeof forced === 'number') (hooks as any).__forcedIndex = undefined
    if (hooks.states[i] === undefined) {
      hooks.states[i] = createReactive({ value }, false)
    }
    const p = hooks.states[i] as { value: T }
    ;(p as any)[IS_REF] = true
    return p
  }
  const p = createReactive({ value }, false) as { value: T }
  ;(p as any)[IS_REF] = true
  return p
}

export function toValue<T = any>(x: any): T {
  if (typeof x === 'function') return (x as any)()
  if (x && typeof x === 'object') {
    const desc = Object.getOwnPropertyDescriptor(x, 'value')
    if (desc && typeof desc.get === 'function') return (x as any).value
    if (x[IS_REF] === true || x[IS_COMPUTED] === true) return (x as any).value
  }
  return x as T
}

export function createShallowProxyFrom<T extends object>(
  getCurrent: () => any,
  setNext: (next: any) => void,
  peekCurrent?: () => any,
): T {
  const target: any = {}
  const proxy = new Proxy(target, {
    get(_t, key) {
      const cur = getCurrent()
      return Reflect.get(cur as any, key)
    },
    set(_t, key, value) {
      const cur = getCurrent()
      const next = Array.isArray(cur) ? cur.slice() : { ...(cur as any) }
      Reflect.set(next as any, key, value)
      setNext(next)
      return true
    },
    ownKeys() {
      const cur = peekCurrent ? peekCurrent() : getCurrent()
      return Reflect.ownKeys(cur as any)
    },
    getOwnPropertyDescriptor(_t, key) {
      const cur = peekCurrent ? peekCurrent() : getCurrent()
      const desc = Object.getOwnPropertyDescriptor(cur as any, key as any)
      if (desc) desc.configurable = true
      return desc
    },
    has(_t, key) {
      const cur = peekCurrent ? peekCurrent() : getCurrent()
      return Reflect.has(cur as any, key)
    },
  })
  return proxy as T
}