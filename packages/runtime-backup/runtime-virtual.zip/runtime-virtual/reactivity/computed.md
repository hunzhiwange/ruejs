import { effect, track, trigger } from './core'
import { createReactive, IS_COMPUTED } from './reactive'

export function computed<T>(getter: () => T): { readonly value: T } {
  const result = createReactive<{ value: T }>({ value: undefined as unknown as T }, false) as {
    value: T
  }
  let dirty = true
  let value: T

  const runner = effect(
    () => {
      value = getter()
      dirty = false
    },
    {
      lazy: true,
      scheduler: () => {
        if (!dirty) {
          dirty = true
          trigger(result as any, 'value')
        }
      },
    },
  )

  Object.defineProperty(result, 'value', {
    get() {
      if (dirty) runner()
      track(result as any, 'value')
      return value
    },
  })

  ;(result as any)[IS_COMPUTED] = true
  return result as { readonly value: T }
}