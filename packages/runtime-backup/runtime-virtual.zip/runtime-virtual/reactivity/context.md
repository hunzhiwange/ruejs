// Component instance context for reactivity to access hook slots
export type HookHost = { __hooks?: { states: any[]; index: number } } | null

let currentInstance: HookHost = null

import * as wasm from '../wasm'

export function setCurrentInstance(i: HookHost) {
  currentInstance = i
  try {
    ;(wasm as any).set_current_instance?.(i as any)
  } catch {}
}

export function getCurrentInstance(): HookHost {
  return currentInstance
}