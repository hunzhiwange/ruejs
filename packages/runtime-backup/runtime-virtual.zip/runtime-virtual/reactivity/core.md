// Core reactive engine: dependency graph, effects, scheduling

export interface ReactiveEffect {
  (): void
  deps: Set<ReactiveEffect>[]
  active: boolean
  scheduler?: () => void
}

export type ReactiveTarget = Record<string | symbol, any>

export const ITERATE_KEY = Symbol('rue-iterate')

// Global state for the reactive engine
const targetMap: WeakMap<ReactiveTarget, Map<string | symbol, Set<ReactiveEffect>>> = new WeakMap()
let activeEffect: ReactiveEffect | null = null
const effectStack: ReactiveEffect[] = []
let batchDepth = 0
const pendingEffects: Set<ReactiveEffect> = new Set()

export function track(target: ReactiveTarget, key: string | symbol): void {
  if (!activeEffect) return
  let depsMap = targetMap.get(target)
  if (!depsMap) {
    targetMap.set(target, (depsMap = new Map()))
  }
  let dep = depsMap.get(key)
  if (!dep) {
    depsMap.set(key, (dep = new Set()))
  }
  trackEffects(dep)
}

function trackEffects(dep: Set<ReactiveEffect>): void {
  if (!activeEffect) return
  dep.add(activeEffect)
  activeEffect.deps.push(dep)
}

export function trigger(target: ReactiveTarget, key: string | symbol): void {
  if (batchDepth > 0) {
    const depsMap = targetMap.get(target)
    if (!depsMap) return
    const dep = depsMap.get(key)
    if (dep) dep.forEach(effect => pendingEffects.add(effect))
    return
  }
  triggerDirect(target, key)
}

function triggerDirect(target: ReactiveTarget, key: string | symbol): void {
  const depsMap = targetMap.get(target)
  if (!depsMap) return
  const dep = depsMap.get(key)
  if (dep) triggerEffects(dep)
}

function triggerEffects(dep: Set<ReactiveEffect>): void {
  const effects = new Set(dep)
  effects.forEach(effect => {
    if (effect !== activeEffect) {
      if (effect.scheduler) effect.scheduler()
      else effect()
    }
  })
}

export function effect(
  fn: () => void,
  options: { lazy?: boolean; scheduler?: () => void } = {},
): ReactiveEffect {
  const effectFn: ReactiveEffect = (() => {
    cleanup(effectFn)
    effectStack.push(effectFn)
    activeEffect = effectFn
    try {
      return fn()
    } finally {
      effectStack.pop()
      activeEffect = effectStack[effectStack.length - 1] || null
    }
  }) as ReactiveEffect

  effectFn.deps = []
  effectFn.active = true
  effectFn.scheduler = options.scheduler

  if (!options.lazy) effectFn()
  return effectFn
}

export function cleanup(effectFn: ReactiveEffect): void {
  effectFn.deps.forEach(dep => dep.delete(effectFn))
  effectFn.deps.length = 0
}

export function batch(fn: () => void): void {
  batchDepth++
  try {
    fn()
  } finally {
    batchDepth--
    if (batchDepth === 0) flushPendingEffects()
  }
}

function flushPendingEffects(): void {
  const effects = new Set(pendingEffects)
  pendingEffects.clear()
  effects.forEach(effect => {
    if (effect.scheduler) effect.scheduler()
    else effect()
  })
}