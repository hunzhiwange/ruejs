import { afterEach, describe, expect, it } from 'vitest'
import { h, renderBetween, vapor, render } from '../src'
import { ref, watchEffect } from '../src/reactivity'

afterEach(() => {
  document.body.innerHTML = ''
})

function elementsBetween(start: Comment, end: Comment): HTMLElement[] {
  const out: HTMLElement[] = []
  let n: Node | null = start.nextSibling
  while (n && n !== end) {
    if (n.nodeType === 1) out.push(n as HTMLElement)
    n = (n as any).nextSibling
  }
  return out
}

describe('renderBetween vapor conditional updates', () => {
  it('replaces previous vapor fragment with new vapor fragment', () => {
    const parent = document.createElement('div')
    const start = document.createComment('rue:slot:start')
    const end = document.createComment('rue:slot:end')
    parent.appendChild(start)
    parent.appendChild(end)

    const first = vapor(() => {
      const frag = document.createDocumentFragment()
      const a1 = document.createElement('span')
      a1.id = 'A1'
      const a2 = document.createElement('span')
      a2.id = 'A2'
      frag.appendChild(a1)
      frag.appendChild(a2)
      return { vaporElement: frag }
    })
    renderBetween(first, parent, start, end)
    let els = elementsBetween(start, end)
    expect(els.map(e => e.id)).toEqual(['A1', 'A2'])

    const second = vapor(() => {
      const frag = document.createDocumentFragment()
      const b1 = document.createElement('span')
      b1.id = 'B1'
      frag.appendChild(b1)
      return { vaporElement: frag }
    })
    renderBetween(second, parent, start, end)
    els = elementsBetween(start, end)
    expect(els.map(e => e.id)).toEqual(['B1'])
    expect(parent.querySelector('#A1')).toBeNull()
    expect(parent.querySelector('#A2')).toBeNull()
  })

  it('multiple toggles keep only latest vapor content and anchors', () => {
    const parent = document.createElement('div')
    const start = document.createComment('rue:slot:start')
    const end = document.createComment('rue:slot:end')
    parent.appendChild(start)
    parent.appendChild(end)

    const make = (id: string) =>
      vapor(() => {
        const frag = document.createDocumentFragment()
        const s = document.createElement('span')
        s.id = id
        frag.appendChild(s)
        return { vaporElement: frag }
      })

    renderBetween(make('X'), parent, start, end)
    renderBetween(make('Y'), parent, start, end)
    renderBetween(make('Z'), parent, start, end)

    const els = elementsBetween(start, end)
    expect(els.map(e => e.id)).toEqual(['Z'])
    expect(parent.contains(end)).toBe(true)
  })

  it('updates between anchors driven by ref + watchEffect', () => {
    const parent = document.createElement('div')
    const start = document.createComment('rue:slot:start')
    const end = document.createComment('rue:slot:end')
    parent.appendChild(start)
    parent.appendChild(end)

    const show = ref(true)

    watchEffect(() => {
      const vnode = show.value
        ? vapor(() => {
            const frag = document.createDocumentFragment()
            const hi = document.createElement('span')
            hi.id = 'HI'
            hi.textContent = '高级'
            frag.appendChild(hi)
            return { vaporElement: frag }
          })
        : vapor(() => {
            const frag = document.createDocumentFragment()
            const lo = document.createElement('span')
            lo.id = 'LO'
            lo.textContent = '普通'
            frag.appendChild(lo)
            return { vaporElement: frag }
          })
      renderBetween(vnode, parent, start, end)
    })

    const ids = () => elementsBetween(start, end).map(e => e.id)
    expect(ids()).toEqual(['HI'])
    show.value = false
    expect(ids()).toEqual(['LO'])
    show.value = true
    expect(ids()).toEqual(['HI'])
    expect(parent.contains(start)).toBe(true)
    expect(parent.contains(end)).toBe(true)
  })
})

describe('fragment keyed children', () => {
  it('nested fragment keyed reorder maintains order', async () => {
    const container = document.createElement('div')
    const makeItem = (id: string) =>
      h('li', { key: id }, [
        h('span', { key: id + ':inner' }, [id]),
        h('fragment', { key: id + ':frag' }, [h('b', { key: id + ':b' }, ['!'])]),
      ])
    const view = (ids: string[]) => h('ul', {}, ids.map(makeItem))
    render(view(['A', 'B', 'C', 'D']), container)
    const before = Array.from(container.querySelectorAll('li')).map(el => el.textContent)
    expect(before).toEqual(['A!', 'B!', 'C!', 'D!'])
    render(view(['C', 'A', 'D', 'B']), container)
    const after = Array.from(container.querySelectorAll('li')).map(el => el.textContent)
    expect(after).toEqual(['C!', 'A!', 'D!', 'B!'])
  })
})

describe('large keyed list move count (Wasm LIS)', () => {
  it('reduces moves with LIS optimization', async () => {
    const container = document.createElement('div')
    const N = 50
    const make = (n: number) => h('li', { key: n }, [String(n)])
    const view = (arr: number[]) => h('ul', {}, arr.map(make))
    const first = Array.from({ length: N }, (_, i) => i + 1)
    render(view(first), container)
    const second = [
      // create a pattern with a long LIS to minimize moves
      ...first.filter(n => n % 2 === 0), // evens in order
      ...first.filter(n => n % 2 === 1), // odds in order
    ]
    let moveCount = 0
    const origInsertBefore = Node.prototype.insertBefore
    // count moves of existing nodes (exclude comment insertions)
    ;(Node.prototype.insertBefore as any) = function (this: Node, node: Node, ref: Node | null) {
      if (node.nodeType !== 8 /* Comment */ && (node as any).__initial) {
        moveCount++
      }
      return origInsertBefore.call(this, node, ref)
    }
    // mark initial nodes
    Array.from(container.querySelectorAll('li')).forEach(el => ((el as any).__initial = true))
    render(view(second), container)
    ;(Node.prototype.insertBefore as any) = origInsertBefore
    const lisLength = N // evens then odds keeps two LIS segments each internally ordered; global LIS equals length of evens (N/2)
    // Expected moves <= N - N/2
    expect(moveCount).toBeLessThanOrEqual(N - Math.floor(N / 2))
    const order = Array.from(container.querySelectorAll('li')).map(el => Number(el.textContent))
    expect(order).toEqual(second)
  })
})

describe('event replacement and removal', () => {
  it('replaces onClick and removes when missing', async () => {
    const container = document.createElement('div')
    let a = 0
    let b = 0
    const viewA = h('button', { onClick: () => a++ }, ['X'])
    render(viewA, container)
    const btn = container.querySelector('button')!
    btn.click()
    expect(a).toBe(1)
    expect(b).toBe(0)
    const viewB = h('button', { onClick: () => b++ }, ['X'])
    render(viewB, container)
    btn.click()
    expect(a).toBe(1)
    expect(b).toBe(1)
    const viewNone = h('button', {}, ['X'])
    render(viewNone, container)
    btn.click()
    expect(a).toBe(1)
    expect(b).toBe(1)
  })
})

describe('dangerouslySetInnerHTML vs children toggle', () => {
  it('switches mutually between innerHTML and children', async () => {
    const container = document.createElement('div')
    const htmlView = h('div', { dangerouslySetInnerHTML: { __html: '<span id="A">A</span>' } }, [])
    render(htmlView, container)
    expect(container.querySelector('#A')?.textContent).toBe('A')
    const childrenView = h('div', {}, [h('span', { id: 'B' }, ['B'])])
    render(childrenView, container)
    expect(container.querySelector('#A')).toBeNull()
    expect(container.querySelector('#B')?.textContent).toBe('B')
    const backHtmlView = h('div', { dangerouslySetInnerHTML: { __html: '<i id="C">C</i>' } }, [])
    render(backHtmlView, container)
    expect(container.querySelector('#B')).toBeNull()
    expect(container.querySelector('#C')?.textContent).toBe('C')
  })
})
