import { describe, it, expect } from 'vitest'
import { render, h, Fragment } from 'rue-js'

const makeNode = (key: string, text: string) => h('div', { key, className: 'item' }, text)

describe('e2e: nested fragment keyed reorder', () => {
  it('preserves order and reuses DOM for nested fragments', () => {
    const container = document.createElement('div')
    const initial = h(
      Fragment,
      null,
      h(Fragment, null, makeNode('a', 'A1'), makeNode('b', 'B1')),
      h(Fragment, null, makeNode('c', 'C1'), makeNode('d', 'D1')),
    )
    render(initial, container)
    const aEl = container.querySelector('.item:nth-child(1)') as HTMLElement
    const bEl = container.querySelector('.item:nth-child(2)') as HTMLElement
    const cEl = container.querySelector('.item:nth-child(3)') as HTMLElement
    const dEl = container.querySelector('.item:nth-child(4)') as HTMLElement
    expect([aEl?.textContent, bEl?.textContent, cEl?.textContent, dEl?.textContent]).toEqual([
      'A1',
      'B1',
      'C1',
      'D1',
    ])
    const next = h(
      Fragment,
      null,
      h(Fragment, null, makeNode('c', 'C2'), makeNode('a', 'A2')),
      h(Fragment, null, makeNode('d', 'D2'), makeNode('b', 'B2')),
    )
    render(next, container)
    const items = Array.from(container.querySelectorAll('.item')).map(el => el.textContent)
    expect(items).toEqual(['C2', 'A2', 'D2', 'B2'])
    // identity reuse
    const [c2, a2, d2, b2] = Array.from(container.querySelectorAll('.item')) as HTMLElement[]
    expect(c2).toBe(cEl)
    expect(a2).toBe(aEl)
    expect(d2).toBe(dEl)
    expect(b2).toBe(bEl)
  })
})
