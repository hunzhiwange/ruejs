import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  type FC,
  h,
  onBeforeCreate,
  onBeforeMount,
  onBeforeUnmount,
  onBeforeUpdate,
  onCreated,
  onMounted,
  onUnmounted,
  onUpdated,
  render,
} from '../src'

afterEach(() => {
  document.body.innerHTML = ''
})

describe('create phase order: parent-child', () => {
  it('calls beforeCreate/created before mount with correct parent-child ordering', () => {
    // 测试点：创建阶段钩子顺序（beforeCreate/created）与挂载阶段的父子调用关系
    const order: string[] = []
    const pBC = vi.fn(() => order.push('parent:beforeCreate'))
    const pC = vi.fn(() => order.push('parent:created'))
    const pBM = vi.fn(() => order.push('parent:beforeMount'))
    const pM = vi.fn(() => order.push('parent:mounted'))
    const cBC = vi.fn(() => order.push('child:beforeCreate'))
    const cC = vi.fn(() => order.push('child:created'))
    const cBM = vi.fn(() => order.push('child:beforeMount'))
    const cM = vi.fn(() => order.push('child:mounted'))

    // 子/父组件注册创建与挂载钩子
    const Child: FC = () => {
      onBeforeCreate(cBC)
      onCreated(cC)
      onBeforeMount(cBM)
      onMounted(cM)
      return <span id="child">c</span>
    }

    const Parent: FC = () => {
      onBeforeCreate(pBC)
      onCreated(pC)
      onBeforeMount(pBM)
      onMounted(pM)
      return (
        <div id="parent">
          <Child />
        </div>
      )
    }

    // 渲染并断言调用顺序：创建阶段先父再子；挂载阶段 beforeMount 先父后子、mounted 先子后父
    const c = document.createElement('div')
    render(h(Parent, null), c)
    expect(order).toEqual([
      'parent:beforeCreate',
      'parent:created',
      'child:beforeCreate',
      'child:created',
      'parent:beforeMount',
      'child:beforeMount',
      'child:mounted',
      'parent:mounted',
    ])
  })
})

describe('created fires only on initial mount (not on update)', () => {
  it('created is called once; updates trigger beforeUpdate/updated', () => {
    // 测试点：created 仅在初次挂载执行；后续更新走 beforeUpdate/updated
    const cCreated = vi.fn()
    const cBU = vi.fn()
    const cU = vi.fn()

    const Comp: FC<{ v: number }> = props => {
      onCreated(cCreated)
      onBeforeUpdate(cBU)
      onUpdated(cU)
      return <div id="v">{props.v}</div>
    }

    // 渲染后更新 props：验证 created 次数与 update 钩子次数
    const c = document.createElement('div')
    render(h(Comp, { v: 1 }), c)
    render(h(Comp, { v: 2 }), c)

    expect(cCreated).toHaveBeenCalledTimes(1)
    expect(cBU).toHaveBeenCalledTimes(1)
    expect(cU).toHaveBeenCalledTimes(1)
    expect(c.querySelector('#v')!.textContent).toBe('2')

    // 再次渲染后更新 props：验证 created 次数与 update 钩子次数
    render(h(Comp, { v: 2 }), c)
    expect(cCreated).toHaveBeenCalledTimes(1)
    expect(cBU).toHaveBeenCalledTimes(2)
    expect(cU).toHaveBeenCalledTimes(2)
  })
})

describe('update phase order: parent-child', () => {
  it('calls beforeUpdate/updated in correct parent-child order', () => {
    // 测试点：更新阶段父子调用顺序（beforeUpdate 先父后子；updated 先子后父）
    const order: string[] = []
    const pBU = vi.fn(() => order.push('parent:beforeUpdate'))
    const pU = vi.fn(() => order.push('parent:updated'))
    const cBU = vi.fn(() => order.push('child:beforeUpdate'))
    const cU = vi.fn(() => order.push('child:updated'))

    const Child: FC<{ v: number }> = props => {
      onBeforeUpdate(cBU)
      onUpdated(cU)
      return <span id="child-v">{props.v}</span>
    }

    const Parent: FC<{ v: number }> = props => {
      onBeforeUpdate(pBU)
      onUpdated(pU)
      return (
        <div id="parent">
          <Child v={props.v} />
        </div>
      )
    }

    // 更新 props 触发钩子并断言顺序
    const c = document.createElement('div')
    render(h(Parent, { v: 1 }), c)
    render(h(Parent, { v: 2 }), c)

    expect(order).toEqual([
      'parent:beforeUpdate',
      'child:beforeUpdate',
      'child:updated',
      'parent:updated',
    ])
    expect(c.querySelector('#child-v')!.textContent).toBe('2')
  })
})

describe('unmount phase order: parent-child', () => {
  it('calls beforeUnmount/unmounted in correct parent-child order', () => {
    // 测试点：卸载阶段父子调用顺序（beforeUnmount 先父后子；unmounted 先子后父）
    const order: string[] = []
    const pBUm = vi.fn(() => order.push('parent:beforeUnmount'))
    const pUm = vi.fn(() => order.push('parent:unmounted'))
    const cBUm = vi.fn(() => order.push('child:beforeUnmount'))
    const cUm = vi.fn(() => order.push('child:unmounted'))

    const Child: FC = () => {
      onBeforeUnmount(cBUm)
      onUnmounted(cUm)
      return <span id="child">c</span>
    }

    const Parent: FC = () => {
      onBeforeUnmount(pBUm)
      onUnmounted(pUm)
      return (
        <div id="parent">
          <Child />
        </div>
      )
    }

    // 替换父组件为普通元素以触发卸载，并断言顺序
    const c = document.createElement('div')
    render(h(Parent, null), c)
    render(h('div', { id: 'replaced' }, 'x'), c)

    expect(order).toEqual([
      'parent:beforeUnmount',
      'child:beforeUnmount',
      'child:unmounted',
      'parent:unmounted',
    ])
    expect(c.querySelector('#replaced')!.textContent).toBe('x')
  })
})
