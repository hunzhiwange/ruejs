import { afterEach, describe, expect, it } from 'vitest'
import { h, renderBetween, vapor } from '../src'

afterEach(() => {
  document.body.innerHTML = ''
})

function elementsBetween(start: Comment, end: Comment): HTMLElement[] {
  const out: HTMLElement[] = []
  let n: Node | null = start.nextSibling
  while (n && n !== end) {
    if (n.nodeType === 1) out.push(n as HTMLElement)
    n = (n as any).nextSibling
  }
  return out
}

describe('vapor fragment replacement between markers', () => {
  it('removes previous fragment children and inserts new node', () => {
    const parent = document.createElement('div')
    const start = document.createComment('rue:slot:start')
    const end = document.createComment('rue:slot:end')
    parent.appendChild(start)
    parent.appendChild(end)

    renderBetween(
      vapor(() => {
        const frag = document.createDocumentFragment()
        const a = document.createElement('span')
        a.id = 'a'
        const b = document.createElement('span')
        b.id = 'b'
        frag.appendChild(a)
        frag.appendChild(b)
        return { vaporElement: frag }
      }),
      parent,
      start,
      end,
    )

    let els = elementsBetween(start, end)
    expect(els.map(e => e.id)).toEqual(['a', 'b'])

    renderBetween(h('div', null, 'X'), parent, start, end)
    els = elementsBetween(start, end)
    expect(els.length).toBe(1)
    expect(els[0].tagName).toBe('DIV')
    expect(els[0].textContent).toBe('X')
    expect(parent.querySelector('#a')).toBeNull()
    expect(parent.querySelector('#b')).toBeNull()
  })
})
