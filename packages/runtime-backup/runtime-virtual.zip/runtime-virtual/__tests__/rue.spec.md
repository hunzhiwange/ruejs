import { afterEach, describe, expect, it, vi } from 'vitest'
import { type FC, emitted, h, mount, render, useEffect, useMemo, useState } from '../src'
import { batch, computed, effect, reactive, ref, watchEffect } from '../src/reactivity'

afterEach(() => {
  document.body.innerHTML = ''
})

describe('computed lazy and scheduler', () => {
  it('does not evaluate until accessed; triggers via scheduler when deps change', () => {
    // 测试点：computed 惰性求值；依赖变化通过调度器触发而非立即执行
    // 初始化响应式源，spy 用于统计 computed 工厂函数执行次数（惰性执行）
    const base = ref(1)
    const spy = vi.fn()
    const c = computed(() => {
      spy()
      return base.value * 2
    })

    // 仅修改依赖，不访问 c.value：不会触发计算（保持惰性）
    base.value = 3
    expect(spy).toHaveBeenCalledTimes(0)

    // 首次访问 c.value：进行惰性计算并缓存结果
    const v = c.value
    expect(v).toBe(6)
    expect(spy).toHaveBeenCalledTimes(1)
  })
})

describe('effect scheduler', () => {
  it('uses custom scheduler instead of running effect immediately', () => {
    // 测试点：提供自定义 scheduler 后，依赖变化只调度任务，不立即执行 effect
    // 自定义调度器：依赖变化时不直接执行副作用，而是交由 scheduler 调度
    const s = reactive({ n: 0 })
    const scheduler = vi.fn()
    let seen = -1
    const e = effect(
      () => {
        seen = s.n
      },
      { scheduler },
    )

    // 初次执行立即运行副作用，记录初始值
    expect(seen).toBe(0)

    // 改变依赖：不会立刻运行副作用，scheduler 被调用
    // 没有 scheduler 时：依赖变更会立即重新运行副作用。
    // 有 scheduler 时：把“何时运行”交由你控制，常用于
    // 节流、防抖、批处理或放入合适的任务队列（如微任务或宏任务）。
    s.n = 1
    expect(scheduler).toHaveBeenCalledTimes(1)
    expect(seen).toBe(0)

    // 手动触发 effect 执行：读取最新值
    e()
    expect(seen).toBe(1)
  })
})

describe('props patching removal', () => {
  it('removes style keys, attributes and events when no longer present', () => {
    // 测试点：当新 props 不包含原样式/属性/事件时，应正确移除并不再触发
    const c = document.createElement('div')
    const h1 = vi.fn()

    // 初次渲染：包含样式、属性与点击事件
    render(h('div', { style: { color: 'red' }, title: 't', onClick: h1 }, 'x'), c)
    const el = c.querySelector('div')!
    el.click()
    expect(h1).toHaveBeenCalledTimes(1)
    expect(el.style.color).toBe('red')
    expect(el.getAttribute('title')).toBe('t')

    // 重新渲染移除相关 props：样式清空、属性删除、事件不再有效
    render(h('div', null, 'x'), c)
    const el2 = c.querySelector('div')!
    el2.click()
    expect(h1).toHaveBeenCalledTimes(1)
    expect(el2.style.color).toBe('')
    expect(el2.hasAttribute('title')).toBe(false)
  })
})

describe('text patching', () => {
  it('updates text children correctly', () => {
    // 测试点：文本节点的 diff/patch，确保内容更新为最新值
    const c = document.createElement('div')
    // 文本子节点从 'a' 更新为 'b'，验证 patchText 生效
    render(h('div', null, 'a'), c)
    expect(c.textContent).toContain('a')
    render(h('div', null, 'b'), c)
    expect(c.textContent).toContain('b')
  })
})

describe('component patching path', () => {
  it('re-renders component subtree when props change', () => {
    // 测试点：组件接收的 props 更新应触发对应子树的重新渲染
    const c = document.createElement('div')
    // Comp 接收 props.value 并渲染到 DOM；更新 props 应触发子树重渲染
    const Comp: FC<{ value: number }> = props => <div id="v">{props.value}</div>

    render(h(Comp, { value: 1 }), c)
    expect(c.querySelector('#v')!.textContent).toBe('1')

    render(h(Comp, { value: 2 }), c)
    expect(c.querySelector('#v')!.textContent).toBe('2')
  })
})

describe('children injection (single vs array)', () => {
  // Box 组件用于统计 children 的数量：单个 children 记为 1；数组 children 返回 length
  // children 是 JSX 插槽内容，通过框架的元素创建函数注入到组件 props 上
  // 在 Box 的写法 <Box title="t"><span>a</span></Box> 中， <span>a</span> 就是 children
  const Box: FC<{ title: string }> = props => (
    <div>
      <h3>{props.title}</h3>
      <div data-test="len">
        {Array.isArray(props.children) ? (props.children as any[]).length : props.children ? 1 : 0}
      </div>
      {props.children}
    </div>
  )

  it('handles single child', () => {
    // 测试点：单个 children 传递与渲染，数量统计应为 1
    const c = document.createElement('div')
    // 传入单个子节点，len 应为 1
    render(
      <Box title="t">
        <span>a</span>
      </Box>,
      c,
    )
    expect(c.querySelector('[data-test="len]')).toBeNull() // fallback check if selector wrong (sanity)
    const lenEl = c.querySelector('[data-test="len"]')!
    expect(lenEl.textContent).toBe('1')
  })

  it('handles multiple children', () => {
    // 测试点：多个 children 传递与渲染，数量统计应为子节点个数
    const c = document.createElement('div')
    // 传入两个子节点，len 应为 2
    render(
      <Box title="t">
        <span>a</span>
        <span>b</span>
      </Box>,
      c,
    )
    const lenEl = c.querySelector('[data-test="len"]')!
    expect(lenEl.textContent).toBe('2')
  })
})

describe('batch flush', () => {
  it('coalesces updates and flushes once', () => {
    // 测试点：批处理合并多次状态变更，只触发一次 effect 刷新
    const s = reactive({ n: 0 })
    let runs = 0
    effect(() => {
      void s.n
      runs++
    })
    // 同一批次内多次赋值只触发一次刷新
    batch(() => {
      s.n = 1
      s.n = 2
      s.n = 3
    })
    expect(runs).toBe(2)
    // 下一批次再次合并刷新
    batch(() => {
      s.n = 4
      s.n = 5
    })
    expect(runs).toBe(3)
  })
})

describe('mount errors and element containers', () => {
  it('throws when container not found', () => {
    // 测试点：传入不存在的挂载容器时，mount 应抛出未找到错误
    // 传入不存在的选择器：mount 应抛出“未找到容器”错误
    const App: FC = () => <div>App</div>
    expect(() => mount(App, '#missing')).toThrow(/not found/)
  })

  it('mounts into element and re-renders on state change', () => {
    // 测试点：挂载到指定元素后，响应式状态变化应驱动视图更新
    const s = reactive({ n: 0 })
    const App: FC = () => <div id="n">{s.n}</div>

    const root = document.createElement('div')
    document.body.appendChild(root)
    // 挂载到 DOM 元素，并在响应式状态变化时重渲染
    mount(App, root)

    expect(document.querySelector('#n')!.textContent).toBe('0')
    s.n = 7
    expect(document.querySelector('#n')!.textContent).toBe('7')
  })
})

describe('props: event replacement', () => {
  it('replaces event listeners when handler changes', () => {
    // 测试点：事件处理函数更新后，旧监听应被替换且不再触发
    const c = document.createElement('div')
    const h1 = vi.fn(),
      h2 = vi.fn()

    // 初次绑定 onClick=h1
    render(h('button', { onClick: h1 }, 'x'), c)
    const btn = c.querySelector('button')!
    btn.click()
    expect(h1).toHaveBeenCalledTimes(1)

    // 重新渲染后替换为 onClick=h2，旧监听不再触发
    render(h('button', { onClick: h2 }, 'x'), c)
    btn.click()
    expect(h1).toHaveBeenCalledTimes(1)
    expect(h2).toHaveBeenCalledTimes(1)
  })
})

describe('component vModel: input', () => {
  it('binds modelValue and updates via onUpdate:modelValue', () => {
    // 测试点：vModel 绑定输入框值，并通过 onUpdate:modelValue 反向更新源
    const c = document.createElement('div')
    const name = ref('A')
    // 子组件通过 vModel 接收 modelValue，并在 input 事件中触发 onUpdate:modelValue
    const InputComp: FC<{
      modelValue: string
      ['onUpdate:modelValue']?: (v: string) => void
    }> = props => (
      <input
        value={props.modelValue}
        onInput={(e: any) => props['onUpdate:modelValue']?.((e.target as HTMLInputElement).value)}
      />
    )
    // 父级 effect：当 name 变化时重新渲染子组件
    effect(() => {
      render(h(InputComp, { vModel: name }), c)
    })
    const el = c.querySelector('input') as HTMLInputElement
    expect(el.value).toBe('A')

    // 更新响应式源 -> 视图同步
    name.value = 'B'
    expect(el.value).toBe('B')

    // 视图交互 -> 通过 emit 更新响应式源
    el.value = 'C'
    el.dispatchEvent(new Event('input'))
    expect(name.value).toBe('C')
  })
})

describe('component vModel: checkbox', () => {
  it('binds checked and updates via onUpdate:modelValue', () => {
    // 测试点：vModel 绑定复选框选中状态，并通过 onUpdate:modelValue 反向同步
    const c = document.createElement('div')
    const checked = ref(true)
    const CheckboxComp: FC<{
      modelValue: boolean
      ['onUpdate:modelValue']?: (v: boolean) => void
    }> = props => (
      <input
        type="checkbox"
        checked={props.modelValue}
        onChange={(e: any) =>
          props['onUpdate:modelValue']?.((e.target as HTMLInputElement).checked)
        }
      />
    )
    effect(() => {
      render(h(CheckboxComp, { vModel: checked }), c)
    })
    const el = c.querySelector('input') as HTMLInputElement
    expect(el.checked).toBe(true)

    checked.value = false
    expect(el.checked).toBe(false)

    el.checked = true
    el.dispatchEvent(new Event('change'))
    expect(checked.value).toBe(true)
  })
})

describe('named vModel: title', () => {
  it('maps vModel:title to title and onUpdate:title', () => {
    // 测试点：命名 vModel（title）映射为 props.title 与 onUpdate:title
    const c = document.createElement('div')
    const title = ref('Hello')
    const TitleComp: FC<{
      title: string
      ['onUpdate:title']?: (v: string) => void
    }> = props => (
      <input
        value={props.title}
        onInput={(e: any) => props['onUpdate:title']?.((e.target as HTMLInputElement).value)}
      />
    )
    effect(() => {
      render(h(TitleComp, { ['vModel:title']: title }), c)
    })
    const el = c.querySelector('input') as HTMLInputElement
    expect(el.value).toBe('Hello')

    title.value = 'World'
    expect(el.value).toBe('World')

    el.value = 'Vue3'
    el.dispatchEvent(new Event('input'))
    expect(title.value).toBe('Vue3')
  })
})

describe('named vModel: enabled (checkbox)', () => {
  it('maps vModel:enabled to enabled and onUpdate:enabled', () => {
    // 测试点：命名 vModel（enabled）映射为 props.enabled 与 onUpdate:enabled
    const c = document.createElement('div')
    const enabled = ref(false)
    const ToggleComp: FC<{
      enabled: boolean
      ['onUpdate:enabled']?: (v: boolean) => void
    }> = props => (
      <input
        type="checkbox"
        checked={props.enabled}
        onChange={(e: any) => props['onUpdate:enabled']?.((e.target as HTMLInputElement).checked)}
      />
    )
    effect(() => {
      render(h(ToggleComp, { ['vModel:enabled']: enabled }), c)
    })
    const el = c.querySelector('input') as HTMLInputElement
    expect(el.checked).toBe(false)

    enabled.value = true
    expect(el.checked).toBe(true)

    el.checked = false
    el.dispatchEvent(new Event('change'))
    expect(enabled.value).toBe(false)
  })
})

describe('select multiple: array value', () => {
  it('sets selected options based on array and updates on change', () => {
    const c = document.createElement('div')
    const selected = ref<string[]>(['A'])

    effect(() => {
      render(
        <select multiple value={selected.value}>
          <option value="A">A</option>
          <option value="B">B</option>
          <option value="C">C</option>
        </select>,
        c,
      )
    })

    const sel = c.querySelector('select') as HTMLSelectElement
    const opts = sel.options
    expect(opts[0].selected).toBe(true)
    expect(opts[1].selected).toBe(false)
    expect(opts[2].selected).toBe(false)

    selected.value = ['A', 'C']
    expect(opts[0].selected).toBe(true)
    expect(opts[1].selected).toBe(false)
    expect(opts[2].selected).toBe(true)
  })
})

describe('emit: custom event', () => {
  it('child emits save -> parent onSave called', () => {
    // 测试点：子组件通过 emit('save') 触发父组件 onSave 回调
    const c = document.createElement('div')
    const onSave = vi.fn()
    const Child: FC<{ onSave?: (msg: string) => void }> = props => {
      const emit = emitted(props)
      return <button onClick={() => emit('save', 'ok')}>save</button>
    }
    render(h(Child, { onSave }), c)
    ;(c.querySelector('button') as HTMLButtonElement).click()
    expect(onSave).toHaveBeenCalledWith('ok')
  })
})

describe('emit: update:modelValue', () => {
  it('child emits update:modelValue to drive vModel', () => {
    // 测试点：子组件触发 update:modelValue 事件以驱动 vModel 双向绑定
    const c = document.createElement('div')
    const name = ref('A')
    const Child: FC<{
      modelValue?: string
      ['onUpdate:modelValue']?: (v: string) => void
      vModel?: { value: string }
    }> = props => {
      const emit = emitted(props)
      return (
        <input
          value={props.modelValue ?? ''}
          onInput={(e: any) => emit('update:modelValue', (e.target as HTMLInputElement).value)}
        />
      )
    }
    effect(() => {
      render(h(Child, { vModel: name }), c)
    })
    const el = c.querySelector('input') as HTMLInputElement
    expect(el.value).toBe('A')
    el.value = 'B'
    el.dispatchEvent(new Event('input'))
    expect(name.value).toBe('B')
  })
})

describe('watchEffect', () => {
  it('runs immediately and tracks deps; stop prevents further runs', () => {
    // 测试点：watchEffect 立即运行并追踪依赖；调用 stop 后停止后续响应
    const count = ref(0)
    const spy = vi.fn()
    const stop = watchEffect(() => {
      spy(count.value)
    })
    expect(spy).toHaveBeenCalledTimes(1)
    count.value = 1
    expect(spy).toHaveBeenCalledTimes(2)
    stop()
    count.value = 2
    expect(spy).toHaveBeenCalledTimes(2)
  })
})

describe('hooks: useState', () => {
  it('updates value and re-renders via setter', () => {
    // 测试点：通过 setter 更新基本类型状态并触发重新渲染
    const CounterComp: FC = () => {
      const [count, setCount] = useState(0)
      return (
        <div>
          <div id="c">{count.value}</div>
          <button id="add" onClick={() => setCount(v => v + 1)}>
            +1
          </button>
        </div>
      )
    }
    const App: FC = () => <CounterComp />
    const root = document.createElement('div')
    document.body.appendChild(root)
    mount(App, root)
    expect(document.querySelector('#c')!.textContent).toBe('0')
    ;(document.querySelector('#add') as HTMLButtonElement).click()
    expect(document.querySelector('#c')!.textContent).toBe('1')
  })

  it('supports array updates with functional updater', () => {
    // 测试点：使用函数式更新对数组进行不可变追加，长度随之变化
    const ListComp: FC = () => {
      const [list, setList] = useState<string[]>(['A'])
      return (
        <div>
          <div id="len">{list.length}</div>
          <button id="push" onClick={() => setList(prev => [...prev, 'B'])}>
            push
          </button>
        </div>
      )
    }
    const App: FC = () => <ListComp />
    const root = document.createElement('div')
    document.body.appendChild(root)
    mount(App, root)
    expect(document.querySelector('#len')!.textContent).toBe('1')
    ;(document.querySelector('#push') as HTMLButtonElement).click()
    expect(document.querySelector('#len')!.textContent).toBe('2')
  })

  it('supports object updates with shallow copy', () => {
    // 测试点：使用浅拷贝更新对象状态，保证不可变并触发渲染
    const UserComp: FC = () => {
      const [user, setUser] = useState<{ name: string; age: number }>({
        name: 'A',
        age: 20,
      })
      return (
        <div>
          <div id="age">{user.age}</div>
          <button id="inc" onClick={() => setUser(u => ({ ...u, age: u.age + 1 }))}>
            inc
          </button>
        </div>
      )
    }
    const App: FC = () => <UserComp />
    const root = document.createElement('div')
    document.body.appendChild(root)
    mount(App, root)
    expect(document.querySelector('#age')!.textContent).toBe('20')
    ;(document.querySelector('#inc') as HTMLButtonElement).click()
    expect(document.querySelector('#age')!.textContent).toBe('21')
  })
})

describe('hooks: useMemo', () => {
  it('recomputes when deps change and memoizes when unchanged', () => {
    // 测试点：依赖变化触发重新计算；依赖不变时沿用 memoized 值
    const spy = vi.fn()
    const Comp: FC = () => {
      const [count, setCount] = useState(0)
      const [_other, setOther] = useState(0)
      // doubled 仅依赖 count：useMemo 工厂在 count 变化时执行；other 变化不影响
      const doubled = useMemo(() => {
        spy()
        return count.value * 2
      }, [count.value])
      return (
        <div>
          <div id="double">{doubled}</div>
          <button id="addCount" onClick={() => setCount(v => v + 1)}>
            addCount
          </button>
          <button id="addOther" onClick={() => setOther(v => v + 1)}>
            addOther
          </button>
        </div>
      )
    }
    const App: FC = () => <Comp />
    const root = document.createElement('div')
    document.body.appendChild(root)
    // 初次挂载：memo 计算一次 -> doubled=0，spy=1
    mount(App, root)
    expect(document.querySelector('#double')!.textContent).toBe('0')
    expect(spy).toHaveBeenCalledTimes(1)
    // 更新 count：依赖变化 -> useMemo 重算，doubled=2，spy=2
    ;(document.querySelector('#addCount') as HTMLButtonElement).click()
    expect(document.querySelector('#double')!.textContent).toBe('2')
    expect(spy).toHaveBeenCalledTimes(2)
    // 更新 other：非依赖变化 -> useMemo 不重算，doubled 维持 2，spy 不变
    ;(document.querySelector('#addOther') as HTMLButtonElement).click()
    expect(document.querySelector('#double')!.textContent).toBe('2')
    expect(spy).toHaveBeenCalledTimes(2)
  })

  it('runs once with empty deps', () => {
    // 测试点：空依赖数组下，只在初次渲染时计算一次
    const spy = vi.fn()
    const Comp: FC = () => {
      const [_n, setN] = useState(0)
      // 空依赖：memo 在挂载时执行一次，之后组件重渲染也不会重新计算
      const memo = useMemo(() => {
        spy()
        return 'X'
      }, [])
      return (
        <div>
          <div id="mem">{memo}</div>
          <button id="b" onClick={() => setN(v => v + 1)}>
            b
          </button>
        </div>
      )
    }
    const App: FC = () => <Comp />
    const root = document.createElement('div')
    document.body.appendChild(root)
    // 初次挂载：memo 计算 -> spy=1
    mount(App, root)
    expect(document.querySelector('#mem')!.textContent).toBe('X')
    expect(spy).toHaveBeenCalledTimes(1)
    // 更新 n：组件重渲染但依赖未变 -> memo 不重算，spy 不变
    ;(document.querySelector('#b') as HTMLButtonElement).click()
    expect(document.querySelector('#mem')!.textContent).toBe('X')
    expect(spy).toHaveBeenCalledTimes(1)
  })

  it('uses Object.is equality for deps (NaN equal; +0/-0 different)', () => {
    // 测试点：依赖比较遵循 Object.is（NaN 相等；+0 与 -0 不同）
    const spy = vi.fn()
    const Comp: FC = () => {
      const [v, setV] = useState(NaN as number)
      // 依赖 v 使用 Object.is 比较：Object.is(NaN, NaN) 为 true；Object.is(+0, -0) 为 false
      const memo = useMemo(() => {
        spy()
        return v.value
      }, [v.value])
      return (
        <div>
          <div id="val">{String(memo)}</div>
          <button id="nan" onClick={() => setV(NaN)}>
            nan
          </button>
          <button id="p0" onClick={() => setV(0)}>
            p0
          </button>
          <button id="n0" onClick={() => setV(-0)}>
            n0
          </button>
        </div>
      )
    }
    const App: FC = () => <Comp />
    const root = document.createElement('div')
    document.body.appendChild(root)
    // 初次计算：spy=1
    mount(App, root)
    expect(spy).toHaveBeenCalledTimes(1)
    // 设置为 NaN：Object.is(NaN, NaN) 相等 -> 不重算
    ;(document.querySelector('#nan') as HTMLButtonElement).click()
    expect(spy).toHaveBeenCalledTimes(1)
    // 设置为 +0：与 NaN 不相等 -> 重算，spy=2
    ;(document.querySelector('#p0') as HTMLButtonElement).click()
    expect(spy).toHaveBeenCalledTimes(2)
    // 设置为 -0：与 +0 不相等（Object.is(+0,-0)=false）-> 再次重算，spy=3
    ;(document.querySelector('#n0') as HTMLButtonElement).click()
    expect(spy).toHaveBeenCalledTimes(3)
    // 当前 memo 显示为 "0"（字符串化后）
    expect(document.querySelector('#val')!.textContent).toBe('0')
  })

  it('recomputes when deps array length changes', () => {
    // 测试点：依赖数组长度改变应视为依赖变化从而重新计算
    const spy = vi.fn()
    const Comp: FC = () => {
      const [count, setCount] = useState(0)
      const [other, setOther] = useState(0)
      const [useTwo, setUseTwo] = useState(false)
      // 当 useTwo=false：memo 仅依赖 count；当 useTwo=true：依赖 [count, other]
      const memo = useMemo(
        () => {
          spy()
          return count.value + other.value
        },
        useTwo.value ? [count.value, other.value] : [count.value],
      )
      return (
        <div>
          <div id="sum">{memo}</div>
          <button id="toggle" onClick={() => setUseTwo(v => !v)}>
            toggle
          </button>
          <button id="addCount" onClick={() => setCount(v => v + 1)}>
            addCount
          </button>
          <button id="addOther" onClick={() => setOther(v => v + 1)}>
            addOther
          </button>
        </div>
      )
    }
    const App: FC = () => <Comp />
    const root = document.createElement('div')
    document.body.appendChild(root)
    // 初始：仅依赖 count，memo=0，spy=1
    mount(App, root)
    expect(document.querySelector('#sum')!.textContent).toBe('0')
    expect(spy).toHaveBeenCalledTimes(1)
    // 更新 other：不在依赖中 -> memo 不重算，spy 不变
    ;(document.querySelector('#addOther') as HTMLButtonElement).click()
    expect(document.querySelector('#sum')!.textContent).toBe('0')
    expect(spy).toHaveBeenCalledTimes(1)
    // 切换 useTwo=true：依赖数组长度由 1 变 2 -> 视为依赖变化，memo 重算为 1
    ;(document.querySelector('#toggle') as HTMLButtonElement).click()
    expect(document.querySelector('#sum')!.textContent).toBe('1')
    expect(spy).toHaveBeenCalledTimes(2)
    // 现在 other 在依赖中：再更新 other -> memo 重算为 2，spy=3
    ;(document.querySelector('#addOther') as HTMLButtonElement).click()
    expect(document.querySelector('#sum')!.textContent).toBe('2')
    expect(spy).toHaveBeenCalledTimes(3)
  })

  it('reference dep: same identity no recompute; new identity recompute', () => {
    // 测试点：引用型依赖仅在引用更换时重算；内部字段变更不触发
    const spy = vi.fn()
    const Comp: FC = () => {
      // obj.current 是对象引用，将其作为 useMemo 的依赖
      // 只有当 obj.current 的“引用”发生变化时才会重算；内部字段变化不会触发
      const obj = reactive<{ current: { x: number } }>({ current: { x: 0 } })
      const [_tick, setTick] = useState(0)
      const memo = useMemo(() => {
        spy()
        return obj.current!.x
      }, [obj.current])
      return (
        <div>
          <div id="m">{memo}</div>
          {/* 仅修改对象内部字段（保持同一引用），强制触发一次重渲染 */}
          <button
            id="mut"
            onClick={() => {
              obj.current!.x++
              setTick(v => v + 1)
            }}
          >
            mut
          </button>
          {/* 替换为新对象（引用变化），再触发一次重渲染 */}
          <button
            id="swap"
            onClick={() => {
              obj.current = { x: obj.current!.x + 3 }
              setTick(v => v + 1)
            }}
          >
            swap
          </button>
        </div>
      )
    }
    const App: FC = () => <Comp />
    const root = document.createElement('div')
    document.body.appendChild(root)
    mount(App, root)
    // 初始渲染：memo = 0；useMemo 工厂函数执行 1 次
    expect(document.querySelector('#m')!.textContent).toBe('0')
    expect(spy).toHaveBeenCalledTimes(1)
    // 修改内部字段但引用不变：memo 不重算，spy 次数不变
    ;(document.querySelector('#mut') as HTMLButtonElement).click()
    expect(document.querySelector('#m')!.textContent).toBe('0')
    expect(spy).toHaveBeenCalledTimes(1)
    // 替换为新对象引用：memo 重算为 1，spy 次数 +1
    ;(document.querySelector('#swap') as HTMLButtonElement).click()
    expect(document.querySelector('#m')!.textContent).toBe('4')
    expect(spy).toHaveBeenCalledTimes(2)
  })

  it('works with useEffect deps', () => {
    // 测试点：useMemo 产物作为 useEffect 依赖；仅在其变化时运行 effect
    const spy = vi.fn()
    const Comp: FC = () => {
      const [count, setCount] = useState(0)
      const [_other, setOther] = useState(0)
      // memo 依赖 count：只有 count 变化时 memo 才会更新
      const memo = useMemo(() => count.value * 2, [count.value])
      // useEffect 依赖 memo：仅在 memo 初次赋值及后续变化时运行
      useEffect(() => {
        spy(memo)
      }, [memo])
      return (
        <div>
          <div id="mm">{memo}</div>
          <button id="addCount" onClick={() => setCount(v => v + 1)}>
            addCount
          </button>
          <button id="addOther" onClick={() => setOther(v => v + 1)}>
            addOther
          </button>
        </div>
      )
    }
    const App: FC = () => <Comp />
    const root = document.createElement('div')
    document.body.appendChild(root)
    mount(App, root)
    // 初始渲染：memo = 0；useEffect（依赖 memo）在挂载阶段运行一次
    expect(document.querySelector('#mm')!.textContent).toBe('0')
    expect(spy).toHaveBeenCalledTimes(1)
    // 仅更新 other：memo 未变化，useEffect 不运行
    ;(document.querySelector('#addOther') as HTMLButtonElement).click()
    expect(spy).toHaveBeenCalledTimes(1)
    // 更新 count：memo 从 0 变为 2，useEffect 因依赖变化而再次运行
    ;(document.querySelector('#addCount') as HTMLButtonElement).click()
    expect(document.querySelector('#mm')!.textContent).toBe('2')
    expect(spy).toHaveBeenCalledTimes(2)
  })
})
