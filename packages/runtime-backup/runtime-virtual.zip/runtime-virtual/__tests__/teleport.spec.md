// 说明（Teleport 行为与单测思路）：
// - Teleport 将一段“区间内容”（两个注释锚点之间的真实 DOM）渲染到“目标容器”中
// - props.to 可是选择器或元素；props.disabled 为 true 时不传送，改为在源组件本地渲染
// - 本组件内部使用 renderBetween(start,end) 维护传送区间；当目标改变时，会把旧区间的真实节点整体搬运到新目标
// - 单测覆盖：
//   1) 启用传送：内容出现在目标容器，源容器为空
//   2) 禁用传送：内容留在源容器，且目标被清空
//   3) 切换目标：内容从旧目标移动到新目标（验证“搬家”逻辑）
//   4) 更新 children：在目标处就地更新文本节点，保持节点身份
import { describe, expect, it } from 'vitest'
import { vi } from 'vitest'
vi.mock('rue-js', async () => {
  const mod = await vi.importActual<any>('@rue/runtime')
  return mod
})
import { Teleport, h, render } from '@rue/runtime'

const child = (id: number, text: string) => h('div', { 'data-id': String(id) }, text)

describe('Teleport basic behavior', () => {
  it('renders to target when enabled', () => {
    const container = document.createElement('div')
    const target = document.createElement('div')
    target.id = 't1'
    document.body.appendChild(target)
    // 禁用与否由 disabled 控制；禁用=false 时传送到目标
    const view = (disabled: boolean) =>
      h('div', null, h(Teleport as any, { to: '#t1', disabled } as any, child(1, 'A')))
    // 渲染启用传送
    render(view(false), container)
    // 源容器应为空；目标容器存在内容
    const inSource = container.querySelector('[data-id]')
    const inTarget = target.querySelector('[data-id]')
    expect(inSource).toBeFalsy()
    expect(inTarget).toBeTruthy()
    document.body.removeChild(target)
  })

  it('renders locally when disabled, and clears target', () => {
    const container = document.createElement('div')
    const target = document.createElement('div')
    target.id = 't2'
    document.body.appendChild(target)
    // 禁用=true：不传送，改为在源容器本地渲染
    const view = (disabled: boolean) =>
      h('div', null, h(Teleport as any, { to: '#t2', disabled } as any, child(2, 'B')))
    // 先启用传送，确认目标含内容
    render(view(false), container)
    expect(target.querySelector('[data-id="2"]')).toBeTruthy()
    // 再禁用传送，内容应回到源容器，同时目标清空
    render(view(true), container)
    expect(container.querySelector('[data-id="2"]')).toBeTruthy()
    expect(target.querySelector('[data-id="2"]')).toBeFalsy()
    document.body.removeChild(target)
  })

  it('moves when target changes', () => {
    const container = document.createElement('div')
    const t1 = document.createElement('div')
    const t2 = document.createElement('div')
    t1.id = 'to1'
    t2.id = 'to2'
    document.body.appendChild(t1)
    document.body.appendChild(t2)
    // 切换 props.to：应将区间真实节点整体从旧目标搬运到新目标
    const view = (toSel: string) =>
      h('div', null, h(Teleport as any, { to: toSel } as any, child(3, 'C')))
    // 初次传送到 t1
    render(view('#to1'), container)
    expect(t1.querySelector('[data-id="3"]')).toBeTruthy()
    expect(t2.querySelector('[data-id="3"]')).toBeFalsy()
    // 切换到 t2：t1 清空，t2 出现内容
    render(view('#to2'), container)
    expect(t1.querySelector('[data-id="3"]')).toBeFalsy()
    expect(t2.querySelector('[data-id="3"]')).toBeTruthy()
    document.body.removeChild(t1)
    document.body.removeChild(t2)
  })

  it('updates children content at target', () => {
    const container = document.createElement('div')
    const target = document.createElement('div')
    target.id = 't3'
    document.body.appendChild(target)
    // 在目标处就地更新 children 文本内容，保持节点身份
    const view = (text: string) =>
      h('div', null, h(Teleport as any, { to: '#t3' } as any, h('span', { 'data-id': '4' }, text)))
    render(view('X'), container)
    const s1 = target.querySelector('[data-id="4"]') as HTMLSpanElement
    expect(s1.textContent).toBe('X')
    render(view('Y'), container)
    const s2 = target.querySelector('[data-id="4"]') as HTMLSpanElement
    expect(s2).toBe(s1)
    expect(s2.textContent).toBe('Y')
    document.body.removeChild(target)
  })
})
