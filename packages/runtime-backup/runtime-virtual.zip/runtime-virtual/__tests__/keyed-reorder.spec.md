import { describe, expect, it } from 'vitest'
import { Fragment, h, render } from '@rue/runtime'

function elementView(items: number[]) {
  return h(
    'ul',
    null,
    ...items.map(i =>
      h(
        'li',
        {
          key: i,
          'data-id': String(i),
        },
        String(i),
      ),
    ),
  )
}

function fragmentView(items: number[]) {
  return h(
    'ul',
    null,
    ...items.map(i =>
      h(
        Fragment,
        { key: i },
        h(
          'li',
          {
            'data-id': String(i),
          },
          String(i),
        ),
      ),
    ),
  )
}

describe('keyed list reorder (one-pass, preserve identity)', () => {
  it('Element: reverse reorder in one render and keep nodes', () => {
    const container = document.createElement('div')
    let items = [1, 2, 3, 4, 5]
    render(elementView(items), container)

    const before: Record<number, HTMLLIElement> = {}
    items.forEach(id => {
      before[id] = container.querySelector(`[data-id="${id}"]`) as HTMLLIElement
    })

    items = [5, 4, 3, 2, 1]
    render(elementView(items), container)

    const order = Array.from(container.querySelectorAll('[data-id]')).map(el =>
      Number(el.getAttribute('data-id')),
    )
    expect(order).toEqual([5, 4, 3, 2, 1])
    items.forEach(id => {
      const after = container.querySelector(`[data-id="${id}"]`) as HTMLLIElement
      expect(after).toBe(before[id])
    })
  })

  it('Fragment: reverse reorder in one render and keep nodes', () => {
    const container = document.createElement('div')
    let items = [1, 2, 3, 4, 5]
    render(fragmentView(items), container)

    const before: Record<number, HTMLLIElement> = {}
    items.forEach(id => {
      before[id] = container.querySelector(`[data-id="${id}"]`) as HTMLLIElement
    })

    items = [5, 4, 3, 2, 1]
    render(fragmentView(items), container)

    const order = Array.from(container.querySelectorAll('[data-id]')).map(el =>
      Number(el.getAttribute('data-id')),
    )
    expect(order).toEqual([5, 4, 3, 2, 1])
    items.forEach(id => {
      const after = container.querySelector(`[data-id="${id}"]`) as HTMLLIElement
      expect(after).toBe(before[id])
    })
  })

  it('mixed: reorder with insertion, preserve existing identities', () => {
    const container = document.createElement('div')
    let items = [1, 2, 3]
    render(elementView(items), container)

    const before1 = container.querySelector(`[data-id="1"]`) as HTMLLIElement
    const before2 = container.querySelector(`[data-id="2"]`) as HTMLLIElement
    const before3 = container.querySelector(`[data-id="3"]`) as HTMLLIElement

    items = [3, 1, 4, 2]
    render(elementView(items), container)

    const order = Array.from(container.querySelectorAll('[data-id]')).map(el =>
      Number(el.getAttribute('data-id')),
    )
    expect(order).toEqual([3, 1, 4, 2])

    const after1 = container.querySelector(`[data-id="1"]`) as HTMLLIElement
    const after2 = container.querySelector(`[data-id="2"]`) as HTMLLIElement
    const after3 = container.querySelector(`[data-id="3"]`) as HTMLLIElement
    const after4 = container.querySelector(`[data-id="4"]`) as HTMLLIElement

    expect(after1).toBe(before1)
    expect(after2).toBe(before2)
    expect(after3).toBe(before3)
    expect(after4).toBeTruthy()
  })
})
