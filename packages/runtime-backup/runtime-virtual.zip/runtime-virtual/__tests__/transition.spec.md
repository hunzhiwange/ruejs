// 说明（Transition 行为与单测思路）：
// - Transition 为“单元素/单片段”提供进入（enter）、离开（leave）、初次展示（appear）过渡
// - 通过 BaseTransition 的 emitted 机制触发钩子 onBeforeEnter/onAfterEnter 等
// - 单测中使用 fake timers + mock RAF，确保 nextFrame/whenTransitionEnds 等异步路径可控
// - 单测覆盖：
//   1) appear：首次渲染时触发 appear 钩子，元素被渲染
//   2) leave：隐藏时触发 leave 钩子并移除元素
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
vi.mock('rue-js', async () => {
  const orig = await vi.importActual<any>('rue-js')
  return {
    ...orig,
    emitted: (props: any) => {
      const p = props || {}
      return (event: string, ...args: any[]) => {
        const keyColon = 'on' + event
        const keyCamel = 'on' + (event[0] ? event[0].toUpperCase() + event.slice(1) : '')
        const handler = (p as any)[keyColon] || (p as any)[keyCamel]
        if (typeof handler === 'function') handler(...args)
      }
    },
  }
})
import { Transition, h, render } from '@rue/runtime'

const withStyle = (key: any, text: string) =>
  h(
    'div',
    {
      key,
      style: { transition: 'opacity 10ms' },
    },
    text,
  )

let origRAF: any

beforeEach(() => {
  // 使用 fake timers + mock RAF，让内置 nextFrame/transition 计时器立即推进
  vi.useFakeTimers()
  origRAF = window.requestAnimationFrame
  window.requestAnimationFrame = (fn: FrameRequestCallback) => {
    return setTimeout(() => fn(performance.now()), 0) as any
  }
})

afterEach(() => {
  window.requestAnimationFrame = origRAF
  vi.useRealTimers()
})

describe('Transition basic enter/leave/appear', () => {
  it('appear hooks fire and element is rendered', () => {
    const container = document.createElement('div')
    const calls: string[] = []
    // appear: 首次渲染显示元素，期待触发 before-appear/after-appear
    const view = (show: boolean) =>
      h(
        Transition as any,
        {
          type: 'transition',
          duration: 10,
          appear: true,
          onBeforeAppear: () => calls.push('before-appear'),
          onAfterAppear: () => calls.push('after-appear'),
        } as any,
        show ? withStyle('a', 'A') : null,
      )
    render(view(true), container)
    vi.runAllTimers()
    const el = container.querySelector('div')
    expect(el).toBeTruthy()
    expect(calls.includes('before-appear')).toBe(true)
    expect(calls.includes('after-appear')).toBe(true)
  })

  it('leave removes element and fires leave hooks', () => {
    const container = document.createElement('div')
    const calls: string[] = []
    // leave: 从显示到隐藏，期待触发 before-leave/after-leave，并移除元素
    const view = (show: boolean) =>
      h(
        Transition as any,
        {
          type: 'transition',
          duration: 10,
          onBeforeLeave: () => calls.push('before-leave'),
          onAfterLeave: () => calls.push('after-leave'),
        } as any,
        show ? withStyle('b', 'B') : null,
      )
    render(view(true), container)
    const before = container.querySelector('div') as HTMLDivElement
    expect(before).toBeTruthy()
    render(view(false), container)
    vi.runAllTimers()
    const after = container.querySelector('div')
    expect(after).toBeFalsy()
    expect(calls.includes('before-leave')).toBe(true)
    expect(calls.includes('after-leave')).toBe(true)
  })
})
