import { afterEach, describe, expect, it, vi } from 'vitest'
import { type FC, useEffect, h, render } from '../src'
import {
  RouterLink,
  RouterView,
  createRouter,
  createWebHashHistory,
  attachRouter,
} from '@rue/router'
vi.mock('rue-js', async () => await import('../src/rue-js'))

afterEach(() => {
  document.body.innerHTML = ''
  // reset to home between tests
  window.location.hash = '#/'
})

describe('hash history', () => {
  it('defaults to "/" when hash is empty', () => {
    // 测试点：空 hash 时历史对象默认定位到根路径 "/"
    window.location.hash = ''
    const history = createWebHashHistory()
    expect(history.location()).toBe('/')
    expect(window.location.hash).toBe('#/')
  })

  it('push updates location.hash and location()', () => {
    // 测试点：push 改变地址并更新 location() 返回值
    const history = createWebHashHistory()
    history.push('/about')
    expect(history.location()).toBe('/about')
    expect(window.location.hash).toBe('#/about')
  })

  it('replace updates location.hash without adding history entry', () => {
    // 测试点：replace 更新地址但不新增历史记录
    const history = createWebHashHistory()
    history.replace('/replaced')
    expect(history.location()).toBe('/replaced')
    expect(window.location.hash).toBe('#/replaced')
  })
})

describe('router + view', () => {
  it('renders route for "/" then updates to "/about" via hashchange', () => {
    // 测试点：RouterView 随 hashchange 切换路由视图
    const c = document.createElement('div')
    const Home: FC = () => h('div', { id: 'home' }, 'Home')
    const About: FC = () => h('div', { id: 'about' }, 'About')

    // 配置两条静态路由
    const r = createRouter({
      history: createWebHashHistory(),
      routes: [
        { path: '/', component: Home },
        { path: '/about', component: About },
      ],
    })
    attachRouter(c, r as any)

    // 在 effect 渲染 RouterView：初始为 Home
    useEffect(() => {
      render(h(RouterView, null), c)
    })
    expect(c.querySelector('#home')?.textContent).toBe('Home')

    // 触发 hashchange：切到 About
    window.location.hash = '#/about'
    window.dispatchEvent(new HashChangeEvent('hashchange'))

    expect(c.querySelector('#about')?.textContent).toBe('About')
    expect(c.querySelector('#home')).toBeNull()
  })

  it('RouterLink navigates and updates RouterView', () => {
    // 测试点：点击 RouterLink 导航并驱动 RouterView 更新
    const c = document.createElement('div')
    const Home: FC = () => h('div', { id: 'home' }, 'Home')
    const About: FC = () => h('div', { id: 'about' }, 'About')

    const r = createRouter({
      history: createWebHashHistory(),
      routes: [
        { path: '/', component: Home },
        { path: '/about', component: About },
      ],
    })
    attachRouter(c, r as any)

    // effect 渲染：包含链接与视图
    useEffect(() => {
      render(h('div', null, h(RouterLink, { to: '/about' }, 'Go About'), h(RouterView, null)), c)
    })

    // 初始在 Home；点击后 hash 变化，视图切换到 About
    expect(c.querySelector('#home')).not.toBeNull()
    const a = c.querySelector('a') as HTMLAnchorElement
    a.click()
    expect(window.location.hash).toBe('#/about')
    expect(c.querySelector('#about')).not.toBeNull()
    expect(c.querySelector('#home')).toBeNull()
  })

  it('route root replacement: Fragment -> Element', () => {
    // 测试点：路由切换时根节点类型可从 Fragment 变为 Element，视图正确替换
    const c = document.createElement('div')
    const Home: FC = () => h('fragment', null, h('span', { id: 'home' }, 'Home'))
    const About: FC = () => h('div', { id: 'about' }, 'About')

    const r = createRouter({
      history: createWebHashHistory(),
      routes: [
        { path: '/', component: Home },
        { path: '/about', component: About },
      ],
    })
    attachRouter(c, r as any)

    // 初始：RouterView 渲染 Fragment 作为根
    useEffect(() => {
      render(h(RouterView, null), c)
    })
    expect(c.querySelector('#home')).not.toBeNull()
    expect(c.querySelector('#about')).toBeNull()

    // 切换到 about：根节点替换为元素
    window.location.hash = '#/about'
    window.dispatchEvent(new HashChangeEvent('hashchange'))

    expect(c.querySelector('#home')).toBeNull()
    expect(c.querySelector('#about')).not.toBeNull()
  })

  it('supports multiple isolated routers in different containers', () => {
    // 测试点：不同容器绑定不同路由实例，渲染互不影响
    const containerA = document.createElement('div')
    const containerB = document.createElement('div')
    document.body.appendChild(containerA)
    document.body.appendChild(containerB)

    const AppAHome: FC = () => h('div', { id: 'app-a-home' }, 'App A Home')
    const AppBHome: FC = () => h('div', { id: 'app-b-home' }, 'App B Home')

    const routerA = createRouter({
      history: createWebHashHistory(),
      routes: [{ path: '/', component: AppAHome }],
    })
    const routerB = createRouter({
      history: createWebHashHistory(),
      routes: [{ path: '/', component: AppBHome }],
    })

    attachRouter(containerA, routerA as any)
    attachRouter(containerB, routerB as any)

    render(h(RouterView, null), containerA)
    render(h(RouterView, null), containerB)

    expect(containerA.querySelector('#app-a-home')).not.toBeNull()
    expect(containerB.querySelector('#app-b-home')).not.toBeNull()
    expect(containerA.querySelector('#app-b-home')).toBeNull()
    expect(containerB.querySelector('#app-a-home')).toBeNull()
  })
})
