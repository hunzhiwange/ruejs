import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
// 说明（TransitionGroup 行为与单测思路）：
// - TransitionGroup 负责“多个 keyed 子元素”的过渡：新增 enter、删除 leave、重排 move（FLIP）
// - 组件内部在渲染后会为每个子元素写入 data-rue-key，以便后续定位元素并计算位移
// - 在 jsdom 中无法得到真实布局与动画帧，难以稳定断言 move 的类名与过渡结束事件
//   因此单测中：
//   1) 对新增/删除，改为断言钩子集合（onBeforeEnter/onBeforeLeave）是否覆盖所有受影响项
//   2) 对重排，仅断言流程不崩溃、DOM 仍包含所有 key 对应元素
// - 另外，使用 fake timers + mock RAF 控制异步 nextFrame/forceReflow 等步骤
vi.mock('rue-js', () => {
  // 在单测环境中提供轻量 emitted 实现，避免 BaseTransition 调用 emitted(props) 出错
  return {
    emitted: (props: any) => {
      const p = props || {}
      return (event: string, ...args: any[]) => {
        const keyColon = 'on' + event
        const keyCamel = 'on' + (event[0] ? event[0].toUpperCase() + event.slice(1) : '')
        const handler = (p as any)[keyColon] || (p as any)[keyCamel]
        if (typeof handler === 'function') handler(...args)
      }
    },
  }
})
import { TransitionGroup, h, render } from '@rue/runtime'

const withStyle = (node: any) =>
  // 为 li 注入最短 CSS 过渡，便于 inferType 返回 'transition' 并触发过渡路径
  h(
    'li',
    {
      key: node,
      style: {
        transition: 'transform 10ms, opacity 10ms',
      },
    },
    String(node),
  )

let origRAF: any

beforeEach(() => {
  // 使用 fake timers + mock RAF，保证 nextFrame/forceReflow 等异步步骤在测试中可控
  vi.useFakeTimers()
  origRAF = window.requestAnimationFrame
  window.requestAnimationFrame = (fn: FrameRequestCallback) => {
    return setTimeout(() => fn(performance.now()), 0) as any
  }
})

afterEach(() => {
  window.requestAnimationFrame = origRAF
  vi.useRealTimers()
})

describe('TransitionGroup enter/leave/move', () => {
  it('applies enter classes to newly inserted items', async () => {
    // 新增：通过 onBeforeEnter 收集 keys，断言所有新增项都触发（不是只第一个）
    const container = document.createElement('div')
    const enters: string[] = []
    const view = (items: number[]) =>
      h(
        TransitionGroup as any,
        {
          name: 'fade',
          type: 'transition',
          duration: 50,
          appear: true,
          tag: 'ul',
          // 在触发 enter 前，从元素上读取 data-rue-key，收集本次新增项的 key
          onBeforeEnter: (el: HTMLElement) => {
            const k = el.getAttribute('data-rue-key') || ''
            enters.push(k)
          },
        } as any,
        ...items.map(i => withStyle(i)),
      )
    let items = [1, 2]
    render(view(items), container)
    items = [1, 2, 3, 4]
    render(view(items), container)
    expect(enters.includes('3')).toBe(true)
    expect(enters.includes('4')).toBe(true)
  })

  it('applies leave classes and removes element after transition', async () => {
    // 删除：通过 onBeforeLeave 收集 keys，断言所有删除项都触发（不是只第一个）
    const container = document.createElement('div')
    const leaves: string[] = []
    const view = (items: number[]) =>
      h(
        TransitionGroup as any,
        {
          name: 'fade',
          type: 'transition',
          duration: 50,
          tag: 'ul',
          // 在触发 leave 前，从元素上读取 data-rue-key，收集本次删除项的 key
          onBeforeLeave: (el: HTMLElement) => {
            const k = el.getAttribute('data-rue-key') || ''
            leaves.push(k)
          },
        } as any,
        ...items.map(i => withStyle(i)),
      )
    let items = [1, 2, 3]
    render(view(items), container)
    items = [3]
    render(view(items), container)
    expect(leaves.includes('1')).toBe(true)
    expect(leaves.includes('2')).toBe(true)
  })

  it('does not crash on reorder with type transition', async () => {
    // 重排：jsdom 不计算真实布局，FLIP 位移（fade-move）无法稳定断言类名；
    // 这里只验证代码路径不崩溃，确保基础逻辑健壮
    const container = document.createElement('div')
    const view = (items: number[]) =>
      h(
        TransitionGroup as any,
        { name: 'fade', type: 'transition', tag: 'ul' } as any,
        ...items.map(i => withStyle(i)),
      )
    let items = [1, 2, 3]
    render(view(items), container)
    items = [3, 1, 2]
    render(view(items), container)
    // 断言所有 key 对应元素仍然存在（未崩溃/丢失）
    const el1 = container.querySelector('[data-rue-key="1"]') as HTMLElement
    const el2 = container.querySelector('[data-rue-key="2"]') as HTMLElement
    const el3 = container.querySelector('[data-rue-key="3"]') as HTMLElement
    expect(el1).toBeTruthy()
    expect(el2).toBeTruthy()
    expect(el3).toBeTruthy()
  })
})
