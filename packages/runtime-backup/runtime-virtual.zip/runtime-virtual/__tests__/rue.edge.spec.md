import { afterEach, describe, expect, it, vi } from 'vitest'
import { type FC, Fragment, batch, computed, effect, h, reactive, ref, render, watch } from '../src'

afterEach(() => {
  document.body.innerHTML = ''
})

describe('computed caching and dirty flag', () => {
  it('does not recompute if deps unchanged and caches last value', () => {
    // 测试点：computed 缓存上次结果；依赖未变化不重复计算
    const base = ref(1)
    const calls = vi.fn()
    const c = computed(() => {
      calls()
      return base.value * 10
    })

    // 初次读取：计算一次并缓存
    expect(c.value).toBe(10)
    expect(calls).toHaveBeenCalledTimes(1)

    // 赋相同值：不触发重算
    base.value = 1
    expect(calls).toHaveBeenCalledTimes(1)

    // 依赖变化：触发重算并更新缓存
    base.value = 2
    expect(c.value).toBe(20)
    expect(calls).toHaveBeenCalledTimes(2)
  })
})

describe('watch default behavior and stop', () => {
  it('does not call initially when immediate=false; stop prevents further calls', () => {
    // 测试点：watch 默认不立即调用；stop 后停止后续回调
    const s = reactive({ n: 0 })
    const cb = vi.fn()
    const stop = watch(() => s.n, cb) // immediate 默认 false
    expect(cb).toHaveBeenCalledTimes(0)

    // 第一次变更触发回调，传递新旧值
    s.n = 1
    expect(cb).toHaveBeenCalledTimes(1)
    // 这两行在检查回调的“新值/旧值”
    // - cb 是 vi.fn() 创建的模拟函数。 cb.mock.calls 记录了每次调用的参数列表。
    // - cb.mock.calls[0] 取的是第一次[0]调用的参数数组； [0] 是第一个参数（新值）， [1] 是第二个参数（旧值）。
    expect(cb.mock.calls[0][0]).toBe(1)
    expect(cb.mock.calls[0][1]).toBe(0)

    // 再次执行
    // 第二次[1]调用的参数数组
    s.n = 3
    expect(cb).toHaveBeenCalledTimes(2)
    expect(cb.mock.calls[1][0]).toBe(3)
    expect(cb.mock.calls[1][1]).toBe(1)

    // stop 之后的变更不再触发
    stop()
    s.n = 2
    expect(cb).toHaveBeenCalledTimes(2)
  })

  it('supports ref source like Vue3', () => {
    // 测试点：watch 源可为 ref；仅在值变化时触发
    const base = ref(0)
    const cb = vi.fn()
    const stop = watch(base, cb)
    expect(cb).toHaveBeenCalledTimes(0)

    // 变更 ref.value：触发一次回调
    base.value = 1
    expect(cb).toHaveBeenCalledTimes(1)
    expect(cb.mock.calls[0][0]).toBe(1)
    expect(cb.mock.calls[0][1]).toBe(0)

    // stop 后变更不触发
    stop()
    base.value = 2
    expect(cb).toHaveBeenCalledTimes(1)
  })

  it('immediate calls once with same old/new for ref source', () => {
    // 测试点：immediate=true 时立即调用一次，传入相同新旧值
    const base = ref(5)
    const cb = vi.fn()
    const stop = watch(base, cb, { immediate: true })
    expect(cb).toHaveBeenCalledTimes(1)
    expect(cb.mock.calls[0][0]).toBe(5)
    expect(cb.mock.calls[0][1]).toBe(5)
    stop()
  })
})

describe('createElement normalization: number and nested arrays', () => {
  it('renders number children as text nodes', () => {
    // 测试点：数字 children 规范化为文本节点渲染
    const c = document.createElement('div')
    render(h('div', null, 123), c)
    expect(c.textContent).toContain('123')
  })

  it('flattens nested children arrays', () => {
    // 测试点：嵌套数组 children 被扁平化为一维列表渲染
    const c = document.createElement('div')
    render(h('div', null, [h('span', null, 'a')], [[h('span', null, 'b')]]), c)
    expect(c.querySelectorAll('span').length).toBe(2)
  })
})

describe('Fragment initial render path', () => {
  it('creates fragment and appends children', () => {
    // 测试点：Fragment 初次渲染将多个子节点并列挂载到容器
    const c = document.createElement('div')
    render(h(Fragment, null, h('span', null, 'x'), h('span', null, 'y')), c)
    expect(c.querySelectorAll('span').length).toBe(2)
  })
})

describe('component initial render and patch path', () => {
  it('mounts function component and re-renders on props change', () => {
    // 测试点：函数组件初次挂载与 props 更新触发的子树重渲染
    const c = document.createElement('div')
    const Comp: FC<{ value: number }> = props => <div id="v">{props.value}</div>

    render(h(Comp, { value: 1 }), c)
    expect(c.querySelector('#v')!.textContent).toBe('1')

    render(h(Comp, { value: 2 }), c)
    expect(c.querySelector('#v')!.textContent).toBe('2')
  })
})

describe('patchProps: className and style add/remove', () => {
  it('updates className and removes it when absent', () => {
    // 测试点：className 增加与移除的补丁逻辑
    const c = document.createElement('div')
    render(h('div', { className: 'a' }, 'x'), c)
    const el = c.querySelector('div')!
    expect(el.className).toBe('a')

    // 重新渲染去掉 className -> DOM 清空类名
    render(h('div', null, 'x'), c)
    const el2 = c.querySelector('div')!
    expect(el2.className).toBe('')
  })

  it('adds new style keys and removes missing ones', () => {
    // 测试点：style 补丁支持新增键与移除缺失键
    const c = document.createElement('div')
    render(h('div', { style: { color: 'red' } }, 'x'), c)
    const el = c.querySelector('div')!
    expect(el.style.color).toBe('red')

    // 重新渲染仅设置 backgroundColor：应移除 color 并新增 backgroundColor
    render(h('div', { style: { backgroundColor: 'blue' } }, 'x'), c)
    const el2 = c.querySelector('div')!
    expect(el2.style.color).toBe('')
    expect(el2.style.backgroundColor).toBe('blue')
  })
})

describe('batch: multiple groups', () => {
  it('flushes once per batch and updates DOM accordingly', () => {
    // 测试点：同一批次内多次赋值合并为一次刷新；批次结束后 DOM 反映最终值
    const c = document.createElement('div')
    const s = reactive({ n: 0 })
    // 在 effect 中渲染 n，依赖变化时统一刷新
    effect(() => {
      render(h('div', null, String(s.n)), c)
    })
    expect(c.textContent).toBe('0')

    // 第一批：1->2->3 合并，最终显示 3
    batch(() => {
      s.n = 1
      s.n = 2
      s.n = 3
    })
    expect(c.textContent).toBe('3')

    // 第二批：4->5 合并，最终显示 5
    batch(() => {
      s.n = 4
      s.n = 5
    })
    expect(c.textContent).toBe('5')
  })
})
