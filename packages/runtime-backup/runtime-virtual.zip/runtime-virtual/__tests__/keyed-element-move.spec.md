import { describe, expect, it } from 'vitest'
import { h, render } from '@rue/runtime'

interface Item {
  id: number
  text: string
  completed: boolean
}

function view(items: Item[]) {
  return h(
    'div',
    null,
    ...items.map(i =>
      h(
        'div',
        {
          key: i.id,
          'data-id': String(i.id),
          className: i.completed ? 'done' : 'todo',
        },
        h('p', null, String(i.id)),
        h('span', null, i.text),
      ),
    ),
  )
}

describe('keyed Element movement (<div key=...>)', () => {
  it('first toggle does not reorder or replace siblings', () => {
    const container = document.createElement('div')
    const items: Item[] = [
      { id: 1, text: 'A', completed: false },
      { id: 2, text: 'B', completed: false },
      { id: 3, text: 'C', completed: false },
    ]

    // initial render
    render(view(items), container)

    const q = (id: number) => container.querySelector(`[data-id="${id}"]`) as HTMLDivElement
    const before1 = q(1)
    const before2 = q(2)
    const before3 = q(3)

    expect(before1).toBeTruthy()
    expect(before2).toBeTruthy()
    expect(before3).toBeTruthy()
    expect(container.querySelectorAll('[data-id]').length).toBe(3)

    // initial class states
    expect(before1.className).toBe('todo')
    expect(before2.className).toBe('todo')
    expect(before3.className).toBe('todo')

    // toggle one item (simulate first click)
    items[1].completed = !items[1].completed
    render(view(items), container)

    const after1 = q(1)
    const after2 = q(2)
    const after3 = q(3)

    // identity should be preserved for all siblings
    expect(after1).toBe(before1)
    expect(after2).toBe(before2)
    expect(after3).toBe(before3)

    // className is updated only for the toggled item
    expect(after1.className).toBe('todo')
    expect(after2.className).toBe('done')
    expect(after3.className).toBe('todo')

    // order remains the same
    const els = Array.from(container.querySelectorAll('[data-id]')) as HTMLDivElement[]
    expect(els.map(el => Number(el.getAttribute('data-id')))).toEqual([1, 2, 3])
  })
})
