import { afterEach, describe, expect, it } from 'vitest'
import { type FC, h, mount, useState } from '../src'

afterEach(() => {
  document.body.innerHTML = ''
})

describe('hooks: useState (react style)', () => {
  it('updates primitive value via setter', () => {
    // 测试点：通过 setter 更新基本类型 state 并驱动重渲染
    const CounterComp: FC = () => {
      const [count, setCount] = useState(0)
      return (
        <div>
          <div id="c">{count.value}</div>
          <button id="add" onClick={() => setCount(v => v + 1)}>
            +1
          </button>
        </div>
      )
    }
    const App: FC = () => <CounterComp />

    // 挂载并断言初始值，然后点击触发 setter 更新
    const root = document.createElement('div')
    document.body.appendChild(root)
    // 挂载组件：初始 count=0
    mount(App, root)

    // 初始断言
    expect(document.querySelector('#c')!.textContent).toBe('0')
    // 点击按钮：通过 setter 更新为 1 并触发重渲染
    ;(document.querySelector('#add') as HTMLButtonElement).click()
    // 断言更新结果
    expect(document.querySelector('#c')!.textContent).toBe('1')
  })

  it('supports functional updater and multiple updates', () => {
    // 测试点：函数式更新在同一事件中多次调用时基于最新状态累加
    const CounterComp: FC = () => {
      const [count, setCount] = useState(0)
      return (
        <div>
          <div id="c2">{count.value}</div>
          <button
            id="add2"
            onClick={() => {
              setCount(v => v + 1)
              setCount(v => v + 1)
            }}
          >
            +2
          </button>
        </div>
      )
    }
    const App: FC = () => <CounterComp />

    const root = document.createElement('div')
    document.body.appendChild(root)
    // 挂载组件：初始 count=0
    mount(App, root)

    // 断言初始渲染
    expect(document.querySelector('#c2')!.textContent).toBe('0')
    // 点击按钮：两次函数式更新，第二次基于第一次后的最新值（避免闭包旧值）
    ;(document.querySelector('#add2') as HTMLButtonElement).click()
    // 断言最终值为 2
    expect(document.querySelector('#c2')!.textContent).toBe('2')
  })

  it('updates array state immutably', () => {
    // 测试点：通过不可变操作更新数组，确保引用变化触发重渲染
    const ListComp: FC = () => {
      const [list, setList] = useState<string[]>(['A'])
      return (
        <div>
          <div id="len">{list.length}</div>
          <button id="push" onClick={() => setList(prev => [...prev, 'B'])}>
            push
          </button>
          <button id="pop" onClick={() => setList(prev => prev.slice(0, -1))}>
            pop
          </button>
        </div>
      )
    }
    const App: FC = () => <ListComp />

    const root = document.createElement('div')
    document.body.appendChild(root)
    // 挂载组件：初始 list=['A']，长度 1
    mount(App, root)

    // 初始断言
    expect(document.querySelector('#len')!.textContent).toBe('1')
    // 两次 push：不可变追加，引用变化 -> 触发渲染，长度到 3
    ;(document.querySelector('#push') as HTMLButtonElement).click()
    ;(document.querySelector('#push') as HTMLButtonElement).click()
    expect(document.querySelector('#len')!.textContent).toBe('3')
    // 一次 pop：不可变裁剪，长度回到 2
    ;(document.querySelector('#pop') as HTMLButtonElement).click()
    expect(document.querySelector('#len')!.textContent).toBe('2')
  })

  it('updates object state with shallow copy', () => {
    // 测试点：使用浅拷贝按字段更新对象，保证不可变并精确控制变化范围
    const UserComp: FC = () => {
      const [user, setUser] = useState<{ name: string; age: number }>({
        name: 'A',
        age: 20,
      })
      return (
        <div>
          <input
            id="name"
            value={user.name}
            onInput={(e: any) =>
              setUser(u => ({
                ...u,
                name: (e.target as HTMLInputElement).value,
              }))
            }
          />
          <div id="age">{user.age}</div>
          <button id="inc" onClick={() => setUser(u => ({ ...u, age: u.age + 1 }))}>
            inc
          </button>
        </div>
      )
    }
    const App: FC = () => <UserComp />

    const root = document.createElement('div')
    document.body.appendChild(root)
    // 挂载组件：初始 user={ name:'A', age:20 }
    mount(App, root)

    // 断言初始 age
    expect(document.querySelector('#age')!.textContent).toBe('20')
    // 点击 inc：浅拷贝更新 age 字段，name 不变
    ;(document.querySelector('#inc') as HTMLButtonElement).click()
    expect(document.querySelector('#age')!.textContent).toBe('21')

    // 修改输入框：浅拷贝仅更新 name 字段，不影响 age
    const nameInput = document.querySelector('#name') as HTMLInputElement
    nameInput.value = 'B'
    nameInput.dispatchEvent(new Event('input'))
    expect((document.querySelector('#name') as HTMLInputElement).value).toBe('B')
    expect(document.querySelector('#age')!.textContent).toBe('21')
  })

  it('maintains hook order and independence across multiple useState calls', () => {
    // 测试点：多个 useState 调用顺序稳定；更新某一 state 不影响另一 state
    const DuoComp: FC = () => {
      const [a, setA] = useState(1)
      const [b, setB] = useState(10)
      return (
        <div>
          <div id="a">{a.value}</div>
          <div id="b">{b.value}</div>
          <button id="addA" onClick={() => setA(v => v + 1)}>
            addA
          </button>
          <button id="addB" onClick={() => setB(v => v + 5)}>
            addB
          </button>
        </div>
      )
    }
    const App: FC = () => <DuoComp />

    const root = document.createElement('div')
    document.body.appendChild(root)
    // 挂载组件：初始 a=1, b=10
    mount(App, root)

    // 初始断言
    expect(document.querySelector('#a')!.textContent).toBe('1')
    expect(document.querySelector('#b')!.textContent).toBe('10')
    // 仅更新 b：验证 a 不变，hook 独立性成立
    ;(document.querySelector('#addB') as HTMLButtonElement).click()
    expect(document.querySelector('#a')!.textContent).toBe('1')
    expect(document.querySelector('#b')!.textContent).toBe('15')
    // 仅更新 a：验证 b 不变
    ;(document.querySelector('#addA') as HTMLButtonElement).click()
    expect(document.querySelector('#a')!.textContent).toBe('2')
    expect(document.querySelector('#b')!.textContent).toBe('15')
  })

  it('isolates state across multiple component instances', () => {
    // 测试点：同一组件的不同实例拥有各自独立的 state；相互不干扰
    const CounterComp: FC<{ id: string }> = props => {
      const [count, setCount] = useState(0)
      return (
        <div>
          <div id={`c-${props.id}`}>{count.value}</div>
          <button id={`add-${props.id}`} onClick={() => setCount(v => v + 1)}>
            +1
          </button>
        </div>
      )
    }
    const App: FC = () => (
      <div>
        <CounterComp id="a" />
        <CounterComp id="b" />
      </div>
    )

    const root = document.createElement('div')
    document.body.appendChild(root)
    // 同时挂载两个实例：各自拥有独立的 state
    mount(App, root)

    // 初始断言：两个实例均为 0
    expect(document.querySelector('#c-a')!.textContent).toBe('0')
    expect(document.querySelector('#c-b')!.textContent).toBe('0')
    // 仅点击 a 实例按钮：只影响 a，不影响 b
    ;(document.querySelector('#add-a') as HTMLButtonElement).click()
    expect(document.querySelector('#c-a')!.textContent).toBe('1')
    expect(document.querySelector('#c-b')!.textContent).toBe('0')
  })

  it('toggles boolean state', () => {
    // 测试点：通过函数式更新对布尔 state 取反，交替显示 true/false
    const ToggleComp: FC = () => {
      const [on, setOn] = useState(false)
      return (
        <button id="toggle" onClick={() => setOn(v => !v)}>
          {String(on.value)}
        </button>
      )
    }
    const App: FC = () => <ToggleComp />

    const root = document.createElement('div')
    document.body.appendChild(root)
    // 挂载：初始 on=false
    mount(App, root)

    // 初始断言
    expect((document.querySelector('#toggle') as HTMLButtonElement).textContent).toBe('false')
    // 第一次点击：取反 -> true
    ;(document.querySelector('#toggle') as HTMLButtonElement).click()
    expect((document.querySelector('#toggle') as HTMLButtonElement).textContent).toBe('true')
    // 第二次点击：再取反 -> false
    ;(document.querySelector('#toggle') as HTMLButtonElement).click()
    expect((document.querySelector('#toggle') as HTMLButtonElement).textContent).toBe('false')
  })

  it('updates multiple states in one handler', () => {
    // 测试点：同一事件处理器中更新多个 state，确保都按顺序生效
    const DuoComp: FC = () => {
      const [a, setA] = useState(0)
      const [b, setB] = useState(0)
      return (
        <div>
          <div id="ma">{a.value}</div>
          <div id="mb">{b.value}</div>
          <button
            id="both"
            onClick={() => {
              setA(v => v + 1)
              setB(v => v + 2)
            }}
          >
            both
          </button>
        </div>
      )
    }
    const App: FC = () => <DuoComp />

    const root = document.createElement('div')
    document.body.appendChild(root)
    // 挂载：初始 a=0, b=0
    mount(App, root)

    // 初始断言
    expect(document.querySelector('#ma')!.textContent).toBe('0')
    expect(document.querySelector('#mb')!.textContent).toBe('0')
    // 点击按钮：同一处理器中依次更新 a 和 b（a+1, b+2）
    ;(document.querySelector('#both') as HTMLButtonElement).click()
    // 断言两者均按预期变化，渲染反映最终合并结果
    expect(document.querySelector('#ma')!.textContent).toBe('1')
    expect(document.querySelector('#mb')!.textContent).toBe('2')
  })
})
