import { describe, expect, it } from 'vitest'
import {
  _$appendChild as appendChild,
  _$createDocumentFragment as createDocumentFragment,
  _$createElement as createElement,
  _$setStyle as setStyle,
  _$settextContent as settextContent,
} from '@rue/runtime'

describe('dom utilities', () => {
  it('createElement creates HTML and SVG elements', () => {
    const div = createElement('div')
    const svg = createElement('svg') as SVGElement
    expect(div instanceof HTMLElement).toBe(true)
    expect(svg instanceof SVGElement).toBe(true)
    expect(svg.namespaceURI).toBe('http://www.w3.org/2000/svg')
  })

  it('setStyle applies string and object styles, removes on null', () => {
    const el = document.createElement('div')
    setStyle(el as any, 'color: red;')
    expect(el.getAttribute('style')).toContain('color: red')
    setStyle(el as any, { backgroundColor: 'blue', display: 'block' })
    expect(el.style.backgroundColor).toBe('blue')
    expect(el.style.display).toBe('block')
    setStyle(el as any, null)
    expect(el.getAttribute('style')).toBeNull()
  })

  it('settextContent normalizes values', () => {
    const el = document.createElement('div')
    settextContent(el, 'X')
    expect(el.textContent).toBe('X')
    settextContent(el, 123)
    expect(el.textContent).toBe('123')
    settextContent(el, true)
    expect(el.textContent).toBe('')
    settextContent(el, null)
    expect(el.textContent).toBe('')
  })

  it('createDocumentFragment returns a fragment', () => {
    const frag = createDocumentFragment()
    expect(frag.nodeType).toBe(11)
  })

  it('appendChild appends node', () => {
    const parent = document.createElement('div')
    const child = document.createElement('span')
    appendChild(parent, child)
    expect(parent.firstChild).toBe(child)
  })
})
