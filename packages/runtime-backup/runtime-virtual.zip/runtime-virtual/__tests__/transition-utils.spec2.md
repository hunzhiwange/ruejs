import { describe, expect, it, vi } from 'vitest'
import { TransitionUtils } from '@rue/runtime'

describe('TransitionUtils basic APIs (jsdom)', () => {
  it('toMs parses durations and delays', () => {
    expect(TransitionUtils.toMs('100ms')).toBe(100)
    expect(TransitionUtils.toMs('0.1s')).toBe(100)
    expect(TransitionUtils.toMs('100ms, 0.2s')).toBe(300)
    expect(TransitionUtils.toMs('auto')).toBe(0)
  })

  it('inferType detects transition vs animation', () => {
    const el = document.createElement('div')
    el.style.transition = 'opacity 10ms'
    el.style.animation = ''
    expect(TransitionUtils.inferType(el)).toBe('transition')

    el.style.transition = ''
    el.style.animation = 'fade 20ms'
    expect(TransitionUtils.inferType(el)).toBe('animation')

    el.style.animation = ''
    expect(TransitionUtils.inferType(el)).toBe(null)
  })

  it('resolveDuration prefers specified duration', () => {
    const el = document.createElement('div')
    el.style.transition = 'opacity 10ms'
    el.style.animation = 'fade 20ms'
    expect(TransitionUtils.resolveDuration(el, undefined, 30, 'enter')).toBe(30)
    expect(TransitionUtils.resolveDuration(el, undefined, { enter: 40, leave: 50 }, 'enter')).toBe(
      40,
    )
    expect(TransitionUtils.resolveDuration(el, undefined, { enter: 40, leave: 50 }, 'leave')).toBe(
      50,
    )
    expect(TransitionUtils.resolveDuration(el, 'transition', undefined, 'enter')).toBe(10)
    expect(TransitionUtils.resolveDuration(el, 'animation', undefined, 'enter')).toBe(20)
  })

  it('whenTransitionEnds resolves by event', () => {
    const el = document.createElement('div')
    el.style.transition = 'opacity 10ms'
    const done = vi.fn()
    TransitionUtils.whenTransitionEnds(el, 'transition', 10, done)
    el.dispatchEvent(new Event('transitionend'))
    expect(done).toHaveBeenCalledTimes(1)
  })
})
