import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  type FC,
  Fragment,
  h,
  onBeforeMount,
  onBeforeUnmount,
  onBeforeUpdate,
  onMounted,
  onUnmounted,
  onUpdated,
  render,
} from '../src'

afterEach(() => {
  document.body.innerHTML = ''
})

describe('lifecycle mount order: parent-child', () => {
  it('calls beforeMount/mounted in correct order', () => {
    // 测试点：挂载阶段的父子调用顺序（beforeMount 先父后子；mounted 先子后父）
    const order: string[] = []
    const pBM = vi.fn(() => order.push('parent:beforeMount'))
    const pM = vi.fn(() => order.push('parent:mounted'))
    const cBM = vi.fn(() => order.push('child:beforeMount'))
    const cM = vi.fn(() => order.push('child:mounted'))

    // 子组件注册挂载钩子
    const Child: FC = () => {
      onBeforeMount(cBM)
      onMounted(cM)
      return <div id="child">c</div>
    }

    // 父组件注册并渲染子组件
    const Parent: FC = () => {
      onBeforeMount(pBM)
      onMounted(pM)
      return (
        <div id="parent">
          <Child />
        </div>
      )
    }

    // 渲染并断言调用顺序与次数
    const c = document.createElement('div')
    render(h(Parent, null), c)

    expect(order).toEqual([
      'parent:beforeMount',
      'child:beforeMount',
      'child:mounted',
      'parent:mounted',
    ])
    expect(pBM).toHaveBeenCalledTimes(1)
    expect(pM).toHaveBeenCalledTimes(1)
    expect(cBM).toHaveBeenCalledTimes(1)
    expect(cM).toHaveBeenCalledTimes(1)
  })
})

describe('lifecycle update order: parent-child', () => {
  it('calls beforeUpdate/updated in correct order on re-render', () => {
    // 测试点：更新阶段的父子调用顺序（beforeUpdate 先父后子；updated 先子后父）
    const order: string[] = []
    const pBU = vi.fn(() => order.push('parent:beforeUpdate'))
    const pU = vi.fn(() => order.push('parent:updated'))
    const cBU = vi.fn(() => order.push('child:beforeUpdate'))
    const cU = vi.fn(() => order.push('child:updated'))

    const Child: FC<{ v: number }> = props => {
      onBeforeUpdate(cBU)
      onUpdated(cU)
      return <span id="child-v">{props.v}</span>
    }

    const Parent: FC<{ v: number }> = props => {
      onBeforeUpdate(pBU)
      onUpdated(pU)
      return (
        <div id="parent">
          <Child v={props.v} />
        </div>
      )
    }

    // 首次渲染后更新 props，触发父子更新钩子
    const c = document.createElement('div')
    render(h(Parent, { v: 1 }), c)
    render(h(Parent, { v: 2 }), c)

    // 断言调用顺序与最终 DOM 文本
    expect(order).toEqual([
      'parent:beforeUpdate',
      'child:beforeUpdate',
      'child:updated',
      'parent:updated',
    ])
    expect(c.querySelector('#child-v')!.textContent).toBe('2')
  })
})

describe('lifecycle unmount order: parent-child', () => {
  it('calls beforeUnmount/unmounted with correct ordering on replacement', () => {
    // 测试点：卸载阶段的父子调用顺序（beforeUnmount 先父后子；unmounted 先子后父）
    const order: string[] = []
    const pBUm = vi.fn(() => order.push('parent:beforeUnmount'))
    const pUm = vi.fn(() => order.push('parent:unmounted'))
    const cBUm = vi.fn(() => order.push('child:beforeUnmount'))
    const cUm = vi.fn(() => order.push('child:unmounted'))

    const Child: FC = () => {
      onBeforeUnmount(cBUm)
      onUnmounted(cUm)
      return <div id="child">c</div>
    }

    const Parent: FC = () => {
      onBeforeUnmount(pBUm)
      onUnmounted(pUm)
      return (
        <div id="parent">
          <Child />
        </div>
      )
    }

    // 先渲染父子，后替换为普通元素，触发卸载钩子
    const c = document.createElement('div')
    render(h(Parent, null), c)
    render(h('div', { id: 'replaced' }, 'x'), c)

    // 断言父子卸载调用顺序与最终 DOM
    expect(order).toEqual([
      'parent:beforeUnmount',
      'child:beforeUnmount',
      'child:unmounted',
      'parent:unmounted',
    ])
    expect(c.querySelector('#replaced')!.textContent).toBe('x')
  })
})

describe('lifecycle does not duplicate handlers for same function', () => {
  it('onUpdated registered with the same fn is called once per update', () => {
    // 测试点：同一 onUpdated 回调不重复注册，更新时只调用一次
    const pU = vi.fn()
    const cU = vi.fn()

    const Child: FC<{ v: number }> = props => {
      onUpdated(cU)
      return <span id="child-v">{props.v}</span>
    }

    const Parent: FC<{ v: number }> = props => {
      onUpdated(pU)
      return (
        <div id="parent">
          <Child v={props.v} />
        </div>
      )
    }

    // 连续三次更新：created 不触发，updated 触发两次
    const c = document.createElement('div')
    render(h(Parent, { v: 1 }), c)
    render(h(Parent, { v: 2 }), c)
    render(h(Parent, { v: 3 }), c)

    expect(pU).toHaveBeenCalledTimes(2)
    expect(cU).toHaveBeenCalledTimes(2)
  })
})

describe('lifecycle with fragments', () => {
  it('mount/update/unmount works inside Fragment', () => {
    // 测试点：Fragment 内部的挂载、更新、卸载钩子照常工作
    const m = vi.fn()
    const u = vi.fn()
    const bu = vi.fn()

    const Comp: FC<{ n: number }> = props => {
      onMounted(m)
      onBeforeUpdate(bu)
      onUpdated(u)
      return h(Fragment, null, <span id="n">{props.n}</span>, <span>a</span>)
    }

    // 更新 props：触发 beforeUpdate/updated；再替换为普通元素触发卸载
    const c = document.createElement('div')
    render(h(Comp, { n: 1 }), c)
    render(h(Comp, { n: 2 }), c)

    expect(bu).toHaveBeenCalledTimes(1)
    expect(u).toHaveBeenCalledTimes(1)
    expect(c.querySelector('#n')!.textContent).toBe('2')

    render(h('div', null, 'gone'), c)
    expect(c.querySelector('#n')).toBeNull()
  })
})
