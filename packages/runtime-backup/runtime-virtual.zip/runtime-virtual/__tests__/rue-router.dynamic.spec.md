import { afterEach, describe, expect, it } from 'vitest'
import { type FC, useEffect, h, render } from '../src'
import {
  RouterLink,
  RouterView,
  createRouter,
  createWebHashHistory,
  attachRouter,
} from '@rue/router'

afterEach(() => {
  document.body.innerHTML = ''
  window.location.hash = '#/'
})

describe('dynamic route params', () => {
  it('matches "/posts/:id" and passes params to component via RouterView', () => {
    // 测试点：动态路由参数解析；RouterView 向组件传递 params
    const c = document.createElement('div')
    const Detail: FC<{ params?: any }> = props =>
      h('div', { id: 'detail' }, `ID:${props.params?.id}`)

    // 创建路由并声明动态路径
    const _router = createRouter({
      history: createWebHashHistory(),
      routes: [{ path: '/posts/:id', component: Detail }],
    })
    attachRouter(c, _router as any)

    // 模拟跳转到含有 id 的地址，并触发 hashchange
    window.location.hash = '#/posts/42'
    window.dispatchEvent(new HashChangeEvent('hashchange'))

    // 在响应式 effect 中渲染 RouterView（路由变化会自动重渲染）
    useEffect(() => {
      render(h(RouterView, null), c)
    })

    // 断言：组件拿到 params.id 并渲染出来
    expect(c.querySelector('#detail')?.textContent).toContain('42')
  })

  it('RouterLink navigates to dynamic route and updates RouterView', () => {
    // 测试点：点击 RouterLink 触发导航；RouterView 根据当前路由更新视图
    const c = document.createElement('div')
    const List: FC = () => h('div', { id: 'list' }, 'List')
    const Detail: FC<{ params?: any }> = props =>
      h('div', { id: 'detail' }, `ID:${props.params?.id}`)

    // 定义列表与详情两条路由（详情为动态路径）
    const _router = createRouter({
      history: createWebHashHistory(),
      routes: [
        { path: '/posts', component: List },
        { path: '/posts/:id', component: Detail },
      ],
    })
    attachRouter(c, _router as any)

    // 在 effect 中渲染 RouterLink 与 RouterView
    useEffect(() => {
      render(h('div', null, h(RouterLink, { to: '/posts/7' }, 'Go 7'), h(RouterView, null)), c)
    })

    // 点击链接后：hash 更新，RouterView 切换到 Detail 并传入 id=7
    const a = c.querySelector('a') as HTMLAnchorElement
    a.click()

    expect(window.location.hash).toBe('#/posts/7')
    expect(c.querySelector('#detail')?.textContent).toContain('7')
    expect(c.querySelector('#list')).toBeNull()
  })
})
