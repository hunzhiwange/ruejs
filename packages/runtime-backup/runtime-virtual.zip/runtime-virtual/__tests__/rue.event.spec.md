import { afterEach, describe, expect, it, vi } from 'vitest'
import { type FC, emitted, h, render } from '../src'

afterEach(() => {
  document.body.innerHTML = ''
})

describe('DOM event binding and trigger', () => {
  it('attaches and triggers onClick', () => {
    // 测试点：DOM 事件绑定与触发
    const c = document.createElement('div')
    const spy = vi.fn()

    // 渲染按钮并绑定 onClick
    render(h('button', { onClick: spy }, 'btn'), c)
    const btn = c.querySelector('button')!
    // 触发点击事件（模拟用户点击）
    btn.dispatchEvent(new MouseEvent('click', { bubbles: true }))

    // 断言回调被调用一次
    expect(spy).toHaveBeenCalledTimes(1)
  })

  it('updates handler and removes when absent', () => {
    // 测试点：事件处理函数的替换与移除
    const c = document.createElement('div')
    const spy1 = vi.fn()
    const spy2 = vi.fn()

    // 初次绑定 spy1
    render(h('button', { onClick: spy1 }, 'btn'), c)
    const btn1 = c.querySelector('button')!
    btn1.dispatchEvent(new MouseEvent('click', { bubbles: true }))
    expect(spy1).toHaveBeenCalledTimes(1)

    // 替换为 spy2：点击只触发新处理器
    render(h('button', { onClick: spy2 }, 'btn'), c)
    const btn2 = c.querySelector('button')!
    btn2.dispatchEvent(new MouseEvent('click', { bubbles: true }))
    expect(spy2).toHaveBeenCalledTimes(1)
    expect(spy1).toHaveBeenCalledTimes(1)

    // 移除处理器：点击不触发任何回调
    render(h('button', null, 'btn'), c)
    const btn3 = c.querySelector('button')!
    btn3.dispatchEvent(new MouseEvent('click', { bubbles: true }))
    expect(spy2).toHaveBeenCalledTimes(1)
  })
})

describe('emitted in component with camelCase and lowercase handler', () => {
  const Emitter: FC<{
    onChange?: (v: number) => void
    onchange?: (v: number) => void
  }> = props => {
    const emit = emitted(props)
    return (
      <button id="em" onClick={() => emit('change', 42)}>
        emit
      </button>
    )
  }

  it('calls onChange when provided', () => {
    // 测试点：组件内 emit 调用 camelCase 事件处理器
    const c = document.createElement('div')
    const handler = vi.fn()

    // 传入 onChange，点击触发 emit('change', 42)
    render(h(Emitter, { onChange: handler }), c)
    const btn = c.querySelector('#em')!
    btn.dispatchEvent(new MouseEvent('click', { bubbles: true }))

    expect(handler).toHaveBeenCalledTimes(1)
    expect(handler).toHaveBeenCalledWith(42)
  })

  it('calls onchange (lowercase) when provided', () => {
    // 测试点：组件内 emit 同时支持小写事件名 handler
    const c = document.createElement('div')
    const handler = vi.fn()

    // 传入 onchange，点击触发 emit('change', 42)
    render(h(Emitter, { onchange: handler }), c)
    const btn = c.querySelector('#em')!
    btn.dispatchEvent(new MouseEvent('click', { bubbles: true }))

    expect(handler).toHaveBeenCalledTimes(1)
    expect(handler).toHaveBeenCalledWith(42)
  })
})

describe('patchProps: remove and re-add event listeners correctly', () => {
  it('removes old listener and adds new one during diff', () => {
    // 测试点：补丁阶段正确移除旧监听并添加新监听
    const c = document.createElement('div')
    const a = vi.fn()
    const b = vi.fn()

    // 初次绑定 a
    render(h('button', { onClick: a }, 'x'), c)
    const btnA = c.querySelector('button')!
    btnA.dispatchEvent(new MouseEvent('click', { bubbles: true }))
    expect(a).toHaveBeenCalledTimes(1)

    // 替换为 b：后续点击只调用 b
    render(h('button', { onClick: b }, 'x'), c)
    const btnB = c.querySelector('button')!
    btnB.dispatchEvent(new MouseEvent('click', { bubbles: true }))
    expect(b).toHaveBeenCalledTimes(1)
    expect(a).toHaveBeenCalledTimes(1)

    // 不变更：保持 b，点击累计调用次数
    render(h('button', { onClick: b }, 'x'), c)
    const btnC = c.querySelector('button')!
    btnC.dispatchEvent(new MouseEvent('click', { bubbles: true }))
    expect(b).toHaveBeenCalledTimes(2)
  })
})
