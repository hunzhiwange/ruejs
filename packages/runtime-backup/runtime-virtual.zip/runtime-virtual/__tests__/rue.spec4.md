import { afterEach, describe, expect, it } from 'vitest'
import { h, renderBetween, vapor } from '../src'

afterEach(() => {
  document.body.innerHTML = ''
})

function elsBetween(start: Comment, end: Comment): HTMLElement[] {
  const out: HTMLElement[] = []
  let n: Node | null = start.nextSibling
  while (n && n !== end) {
    if (n.nodeType === 1) out.push(n as HTMLElement)
    n = (n as any).nextSibling
  }
  return out
}

describe('renderBetween edge cases', () => {
  it('replaces element with vapor fragment', () => {
    const parent = document.createElement('div')
    const start = document.createComment('rue:slot:start')
    const end = document.createComment('rue:slot:end')
    parent.appendChild(start)
    parent.appendChild(end)

    renderBetween(h('div', null, 'X'), parent, start, end)
    let els = elsBetween(start, end)
    expect(els.length).toBe(1)
    expect(els[0].tagName).toBe('DIV')

    const v = vapor(() => {
      const frag = document.createDocumentFragment()
      const s = document.createElement('span')
      s.id = 'V1'
      frag.appendChild(s)
      return { vaporElement: frag }
    })
    renderBetween(v, parent, start, end)
    els = elsBetween(start, end)
    expect(els.map(e => e.id)).toEqual(['V1'])
    expect(parent.querySelector('div')).toBeNull()
  })

  it('idempotent: rendering same vnode twice keeps single node', () => {
    const parent = document.createElement('div')
    const start = document.createComment('rue:slot:start')
    const end = document.createComment('rue:slot:end')
    parent.appendChild(start)
    parent.appendChild(end)

    const node = h('div', { id: 'ONE' }, 'A')
    renderBetween(node, parent, start, end)
    renderBetween(node, parent, start, end)

    const els = elsBetween(start, end)
    expect(els.length).toBe(1)
    expect(els[0].id).toBe('ONE')
    expect(els[0].textContent).toBe('A')
  })
})
