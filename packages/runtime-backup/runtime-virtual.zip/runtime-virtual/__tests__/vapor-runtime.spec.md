import { describe, expect, it } from 'vitest'
import { type VaporListItemRange, _$vaporKeyedList as vaporKeyedList } from '@rue/runtime'

describe('vaporKeyedList reorder/insert/remove', () => {
  it('reorders keyed ranges in one pass and preserves identity', () => {
    const parent = document.createElement('ul')
    let elements = new Map<any, VaporListItemRange>()

    const renderItem = (
      item: number,
      p: Node & ParentNode,
      start: Comment,
      end: Comment,
      _idx?: number,
    ) => {
      // simple item: <li data-id=...>...</li> between start/end
      const li = document.createElement('li')
      li.setAttribute('data-id', String(item))
      li.textContent = String(item)
      p.insertBefore(li, end)
    }

    let items = [1, 2, 3, 4, 5]
    elements = vaporKeyedList({
      items,
      getKey: (x: number) => x,
      elements,
      parent,
      before: null,
      renderItem,
    })
    const beforeEls = Array.from(parent.querySelectorAll('[data-id]'))
    const beforeById: Record<number, Element> = {}
    beforeEls.forEach(el => (beforeById[Number(el.getAttribute('data-id'))] = el))

    items = [5, 4, 3, 2, 1]
    elements = vaporKeyedList({
      items,
      getKey: (x: number) => x,
      elements,
      parent,
      before: null,
      renderItem,
    })
    const order = Array.from(parent.querySelectorAll('[data-id]')).map(el =>
      Number(el.getAttribute('data-id')),
    )
    expect(order).toEqual([5, 4, 3, 2, 1])
    order.forEach(id => {
      const el = parent.querySelector(`[data-id="${id}"]`)!
      expect(el).toBe(beforeById[id])
    })
  })

  it('inserts and removes items while preserving existing ranges', () => {
    const parent = document.createElement('ul')
    let elements = new Map<any, VaporListItemRange>()
    const renderItem = (
      item: number,
      p: Node & ParentNode,
      start: Comment,
      end: Comment,
      _idx?: number,
    ) => {
      const li = document.createElement('li')
      li.setAttribute('data-id', String(item))
      li.textContent = String(item)
      p.insertBefore(li, end)
    }

    let items = [1, 2, 3]
    vaporKeyedList({ items, getKey: x => x, elements, parent, before: null, renderItem })
    const before1 = parent.querySelector('[data-id="1"]')!
    const before3 = parent.querySelector('[data-id="3"]')!

    items = [3, 1, 4]
    vaporKeyedList({ items, getKey: x => x, elements, parent, before: null, renderItem })
    const ids = Array.from(parent.querySelectorAll('[data-id]')).map(el =>
      Number(el.getAttribute('data-id')),
    )
    expect(ids).toEqual([3, 1, 4])
    expect(parent.querySelector('[data-id="1"]')).toBe(before1)
    expect(parent.querySelector('[data-id="3"]')).toBe(before3)
    expect(parent.querySelector('[data-id="4"]')).toBeTruthy()
  })
})
