import { afterEach, describe, expect, it } from 'vitest'
import { type FC, useComponent, useEffect, h, render } from '../src'
import {
  RouterLink,
  RouterView,
  createRouter,
  createWebHashHistory,
  attachRouter,
} from '@rue/router'

afterEach(() => {
  document.body.innerHTML = ''
  window.location.hash = '#/'
})

const Detail: FC<{ params?: any }> = p => h('div', { id: 'detail' }, `ID:${p.params?.id ?? '-'}`)

describe('lazy route component', () => {
  it('renders loading then component after loader resolves', async () => {
    // 测试点：异步组件加载流程；加载中显示占位，加载完成后显示真实组件
    const c = document.createElement('div')
    // 定义异步组件：模拟延时后返回 Detail 组件
    const LazyDetail = useComponent<{ params?: any }>(
      () =>
        new Promise<{ default: FC<{ params?: any }> }>(res =>
          setTimeout(() => res({ default: Detail }), 0),
        ),
    )
    // 创建路由：动态路径使用异步组件
    const r = createRouter({
      history: createWebHashHistory(),
      routes: [{ path: '/posts/:id', component: LazyDetail }],
    })
    attachRouter(c, r as any)
    // 导航到目标路由并触发 hashchange
    window.location.hash = '#/posts/9'
    window.dispatchEvent(new HashChangeEvent('hashchange'))
    // effect 中渲染 RouterView：先显示 Loading，然后等待加载完成
    useEffect(() => {
      render(h(RouterView, null), c)
    })
    expect(c.textContent).toMatch(/Loading/i)
    await new Promise(r => setTimeout(r, 0))
    // 断言加载完成后 Detail 已渲染且拿到 params.id
    expect(c.querySelector('#detail')?.textContent).toContain('9')
  })

  it('RouterLink triggers lazy load and updates view', async () => {
    // 测试点：点击 RouterLink 触发异步加载；视图先 Loading 后渲染真实组件
    const c = document.createElement('div')
    const List: FC = () => h('div', { id: 'list' }, 'List')
    // 定义异步 Detail：延时后返回真实组件
    const LazyDetail = useComponent<{ params?: any }>(
      () =>
        new Promise<{ default: FC<{ params?: any }> }>(res =>
          setTimeout(() => res({ default: Detail }), 0),
        ),
    )
    // 路由配置：列表与异步详情
    const r = createRouter({
      history: createWebHashHistory(),
      routes: [
        { path: '/posts', component: List },
        { path: '/posts/:id', component: LazyDetail },
      ],
    })
    attachRouter(c, r as any)
    // effect 渲染：包含链接与 RouterView
    useEffect(() => {
      render(h('div', null, h(RouterLink, { to: '/posts/7' }, 'Go 7'), h(RouterView, null)), c)
    })
    // 点击后：进入 Loading 状态，再等待加载完成
    ;(c.querySelector('a') as HTMLAnchorElement).click()
    expect(c.textContent).toMatch(/Loading/i)
    await new Promise(r => setTimeout(r, 0))
    // Detail 渲染并取到 id；列表被切换掉
    expect(c.querySelector('#detail')?.textContent).toContain('7')
    expect(c.querySelector('#list')).toBeNull()
  })
})
