export interface DOMAdapter {
  createComment(data: string): Comment
  createTextNode(data: string): Text
  createElement(tag: string): Element
  createTextWrapper(parent: Element): Element
  setStyle(el: HTMLElement, style: string | Partial<CSSStyleDeclaration> | null | undefined): void
  patchStyle(
    el: HTMLElement,
    oldStyle: Partial<CSSStyleDeclaration> | undefined,
    newStyle: Partial<CSSStyleDeclaration> | undefined,
  ): void
  settextContent(el: Node, val: any): void
  createDocumentFragment(): DocumentFragment
  appendChild(parent: Node, child: Node): void
  removeChild(parent: Node, child: Node): void
  insertBefore(parent: Node, child: Node, ref: Node | null): void
  replaceChild(parent: Node, newChild: Node, oldChild: Node): void
  querySelector(selector: string): Element | null
  setAttribute(el: Element, name: string, value: any): void
  removeAttribute(el: Element, name: string): void
  addEventListener(el: Element, eventName: string, listener: DOMEventHandler): void
  removeEventListener(el: Element, eventName: string, listener: DOMEventHandler): void
  setClassName(el: Element, value: string): void
  setInnerHTML(el: Element, html: string): void
  setValue(el: Element, value: any): void
  setChecked(el: Element, checked: boolean): void
  setDisabled(el: Element, disabled: boolean): void
  getTagName(el: Element): string
  contains(parent: Node, child: Node): boolean
  getParentNode(node: Node): Node | null
  isFragment(node: Node): boolean
  collectFragmentChildren(node: Node): Node[]
  applyRef(el: Element, ref: any): void
  clearRef(ref: any): void
}

const SVG_NS = 'http://www.w3.org/2000/svg'
const SVG_TAGS = new Set([
  'svg',
  'g',
  'circle',
  'ellipse',
  'line',
  'path',
  'polygon',
  'polyline',
  'rect',
  'text',
  'defs',
  'clipPath',
  'mask',
  'pattern',
  'linearGradient',
  'radialGradient',
  'stop',
  'use',
  'symbol',
  'marker',
  'foreignObject',
])

export class BrowserDOMAdapter implements DOMAdapter {
  createComment(data: string) {
    return document.createComment(data)
  }
  createTextNode(data: string) {
    return document.createTextNode(data)
  }
  createElement(tag: string) {
    return SVG_TAGS.has(tag) ? document.createElementNS(SVG_NS, tag) : document.createElement(tag)
  }
  createTextWrapper(parent: Element) {
    return parent instanceof SVGElement ? this.createElement('text') : this.createElement('span')
  }
  setStyle(el: HTMLElement, style: string | Partial<CSSStyleDeclaration> | null | undefined) {
    if (typeof style === 'string') {
      el.setAttribute('style', style)
    } else if (style && typeof style === 'object') {
      Object.assign(el.style, style)
    } else {
      el.removeAttribute('style')
    }
  }
  settextContent(el: Node, val: any) {
    el.textContent = val == null || typeof val === 'boolean' ? '' : String(val)
  }
  createDocumentFragment() {
    return document.createDocumentFragment()
  }
  appendChild(parent: Node, child: Node) {
    parent.appendChild(child)
  }
  removeChild(parent: Node, child: Node) {
    parent.removeChild(child)
  }
  insertBefore(parent: Node, child: Node, ref: Node | null) {
    parent.insertBefore(child, ref)
  }
  replaceChild(parent: Node, newChild: Node, oldChild: Node) {
    parent.replaceChild(newChild, oldChild)
  }
  querySelector(selector: string) {
    return document.querySelector(selector)
  }
  setAttribute(el: Element, name: string, value: any) {
    el.setAttribute(name, String(value))
  }
  removeAttribute(el: Element, name: string) {
    el.removeAttribute(name)
  }
  addEventListener(el: Element, eventName: string, listener: DOMEventHandler) {
    el.addEventListener(eventName, listener)
  }
  removeEventListener(el: Element, eventName: string, listener: DOMEventHandler) {
    el.removeEventListener(eventName, listener)                 
  }
  setClassName(el: Element, value: string) {
    if (el instanceof SVGElement) {
      el.setAttribute('class', value)
    } else {
      ;(el as HTMLElement).className = value
    }
  }
  setInnerHTML(el: Element, html: string) {
    ;(el as HTMLElement).innerHTML = html
  }
  patchStyle(
    el: HTMLElement,
    oldStyle: Partial<CSSStyleDeclaration> | undefined,
    newStyle: Partial<CSSStyleDeclaration> | undefined,
  ) {
    const prev = oldStyle || {}
    const next = newStyle || {}
    for (const k of Object.keys(prev)) {
      if (!(k in next)) (el.style as any)[k] = ''
    }
    Object.assign(el.style, next)
  }
  setValue(el: Element, value: any) {
    if ((el as any).value !== undefined) {
      ;(el as any).value = value
    } else {
      el.setAttribute('value', String(value))
    }
  }
  setChecked(el: Element, checked: boolean) {
    if ((el as any).checked !== undefined) {
      ;(el as any).checked = checked
    } else {
      if (checked) el.setAttribute('checked', '')
      else el.removeAttribute('checked')
    }
  }
  setDisabled(el: Element, disabled: boolean) {
    if ((el as any).disabled !== undefined) {
      ;(el as any).disabled = disabled
    } else {
      if (disabled) el.setAttribute('disabled', '')
      else el.removeAttribute('disabled')
    }
  }
  getTagName(el: Element) {
    return (el as HTMLElement).tagName
  }
  contains(parent: Node, child: Node) {
    return (parent as any).contains?.(child) ?? false
  }
  getParentNode(node: Node) {
    return (node as any).parentNode || null
  }
  isFragment(node: Node) {
    return (node as any).nodeType === 11
  }
  collectFragmentChildren(node: Node) {
    if (this.isFragment(node)) {
      return Array.from((node as DocumentFragment).childNodes)
    }
    return [node]
  }
  applyRef(el: Element, ref: any) {
    if (typeof ref === 'function') {
      ;(ref as Function)(el)
    } else if (ref && typeof ref === 'object' && 'current' in ref) {
      ;(ref as any).current = el
    }
  }
  clearRef(ref: any) {
    if (typeof ref === 'function') {
      ;(ref as Function)(null)
    } else if (ref && typeof ref === 'object' && 'current' in ref) {
      ;(ref as any).current = undefined
    }
  }
}

let CURRENT_ADAPTER: DOMAdapter = new BrowserDOMAdapter()

export const setDOMAdapter = (adapter: DOMAdapter) => {
  CURRENT_ADAPTER = adapter
}
export const getDOMAdapter = () => CURRENT_ADAPTER

export const createComment = (data: string) => CURRENT_ADAPTER.createComment(data)
export const createTextNode = (data: string) => CURRENT_ADAPTER.createTextNode(data)
export const createElement = (tag: string) => CURRENT_ADAPTER.createElement(tag)
export const createTextWrapper = (parent: Element) => CURRENT_ADAPTER.createTextWrapper(parent)
export const setStyle = (
  el: HTMLElement,
  style: string | Partial<CSSStyleDeclaration> | null | undefined,
) => {
  CURRENT_ADAPTER.setStyle(el, style)
}
export const settextContent = (el: Node, val: any) => {
  CURRENT_ADAPTER.settextContent(el, val)
}
export const createDocumentFragment = () => CURRENT_ADAPTER.createDocumentFragment()
export const appendChild = (parent: Node, child: Node) => {
  CURRENT_ADAPTER.appendChild(parent, child)
}
export const removeChild = (parent: Node, child: Node) => {
  CURRENT_ADAPTER.removeChild(parent, child)
}
export const insertBefore = (parent: Node, child: Node, ref: Node | null) => {
  CURRENT_ADAPTER.insertBefore(parent, child, ref)
}
export const replaceChild = (parent: Node, newChild: Node, oldChild: Node) => {
  CURRENT_ADAPTER.replaceChild(parent, newChild, oldChild)
}
export const querySelector = (selector: string) => CURRENT_ADAPTER.querySelector(selector)
export const setAttribute = (el: Element, name: string, value: any) =>
  CURRENT_ADAPTER.setAttribute(el, name, value)
export const removeAttribute = (el: Element, name: string) =>
  CURRENT_ADAPTER.removeAttribute(el, name)
export const addEventListener = (el: Element, eventName: string, listener: DOMEventHandler) =>
  CURRENT_ADAPTER.addEventListener(el, eventName, listener)
export const removeEventListener = (el: Element, eventName: string, listener: DOMEventHandler) =>
  CURRENT_ADAPTER.removeEventListener(el, eventName, listener)
export const setClassName = (el: Element, value: string) => CURRENT_ADAPTER.setClassName(el, value)
export const setInnerHTML = (el: Element, html: string) => CURRENT_ADAPTER.setInnerHTML(el, html)
export const setValue = (el: Element, value: any) => CURRENT_ADAPTER.setValue(el, value)
export const setChecked = (el: Element, checked: boolean) => CURRENT_ADAPTER.setChecked(el, checked)
export const setDisabled = (el: Element, disabled: boolean) =>
  CURRENT_ADAPTER.setDisabled(el, disabled)
export const getTagName = (el: Element) => CURRENT_ADAPTER.getTagName(el)
export const contains = (parent: Node, child: Node) => CURRENT_ADAPTER.contains(parent, child)
export const getParentNode = (node: Node) => CURRENT_ADAPTER.getParentNode(node)
export const patchStyle = (
  el: HTMLElement,
  oldStyle: Partial<CSSStyleDeclaration> | undefined,
  newStyle: Partial<CSSStyleDeclaration> | undefined,
) => CURRENT_ADAPTER.patchStyle(el, oldStyle, newStyle)
export const isFragment = (node: Node) => CURRENT_ADAPTER.isFragment(node)
export const collectFragmentChildren = (node: Node) => CURRENT_ADAPTER.collectFragmentChildren(node)
export const applyRef = (el: Element, ref: any) => CURRENT_ADAPTER.applyRef(el, ref)
export const clearRef = (ref: any) => CURRENT_ADAPTER.clearRef(ref)
export type DomLikeNode = any
export type DOMEventHandler = (evt: any) => void
