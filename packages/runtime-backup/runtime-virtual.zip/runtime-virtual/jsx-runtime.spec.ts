import { describe, expect, it } from 'vitest'
import { h, render } from 'rues'
import { Fragment, jsx, jsxs } from '@rue/jsx-runtime'

describe('jsx-runtime jsx/jsxs', () => {
  it('renders single child with jsx', () => {
    const container = document.createElement('div')
    render(jsx('div', { children: 'X' }), container as any)
    expect(container.querySelector('div')!.textContent).toBe('X')
  })

  it('renders multiple children with jsxs', () => {
    const container = document.createElement('div')
    render(
      jsxs('ul', {
        children: [h('li', null, 'A'), h('li', null, 'B')],
      }),
      container as any,
    )
    const items = Array.from(container.querySelectorAll('li')).map(li => li.textContent)
    expect(items).toEqual(['A', 'B'])
  })

  it('Fragment composes children', () => {
    const container = document.createElement('div')
    render(
      jsx(Fragment, { children: [h('span', null, 'S1'), h('span', null, 'S2')] }),
      container as any,
    )
    const spans = Array.from(container.querySelectorAll('span')).map(s => s.textContent)
    expect(spans).toEqual(['S1', 'S2'])
  })
})
