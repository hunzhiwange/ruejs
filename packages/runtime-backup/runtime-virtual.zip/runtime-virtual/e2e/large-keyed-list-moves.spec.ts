import { describe, it, expect } from 'vitest'
import { h, render, loadAsyncRue } from 'rues'

describe('e2e: large keyed list moves with LIS', () => {
  it('reduces moves with LIS optimization', async () => {
    await loadAsyncRue()
    const container = document.createElement('div')
    const N = 50
    const make = (n: number) => h('li', { key: n }, [String(n)])
    const view = (arr: number[]) => h('ul', {}, arr.map(make))
    const first = Array.from({ length: N }, (_, i) => i + 1)
    render(view(first), container)
    const second = [...first.filter(n => n % 2 === 0), ...first.filter(n => n % 2 === 1)]
    let moves = 0
    const orig = Node.prototype.insertBefore
    ;(Node.prototype.insertBefore as any) = function (this: Node, node: Node, ref: Node | null) {
      if (node.nodeType !== 8 && (node as any).__initial) moves++
      return orig.call(this, node, ref)
    }
    Array.from(container.querySelectorAll('li')).forEach(el => ((el as any).__initial = true))
    render(view(second), container)
    ;(Node.prototype.insertBefore as any) = orig
    expect(moves).toBeLessThanOrEqual(N - Math.floor(N / 2))
    const order = Array.from(container.querySelectorAll('li')).map(el => Number(el.textContent))
    expect(order).toEqual(second)
  })
})
