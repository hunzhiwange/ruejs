import { describe, it, expect } from 'vitest'
import { h, render, loadAsyncRue } from 'rues'

describe('e2e: dangerouslySetInnerHTML vs children toggle', () => {
  it('switches mutually between innerHTML and children', async () => {
    await loadAsyncRue()
    const container = document.createElement('div')
    const htmlView = h('div', { dangerouslySetInnerHTML: { __html: '<span id="A">A</span>' } }, [])
    render(htmlView, container)
    expect(container.querySelector('#A')?.textContent).toBe('A')
    const childrenView = h('div', {}, [h('span', { id: 'B' }, ['B'])])
    render(childrenView, container)
    expect(container.querySelector('#A')).toBeNull()
    expect(container.querySelector('#B')?.textContent).toBe('B')
    const backHtmlView = h('div', { dangerouslySetInnerHTML: { __html: '<i id="C">C</i>' } }, [])
    render(backHtmlView, container)
    expect(container.querySelector('#B')).toBeNull()
    expect(container.querySelector('#C')?.textContent).toBe('C')
  })
})
