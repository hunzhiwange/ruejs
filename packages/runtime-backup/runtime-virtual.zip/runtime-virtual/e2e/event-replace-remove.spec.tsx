import { describe, it, expect } from 'vitest'
import { h, render, loadAsyncRue } from 'rues'

describe('e2e: event replace and remove', () => {
  it('replaces onClick and removes when missing', async () => {
    await loadAsyncRue()
    const container = document.createElement('div')
    let a = 0
    let b = 0
    const viewA = h('button', { onClick: () => a++ }, ['X'])
    render(viewA, container)
    const btn = container.querySelector('button')!
    btn.click()
    expect(a).toBe(1)
    expect(b).toBe(0)
    const viewB = h('button', { onClick: () => b++ }, ['X'])
    render(viewB, container)
    btn.click()
    expect(a).toBe(1)
    expect(b).toBe(1)
    const viewNone = h('button', {}, ['X'])
    render(viewNone, container)
    btn.click()
    expect(a).toBe(1)
    expect(b).toBe(1)
  })
})
